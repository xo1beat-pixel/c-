#pragma once

#include <JuceHeader.h>
#include <cmath>
#include "PluginProcessor.h"

// Shared MIDI pitch-bend helpers used by both the audio processor (real-time
// playback) and the piano roll (MIDI export). Keeping them in ONE place
// guarantees real-time playback and exported files stay in sync.

namespace MidiPitch
{
    constexpr float pitchCurveBeatEpsilon = 0.0000001f;

    // Evaluate the pitch curve at a beat offset relative to the note start.
    // pitchShape: 0 = linear (tension-interpolated), 1 = square (step).
    inline float evaluatePitchBendAtBeat(const NoteEvent& note, float beatOffset, int pitchShape)
    {
        if (note.pitchCurve.empty())
            return 0.0f;

        const float noteLength = juce::jmax(0.0f, note.lengthBeats);
        const float localBeat = noteLength > 0.0f ? juce::jlimit(0.0f, noteLength, beatOffset) : 0.0f;

        if (localBeat <= note.pitchCurve.front().x)
            return note.pitchCurve.front().y;

        if (localBeat >= note.pitchCurve.back().x)
            return note.pitchCurve.back().y;

        for (size_t i = 0; i + 1 < note.pitchCurve.size(); ++i)
        {
            const auto& left = note.pitchCurve[i];
            const auto& right = note.pitchCurve[i + 1];

            if (localBeat >= left.x && localBeat <= right.x)
            {
                const float dx = right.x - left.x;
                if (dx <= pitchCurveBeatEpsilon)
                    return right.y;

                float t = (localBeat - left.x) / dx;

                // Explicit per-node shape (set via the C menu) ALWAYS wins,
                // even when the global pitch-shape mode is Square.
                // Shapes: 1 = Linear, 2 = Square, 3 = Smooth, 4 = Ease In,
                //         5 = Ease Out, 6 = Sine.
                if (left.shape == 2) // Square: hold the value, jump at the end
                    return localBeat < right.x ? left.y : right.y;
                if (left.shape >= 1 && left.shape <= 6)
                {
                    float tt = t;
                    switch (left.shape)
                    {
                        case 3: tt = t * t * (3.0f - 2.0f * t); break;                          // Smooth
                        case 4: tt = t * t; break;                                              // Ease In
                        case 5: tt = 1.0f - (1.0f - t) * (1.0f - t); break;                     // Ease Out
                        case 6: tt = 0.5f - 0.5f * std::cos(t * juce::MathConstants<float>::pi); break; // Sine
                        default: break; // 1 = Linear
                    }
                    return left.y + tt * (right.y - left.y);
                }

                // shape 0 (auto): an explicit tension overrides the global
                // mode (so Alt+drag tension editing works even in Square),
                // otherwise the global mode applies.
                if (left.tension != 0.0f)
                {
                    // Stronger exponent (x6) so moderate tension values curve
                    // harder; tension can go up to +/-2 for extreme shaping.
                    float tt = t;
                    if (left.tension > 0.0f)
                        tt = std::pow(t, 1.0f + left.tension * 6.0f);
                    else
                        tt = 1.0f - std::pow(1.0f - t, 1.0f - left.tension * 6.0f);
                    return left.y + tt * (right.y - left.y);
                }

                if (pitchShape == 1)
                    return localBeat < right.x ? left.y : right.y;

                // Global curve-shape modes for auto nodes:
                // 0 = Linear, 2 = Smooth, 3 = Ease In, 4 = Ease Out, 5 = Sine.
                if (pitchShape != 0)
                {
                    float tt = t;
                    switch (pitchShape)
                    {
                        case 2: tt = t * t * (3.0f - 2.0f * t); break;                          // Smooth
                        case 3: tt = t * t; break;                                              // Ease In
                        case 4: tt = 1.0f - (1.0f - t) * (1.0f - t); break;                     // Ease Out
                        case 5: tt = 0.5f - 0.5f * std::cos(t * juce::MathConstants<float>::pi); break; // Sine
                        default: break;
                    }
                    return left.y + tt * (right.y - left.y);
                }
                return left.y + t * (right.y - left.y);
            }
        }

        return note.pitchCurve.back().y;
    }

    // Convert semitones to a 14-bit MIDI pitch wheel value (0..16383, center 8192).
    inline int pitchBendToMidiValue(float bendSemitones, int bendRange)
    {
        if (bendRange <= 0)
            return 8192;

        float normalizedBend = bendSemitones / (float)bendRange;
        normalizedBend = juce::jlimit(-1.0f, 1.0f, normalizedBend);

        int value = 8192;
        if (normalizedBend >= 0.0f)
            value += (int)std::round(normalizedBend * 8191.0f);
        else
            value += (int)std::round(normalizedBend * 8192.0f);

        return juce::jlimit(0, 16383, value);
    }

    inline void addSequenceEvent(juce::MidiMessageSequence& sequence, juce::MidiMessage message, double tick)
    {
        message.setTimeStamp(tick);
        sequence.addEvent(message);
    }

    // RPN pitch-bend-range setup for an exported MIDI file (timestamped).
    inline void addPitchBendRangeMessages(juce::MidiMessageSequence& sequence, int channel, int semitones, double tick)
    {
        const int range = juce::jlimit(0, 96, semitones);

        addSequenceEvent(sequence, juce::MidiMessage::controllerEvent(channel, 101, 0), tick);
        addSequenceEvent(sequence, juce::MidiMessage::controllerEvent(channel, 100, 0), tick);
        addSequenceEvent(sequence, juce::MidiMessage::controllerEvent(channel, 6, range), tick);
        addSequenceEvent(sequence, juce::MidiMessage::controllerEvent(channel, 38, 0), tick);
        addSequenceEvent(sequence, juce::MidiMessage::controllerEvent(channel, 101, 127), tick);
        addSequenceEvent(sequence, juce::MidiMessage::controllerEvent(channel, 100, 127), tick);
    }

    // RPN pitch-bend-range setup for real-time playback (sample offset).
    inline void addPitchBendRangeMessages(juce::MidiBuffer& midiMessages, int channel, int semitones, int sampleOffset)
    {
        const int range = juce::jlimit(0, 96, semitones);

        midiMessages.addEvent(juce::MidiMessage::controllerEvent(channel, 101, 0), sampleOffset);
        midiMessages.addEvent(juce::MidiMessage::controllerEvent(channel, 100, 0), sampleOffset);
        midiMessages.addEvent(juce::MidiMessage::controllerEvent(channel, 6, range), sampleOffset);
        midiMessages.addEvent(juce::MidiMessage::controllerEvent(channel, 38, 0), sampleOffset);
        midiMessages.addEvent(juce::MidiMessage::controllerEvent(channel, 101, 127), sampleOffset);
        midiMessages.addEvent(juce::MidiMessage::controllerEvent(channel, 100, 127), sampleOffset);
    }

    // Sample step between pitch-bend evaluations.
    //   stepMicros <= 0 : every sample (MAXIMUM evaluation detail)
    //   stepMicros  > 0 : evaluate every N microseconds (e.g. 250 = 0.25 ms)
    //
    // DELIVERY FLOOR: never emit pitch-wheel events denser than ~0.5 ms,
    // regardless of the selected resolution. Denser streams (1 sample or
    // 0.25 ms during a fast slide) overwhelm some instruments' MIDI
    // processing (observed with Kontakt): the tail events — including the
    // ones carrying the final target pitch — get dropped, so fast slides
    // land short. 0.5 ms steps still resolve far below a cent, so the floor
    // is inaudible while guaranteeing the slide always reaches the target.
    inline int getPitchBendStepSamples(double sampleRate, int stepMicros)
    {
        if (sampleRate <= 0.0)
            sampleRate = 48000.0;
        if (stepMicros <= 0)
            stepMicros = 1; // Maximum: evaluate every sample

        const int minStep = juce::jmax(1, (int)std::lround(sampleRate * 0.0005));
        return juce::jmax(minStep, (int)std::lround(sampleRate * (double)stepMicros / 1000000.0));
    }
}
