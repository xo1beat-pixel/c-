#pragma once

#include <JuceHeader.h>
#include <functional>
#include <thread>
#include "PluginProcessor.h"
#include "PianoRollComponent.h"

// TabbedComponent has no ChangeBroadcaster support, so a small subclass
// reports tab switches via currentTabChanged().
class TabbedPianoRollComponent : public juce::TabbedComponent
{
public:
    TabbedPianoRollComponent() : juce::TabbedComponent (juce::TabbedButtonBar::TabsAtTop) {}
    std::function<void(int)> onTabChanged;
protected:
    void currentTabChanged (int newIndex, const juce::String& newTabName) override
    {
        if (onTabChanged)
            onTabChanged (newIndex);
    }
};

// Small input/output VU meter bar (reads smoothed atomic levels written by
// the audio thread; repaints itself on a 30 Hz timer).
class VUMeterComponent : public juce::Component, public juce::Timer
{
public:
    explicit VUMeterComponent (WebDAWHostAudioProcessor& p) : processor (p) { startTimerHz (30); }

    void paint (juce::Graphics&) override;
    void timerCallback() override { repaint(); }

private:
    WebDAWHostAudioProcessor& processor;
};

class WebDAWHostAudioProcessorEditor : public juce::AudioProcessorEditor,
                                       public juce::DragAndDropContainer,
                                       public juce::ListBoxModel,
                                       public juce::ComponentListener,
                                       public juce::Timer
{
public:
    WebDAWHostAudioProcessorEditor (WebDAWHostAudioProcessor&);
    ~WebDAWHostAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    bool keyPressed (const juce::KeyPress&) override;
    void timerCallback() override;

    // --- ComponentListener (plugin editor size changes) ---
    void componentMovedOrResized (juce::Component&, bool, bool) override;

    // --- ListBoxModel (VST browser) ---
    int getNumRows() override;
    void paintListBoxItem (int rowNumber, juce::Graphics& g, int width, int height, bool rowIsSelected) override;
    void listBoxItemClicked (int rowNumber, const juce::MouseEvent&) override;
    void listBoxItemDoubleClicked (int rowNumber, const juce::MouseEvent&) override;

private:
    WebDAWHostAudioProcessor& audioProcessor;
    juce::LookAndFeel_V4 lookAndFeel;

    // UI Components
    TabbedPianoRollComponent tabs;

    // A placeholder for the hosted plugin's editor
    std::unique_ptr<juce::Component> pluginEditorComponent;
    juce::TextButton loadPluginButton;
    juce::TextButton scanButton;
    juce::TextButton browseButton;
    juce::TextButton scanPathsButton;
    juce::TextButton undoButton;
    juce::TextButton redoButton;
    juce::String redoPluginPath; // plugin path to restore with Redo (set by Undo)

    // VST3 browser
    juce::TextEditor vstSearchBox;
    juce::ComboBox categoryCombo;   // "All Plugins" / "★ Favorites" category filter
    juce::TextButton favouriteButton; // toggles the selected plugin's favourite state
    juce::Label scanStatusLabel;   // shows the result of the last scan (count / hint)
    juce::Label loadedPluginLabel; // shows the currently loaded VST3 (if any)

    // ListBox subclass that tracks the hovered row so paintListBoxItem can
    // render a hover highlight (ListBoxModel has no hover callback).
    class BrowserListBox : public juce::ListBox
    {
    public:
        int hoveredRow = -1;

        // "Glass" backdrop for the VST browser: a translucent vertical
        // gradient over the page background (the list background colour is
        // set fully transparent), plus 1px frosted edge highlights, so the
        // panel reads as a pane of glass instead of a flat dark slab.
        void paint (juce::Graphics& g) override
        {
            auto b = getLocalBounds().toFloat();
            juce::ColourGradient glass (juce::Colour (0xd80e131a), 0.0f, 0.0f,
                                        juce::Colour (0xa80e131a), 0.0f, b.getHeight(), false);
            g.setGradientFill (glass);
            g.fillAll();
            juce::ListBox::paint (g);
            g.setColour (juce::Colour (0x26ffffff));
            g.drawHorizontalLine (0, 0.0f, b.getRight());
            g.setColour (juce::Colour (0x2affffff));
            g.drawVerticalLine ((int) b.getRight() - 1, 0.0f, b.getBottom());
        }

        void mouseMove (const juce::MouseEvent& e) override
        {
            const int row = getRowContainingPosition (e.x, e.y);
            if (row != hoveredRow)
            {
                hoveredRow = row;
                repaint();
            }
            juce::ListBox::mouseMove (e);
        }

        void mouseExit (const juce::MouseEvent&) override
        {
            if (hoveredRow >= 0)
            {
                hoveredRow = -1;
                repaint();
            }
        }
    };

    BrowserListBox vstBrowserList;
    juce::StringArray vstPluginPaths;    // all discovered .vst3 paths
    juce::StringArray vstFilteredPaths;  // search-filtered (+ favourites first)
    juce::StringArray favouritePaths;    // favourited .vst3 paths
    juce::File favouritesFile;

    // File choosers need to be member variables in modern JUCE
    std::unique_ptr<juce::FileChooser> fileChooser;
    std::unique_ptr<juce::FileChooser> pathChooser;

    // User-defined scan folders (persisted)
    juce::StringArray scanPaths;
    juce::File scanPathsFile;
    void openScanPathsDialog();
    void loadScanPaths();
    void saveScanPaths();

    // Resizable + foldable VST browser panel: a draggable divider strip sits
    // between the plugin list and the hosted editor. Drag to resize, click to
    // collapse/expand, double-click to reset to the default width.
    class PanelDivider : public juce::Component
    {
    public:
        explicit PanelDivider (WebDAWHostAudioProcessorEditor& owner) : ownerRef (owner)
        {
            setMouseCursor (juce::MouseCursor::LeftRightResizeCursor);
        }
        void paint (juce::Graphics&) override;
        void mouseDown (const juce::MouseEvent&) override;
        void mouseDrag (const juce::MouseEvent&) override;
        void mouseUp (const juce::MouseEvent&) override;
        void mouseDoubleClick (const juce::MouseEvent&) override;
    private:
        WebDAWHostAudioProcessorEditor& ownerRef;
        int dragStartScreenX = 0; // screen X at mouseDown (stable during drag)
        int dragStartWidth = 0;
        bool mouseDownCollapsed = false; // was the panel folded when the drag started?
    };

    std::unique_ptr<PanelDivider> panelDivider;
    int browserPanelWidth = 280;        // current panel width (message thread only)
    bool browserPanelCollapsed = false; // panel folded away (message thread only)
    bool isResizingBrowserPanel = false; // true while the divider is being dragged
    void setBrowserPanelCollapsed (bool collapsed);

    // Custom Piano Roll
    PianoRollComponent pianoRoll;

    // Top utility strip: render, MIDI clock toggle, plugin GUI, VU meters.
    juce::TextButton renderButton;
    juce::TextButton dragWavButton;
    juce::TextButton midiClockButton;
    juce::TextButton pluginGuiButton;
    void togglePluginGui();
    juce::Label renderStatusLabel;
    std::unique_ptr<VUMeterComponent> vuMeter;
    std::unique_ptr<juce::FileChooser> renderChooser;
    std::thread renderThread;
    bool isRendering = false;
    void startRender (const juce::File& destFile);
    void startDragRender();
    void loadPluginFromPath (const juce::String& path, bool showGui = true);
    bool pendingAutoShowGui = false; // open the GUI when the warm load finishes
    bool pluginGuiShown = false;     // OUR visibility state (native VST3 windows ignore Component::isVisible)
    bool sizeTrackingActive = false; // window-size memory starts after the constructor
    int lastSavedW = 0, lastSavedH = 0;
    // The hosted plugin editor's NATURAL size (captured right after creation,
    // before our layout squeezes it) — used to grow the window to fit it.
    int pluginNaturalW = 0, pluginNaturalH = 0;
    void capturePluginEditorNaturalSize();

    void loadKontakt();
    void unloadPlugin();
    void redoLoad();
    void updateHostState();
    void scanVst3Folders();
    void rebuildVstBrowserList();
    void fitWindowToPluginEditor(); // grow the host window so the plugin editor is fully visible
    void updateFavouriteButtonState();
    bool isFavourite (const juce::String& path) const;
    void toggleFavourite (const juce::String& path);
    void loadFavourites();
    void saveFavourites();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (WebDAWHostAudioProcessorEditor)
};
