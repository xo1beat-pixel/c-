# WebDAW VST Host — fixed project

Verified against JUCE 8.0.13 (MSVC-compatible). All four build fixes plus the
Legato feature, faster Ctrl+wheel zoom, and the note-colour picker are
included in this project.

## Remember the open tab

The editor now remembers which tab was active (VST Host or Piano Roll) and
restores it on reopen — persisted as `hostTabIndex` in global settings
(global preference, like the theme). No more always jumping back to the Host
tab.

## Razor selection is undoable

Undo/redo snapshots now include the **razor selection box** (position, size,
pitch range) alongside the notes. Undoing a razor edit (stretch, move,
delete, **edge resize**) restores both the notes AND the selection area to
its pre-edit state; redo moves both forward again. The plain (no-Alt) edge
resize now snapshots the selection on drag start, so Ctrl+Z undoes a box
resize too.

## Razor area time-stretch (Alt + edge drag)

The razor selection now supports **content time-stretch**: hold **Alt** and
left-drag the razor area's left or right edge (amber handle bars) — all notes
inside the region scale with the new edge (positions AND durations). Example:
drag a 2-bar region down to 1 bar = double time; drag 1 bar out to 2 = half
time. Left/right edges snap to the grid; plain (no-Alt) edge drag still just
resizes the selection box, and the existing move/resize/delete behaviors are
unchanged. Undoable like the razor move (snapshot + undo history).

## Note borders (reference look)

Note rectangles now draw a **full-opacity darker outline** (was 55% alpha,
nearly invisible), so notes read as solid blocks with a clearly defined
darker-green edge, matching the reference style.

## Toolbar rearrangement

Toolbar buttons are now laid out in **logical groups** with consistent
8px gaps and separators between groups: `[Draw Select] | [Grid Vel] |
[Drag MIDI] | [Pitch PB] | [Legato Scale (Shape) Theme Panic]` (right group
anchored). Positions are computed in `resized()` from the window width
instead of hard-coded X values, and the separators follow the laid-out
button rects so they never drift out of alignment.

## Crisper rendering (pixel-snapped lines)

All grid lines (bars/beats/sub-beats), row separators, ruler ticks and
velocity-lane lines are now snapped to the pixel grid (half-pixel offset),
so 1px lines render crisp instead of being anti-aliased across two pixels.
Verified: no `setBufferedToImage` anywhere (only `setOpaque(true)`, which
helps performance), and DPI handling stays with JUCE's default per-monitor
pipeline.

## Grid Bg override actually shows

With a custom Grid Bg colour set, every derived surface (key rows, keys,
toolbar, grid lines, velocity lane) now uses a much smaller brightening
step, so the chosen colour dominates — setting pure black now renders a
near-black piano roll instead of the rows washing out to mid-grey.

## Clean-UI pass (based on the MIDISketch reference)

- **Toolbar**: buttons are now flat and borderless; only the active button is
  tinted with the single theme accent (subtle fill + accent text + 2px accent
  bar). Vel no longer uses its own red/amber accent. New icons for Grid,
  Pitch, Theme and Panic (pencil/cursor/vel icons already existed).
- **Grid**: line brightness and opacity lowered everywhere (bars/beats/
  sub-beats in both the piano roll and the velocity lane) so the grid
  recedes behind the notes.
- **Ruler**: measure numbers only render when bars are wide enough (no more
  overlapping numbers when zoomed out); smaller fonts and softer colours for
  measure/beat/sub-beat numbers.
- **In-note names**: now OFF by default (the clean look). A show/hide toggle
  (◉/○ eye button) was added to the Note Name row in the theme panel,
  alongside the existing B bold toggle, colour swatch and Reset. Persisted as
  `showNoteNames` in global settings.

## Theme tweaks persist across close/reopen

All theme adjustments (theme index, colours, grid line thicknesses, text
colours/bold, font typeface) are now **global preferences only**: they are
saved to `%APPDATA%/WebDAWHost/settings.xml` and restored in the processor
constructor. `setStateInformation` no longer restores them from the DAW
project, so a project saved before a theme change can no longer overwrite
the most recent adjustments when the VST is reopened. Project content
(notes, loops, view position, tool/visibility flags, scale, pitch settings)
still round-trips through the project state as before.

## Theme tweaks — note-name & toolbar text styling

The theme tweaks panel gains a **Font** dropdown (Segoe UI / Arial / Georgia
/ Consolas / Verdana / Tahoma / Trebuchet MS / Times New Roman / Courier New
/ Impact / Comic Sans MS) that retypes all piano-roll text — toolbar labels,
ruler numbers, key names, in-note names, panel labels — plus three rows —
**Note Text** (note names on the keys), **Toolbar Text** (toolbar
labels/icons) and **Note Name** (the note name inside each note, e.g. "C4")
— each with a **B** bold toggle, a colour swatch (opens the live colour
selector) and a Reset button back to the default. Persisted as
`fontTypeface`, `noteTextColour` / `noteTextBold` / `toolbarTextColour` /
`toolbarTextBold` / `noteNameColour` / `noteNameBold` in global settings
and project state (0 colour = theme default).

The panel now has 18 rows and **scrolls with the mouse wheel** when they
don't fit the window (title/divider scroll along with the rows; the scroll
resets when the panel is reopened). Files touched: `PluginProcessor.h/.cpp`,
`PianoRollComponent.h/.cpp`.

## Ruler loop highlight — no longer covers the numbers

The loop highlight on the ruler previously painted an opaque dark bar over the
ruler numbers. It now dims the ruler **outside** the loop (same treatment as
the grid and velocity lane), draws green boundary lines at the loop edges, and
keeps the arrow markers and end flag — the numbers stay fully readable inside
the loop region. Files touched: `PianoRollComponent.cpp`.

## Theme tweaks — per-type grid line thickness

The single "Grid Line Thickness" slider is now **three mini-sliders** in one
row of the theme tweaks panel (Theme button): **Sub-beat**, **Beat** and
**Bar** (measure) line thickness, each a 0.5x–3.0x multiplier of its line
width. The main grid and the velocity lane use them independently
(`1.6x/0.9x/0.5x` bar/beat/sub-beat base widths). Values are persisted in
global settings and project state; older saves with a single
`gridLineThickness` are migrated to all three (new attribute names:
`gridSubBeatThickness`, `gridBeatThickness`, `gridBarThickness`; the legacy
attribute is still written as the bar value so older builds keep working).

Files touched: `PluginProcessor.h/.cpp`, `PianoRollComponent.h/.cpp`.

## UI refresh — VST Host tab

- **Undo / Redo for loading**: the old "Unload" button is now **Undo** (red,
  full-width, bottom of the VST browser, visible while a plugin is loaded) —
  it unloads the plugin and remembers what was loaded. A **Redo** button
  (green) takes its place after an undo and reloads that plugin. Loading a
  different plugin clears the redo history. Keyboard shortcuts work on the
  VST Host tab: **Ctrl+Z** = undo (unload), **Ctrl+Shift+Z / Ctrl+Y** = redo
  (reload). The processor exposes `getHostedPluginPath()` so a plugin restored
  from a saved state can also be redone.
- **Better button arrangement**: **Load** is now the primary action and
  stretches to fill the bottom row; **Browse… / Scan / Paths…** are secondary
  (neutral dark fill) fixed-width buttons; the **Undo** row sits below them.
- **Loaded indicator**: a "Loaded: <plugin name>" row appears above the list
  while a plugin is loaded (teal, bold).
- **Browser design**: hover highlight on rows, left accent bar + tinted
  selection, restyled search box (focus outline), dark combo popup, styled
  scrollbar, gold star toggle for favourites (turns gold when the selected
  plugin is favourited).

Files touched: `PluginEditor.h/.cpp`.

## Other features

- **Colour pickers** — in the theme tweaks panel (Theme button): "Note
  Color" and "Pitch Line Color" swatches open colour selectors; notes and
  pitch curves recolor live (velocity/contrast shading still applies).
  "Reset" returns each to the theme accent. Both persisted in global
  settings + project state.
- **Faster zoom** — Ctrl+wheel / Ctrl+Shift+wheel zoom multiplicatively
  (x1.25 per notch) instead of the old fixed pixel step.
- **Legato mode remembered instantly** — saved synchronously on click;
  restored from global settings + project state.

## Feature — Legato note modes

A **Legato** button was added to the piano-roll toolbar (right side, next to
the scale-lock button). Click it to cycle through three modes:

- **Legato** (off) — normal pitch-bend: every note-on snaps the wheel to the
  note's start pitch.
- **Legato: mono** — monophonic legato: the new note **cuts** the previous
  note's sustain (note-off sent ~5 ms early at the new note-on so the new
  note doesn't choke, its channel reused).
- **Legato: rtn** (return legato) — **like mono** (the top note cuts the
  previous note's voice), but when the top note ends, the cut note is
  **retriggered at its own start pitch** — **only if it is still held**
  (its end is after the top note's end); otherwise it stays silent.
  E.g. a long C + overlapping D: D cuts C and plays; when D ends, C is
  retriggered and rings until its own end.

**Every note-on ALWAYS resets the pitch wheel to the note's own start pitch**
(the value of its first pitch point, usually 0) — legato modes only control
note cutting/retriggering, they never carry the wheel over from the previous
note, so the pitch points at the start of each note are always honored.
The old "poly" legato mode (overlap + pitch glide) was removed.

Works in both bend modes (shared channel-1 wheel and MPE per-note wheels).
The state is persisted (project state XML + global settings; older saved
states migrate automatically: poly -> off, mono 2->1, rtn 3->2).

Files touched: `PluginProcessor.h/.cpp` (engine), `PianoRollComponent.h/.cpp`
(button).

---

# Build fixes applied

## Fix 1 — error C1083: Cannot open include file: 'JuceHeader.h'

`JuceHeader.h` is auto-generated per target. The project never called
`juce_generate_juce_header()`, so the file was never created and the generated
include path was never added.

**File:** `CMakeLists.txt` — added after the `juce_add_plugin(...)` block:

```cmake
juce_generate_juce_header(WebDAW_VST_Host)
```

## Fix 2 — error C2280: 'AudioPluginFormatManager::addDefaultFormats()': attempting to reference a deleted function

JUCE 8.0.11 removed `AudioPluginFormatManager::addDefaultFormats()` (declared
`= delete`; the format manager moved to the new `juce_audio_processors_headless`
module). The replacement is the free function `addDefaultFormatsToManager()`
(registers all standard formats **with** UI support).

**File:** `PluginProcessor.cpp` (constructor) — replaced:

```cpp
formatManager.addDefaultFormats();
```

with:

```cpp
addDefaultFormatsToManager(formatManager);
```

No CMake change was needed for this one — the headless module is pulled in
automatically as a dependency of `juce_audio_processors`.

## Fix 4 — error C1189 (#error) in juce_audio_plugin_client_VST3.cpp:
"conflict with parameter automation between VST2 and VST3"

JUCE enables `JUCE_VST3_CAN_REPLACE_VST2` by default and #errors if the
plugin doesn't opt into the VST2-compatible parameter-ID scheme. This
plugin ships VST3 only (no VST2 version, VST2 hosting disabled), so the
flag is unnecessary.

**File:** `CMakeLists.txt` — added to `target_compile_definitions(WebDAW_VST_Host PUBLIC ...)`:

```cmake
JUCE_VST3_CAN_REPLACE_VST2=0
```

Also added `JUCE_USE_CURL=0` (the plugin does no networking; avoids a
libcurl link dependency — matches the WaveEditor project).

**File:** `PianoRollComponent.cpp` (tooltip width, line ~1177) — replaced:

```cpp
tipFont.getStringWidth(hoveredToolbarHint)
```

with:

```cpp
juce::GlyphArrangement::getStringWidth(tipFont, hoveredToolbarHint)
```

`GlyphArrangement::getStringWidth(const Font&, StringRef)` is the JUCE-
recommended replacement (static, returns float).

## Build

```powershell
cmake -S . -B build
cmake --build build --config Release --target WebDAW_VST_Host
```

(The `CMAKE_GENERATOR_PLATFORM will be ignored` warnings are harmless.)

---

# Bug fixes — stuck notes on sustain (v3 follow-up)

## Fix 5 — notes retuned while playing never release (stuck until Panic)

**Symptom:** press play, then drag/transpose notes while they are sounding;
after pressing stop the notes keep ringing until Panic.

**Cause:** the UI drag rewrites `NoteEvent.midiNote` in place, but the note-on
was already sent at the OLD pitch. Every note-off path sent
`noteOff(channel, midiNote)` — the new pitch — which never matched the ringing
voice, so the instrument held it forever.

**Fix:** `NoteEvent` gains `int soundingMidiNote` (the pitch actually sent at
note-on, set in both note-on paths including the return-legato retrigger), and
all note-off paths (stop, playhead jump, note end x2, legato cut, channel
steal, unload, stopped-transport branch) now send `noteOffPitch(note)` = the
sounded pitch (falling back to `midiNote` for notes that never sounded).

## Fix 6 — legato mode: chords keep ringing after stop

**Symptom:** with Legato (mono or rtn) enabled, playing a chord and pressing
stop leaves the chord sustained until Panic. Legato off = normal.

**Cause:** the legato "cut" emits the old note's note-off ~5 ms before the new
note's onset. When the cut note and the cutting note start in the SAME audio
block (the notes of a chord), the cut note's note-on is also emitted in that
block, at `sampleOffset + 1` — but the cut note-off was placed at sample 0,
i.e. BEFORE the note-on. The instrument sees off → on, so the cut voice starts
ringing while the sequencer has already marked it not-playing: no note-off is
ever sent for it. On stop only the still-"playing" notes are released, so the
orphaned chord voices hang until Panic.

**Fix:** the legato cut sample is now clamped to at least 2 samples AFTER the
cut note's own onset
(`jmax(sampleOffset - earlyCutSamples, n2OnsetSample + 2)`), which is strictly
after the cut note's note-on (`sampleOffset + 1` in legato, where the backlog
is empty). Chord notes still cut correctly (last-triggered note wins), but the
cut note-off always lands after the note-on, so every voice gets its release.

Files touched: `PluginProcessor.h`, `PluginProcessor.cpp`.

## Fix 7 — selected notes highlight too strongly

**Symptom:** clicking a note lights it up excessively.

**Cause:** the selection tint in `getNoteColour()` used `base.brighter(0.4f)`,
which pushes every RGB channel 40 % of the way to white — a saturated theme
green became a pale washed-out green.

**Fix:** reduced to `brighter(0.12f)` — a clear but subtle lift; the note
keeps its colour identity. (The velocity-lane lollipop keeps its white
selected head as the explicit "this note is selected" marker.)

File: `PianoRollComponent.cpp`.

## Fix 8 — changing the global pitch shape re-shapes already-drawn curves

**Symptom:** switching the global Shape mode (Linear/Square/Smooth/…)
immediately changed every already-drawn pitch-bend curve to the new mode.

**Cause:** every node created by drawing was written with `shape = 0`
("auto"). Auto nodes with no tension fall back to the GLOBAL shape at
evaluation time, so a global change silently re-shaped all existing curves.

**Fix:** per-node shapes are now BAKED at creation time:
- New nodes (and the seeded start point of a new curve) get
  `shape = globalMode + 1` (explicit Linear/Square/Smooth/Ease In/Ease Out/
  Sine), so each curve keeps the shape it was drawn with.
- On project load, plain auto nodes (`shape == 0`, no tension) are baked once
  to the shape they are currently rendered with, freezing existing curves;
  tension-driven nodes are left alone (tension already overrides the global
  mode).
- The first bend point drawn on a fresh curve also re-bakes its start point
  to the CURRENT mode, so a curve started after switching modes uses the new
  mode for its whole first segment.
- Explicit per-node shapes set via the C menu still win (unchanged), and MIDI
  export / real-time playback both use the same evaluation, so frozen curves
  play exactly as drawn.

File: `PianoRollComponent.cpp`.

---

# Experimental UI features (backup taken before these: WebDAW-halfbeat-grid-slider-backup-pre-experiments.zip)

## Feature A — Drag-preview ghost

While moving notes (Select tool, plain Move drag), the ORIGINAL position of
every dragged note is shown as a dim accent outline (faint fill + 1.3 px
outline), so you see exactly how far you've dragged. The ghost comes from the
drag-start snapshot (`selectedNotesDragState`) — it stays put while the live
notes move, and disappears on mouseUp. Not shown for marquee/resize/velocity/
Alt-copy drags. Files: `PianoRollComponent.h/.cpp`.

## Feature B — Pitch-curve drag handles & context cursors

- Node grab radii now grow when zoomed out (small keyHeight): `x1.35` below
  14 px key height with a ~9 px floor, in BOTH the click-grab test and
  `findPitchNodeAtMouse`, so nodes stay easy to grab when notes are thin.
- Cursor feedback in pitch mode: open hand over a node, left/right resize on
  a note edge, crosshair over the curve line (add node / Alt tension drag),
  normal elsewhere. The node hit-test in mouseMove is inline (mouseMove
  already holds noteLock, so the locked `findPitchNodeAtMouse` can't be
  called there). File: `PianoRollComponent.cpp`.

## Feature C — Adaptive grid density (level-of-detail)

Grid lines fade out as they get denser when zoomed out — no more wall of
lines. Sub-beat lines fade to zero below ~12 px/beat, half-beats below
~18 px/beat, beats and bars get a mild fade at very low zoom; each factor is
1.0 at the default zoom (40 px/beat) so nothing changes for normal use.
Lines below ~2 % alpha are skipped entirely (also a small paint win on huge
zoomed-out projects). The velocity lane gets the same treatment. File:
`PianoRollComponent.cpp`.

## Feature D — Animated transitions

- Wheel scroll and Ctrl+wheel zoom now ease smoothly to their targets
  (exponential lerp in the 60 Hz timer, ~230 ms settle) instead of jumping;
  Ctrl+wheel zoom still centers on the cursor. Programmatic view sets
  (state restore, layout) stay instant.
- A freshly placed note (Draw tool) flashes briefly (white fill + outline,
  decays over ~0.4 s in the timer) so placement is visible at a glance.
  Files: `PianoRollComponent.h/.cpp`.

## Feature E — Glass panel for the VST browser

The VST3 browser list now reads as a pane of glass: a translucent vertical
gradient backdrop (drawn in the BrowserListBox paint override, over the
page background), fully transparent list background and scrollbar, plus
1 px frosted top/right edge highlights. Rows keep their translucent
selection/hover tints, so readability is unchanged. Files:
`PluginEditor.h/.cpp`.

## Feature B — REVERTED (experiment rolled back)

The pitch-curve hit-radius changes and the context cursors from Feature B
have been reverted to the original behaviour (fixed 7px grab radius + 6px
click grab; no cursor override in pitch mode). The other features (A, C, D,
E) are unchanged.

## Feature A — fix: ghost removed on mouse release

The ghost flag was already cleared in mouseUp, but the component wasn't
repainted there, so the last frame (with the ghost) lingered until the next
repaint. mouseUp now calls repaint() immediately after clearing it, so the
ghost disappears the moment the mouse is released.

## Feature D — tweak: Ctrl+wheel zoom sped up

Ctrl+wheel horizontal zoom is now ~x1.8 per notch (was ~x1.5) so zooming in
and out feels faster.

## Feature — end endpoint marker removed

The pitch-curve renderer drew a filled "end guard" dot at the right edge of
every note (showing the curve value at release). Removed it — purely visual,
playback and release pitch are unchanged. The curve line itself still extends
to the note's end, and the start marker remains.

## Feature — resizable velocity-lane divider (theme slider removed)

- The velocity lane now has a draggable divider: grab the strip at the lane's
  top edge (cursor becomes up/down-resize, grip hint drawn centred above the
  edge) and drag to resize the lane between 30 and 500 px. The new height is
  persisted exactly like the old slider (pianoRollVelocityLaneHeight).
- The "Velocity Lane Height" slider has been REMOVED from the theme editor
  panel (it's redundant now — drag the divider instead).
- Files: PianoRollComponent.h/.cpp.

## Feature — pitch-curve thumbnails on notes

Notes that have a drawn pitch curve now show a tiny (~9px tall) mini-curve
INSIDE the note body, sampled from the same evaluatePitchBendAtBeat the
engine uses, so you can spot bends at a glance without entering pitch mode.
Shows when pitch mode is off and the note is big enough to contain it;
hidden automatically when pitch mode is on. File: PianoRollComponent.cpp.

## Feature — smooth note entrance (~100 ms fade-in)

Notes that APPEAR now fade in over ~6 ticks (~100 ms at 60 Hz) instead of
popping:
- Paste: the pasted notes fade in.
- Undo / redo: only the notes that actually appeared fade in — diffed against
  the previous state by (pitch, position, length), so undoing a delete or a
  move fades those notes, while velocity-only undo / pitch-curve undo leave
  everything solid.
- Freshly drawn notes (Draw tool) fade in as you start drawing.
- The entrance alpha multiplies the note's opacity (body + outline together);
  the timer ages the spawn marks out after ~100 ms and keeps repainting while
  fading. Files: PianoRollComponent.h/.cpp.

## Smooth note entrance — REMOVED (experiment rolled back)

Requested fade durations went 100ms -> 50ms -> 30ms -> 20ms -> 5ms. 5ms is
below the 60Hz repaint resolution (one tick ~17ms), i.e. visually identical
to no fade, so the whole feature was removed: no spawn tracking, no entrance
alpha, no timer aging. Notes appear instantly again. The note-placement
flash (separate feature) is unchanged.

## Feature — ghost pitch lines (replaces the mini-curve thumbnail)

- The tiny 10px "mini-curve" thumbnail inside notes is GONE.
- Instead, when pitch mode is OFF, notes with a drawn bend now show their
  REAL pitch curve as a low-visibility ghost line (30 % alpha, same geometry
  and clamping as pitch mode) — you can see exactly where the bend goes
  without entering pitch mode.
- New "Ghost Pitch Lines" toggle button in the theme editor panel (blue when
  on, persisted via pianoRollGhostPitchLines in both config + project state).
  Hidden automatically in pitch mode regardless of the toggle.
- Files: PluginProcessor.h/.cpp, PianoRollComponent.h/.cpp.

## Feature — ghost line visibility slider

The theme editor's "Ghost Pitch Lines" row now also has a slider right next
to the button (5-70 %, default 30) that adjusts the ghost line opacity live.
Persisted as pianoRollGhostPitchLineOpacity in both config + project state.
File: PluginProcessor.h/.cpp, PianoRollComponent.h/.cpp.

## Bug fix — pan after animated zoom "snaps back / jumps"

Ctrl+wheel zoom leaves a ~200ms easing animation running (view lerping toward
its target). Starting a middle-button (or Alt+drag) pan during that window
fought the animation: the timer kept easing the view back to the old zoom
target while the pan dragged it away, causing the snap-back/jump. The pan
start now cancels the animation first (and the pan drag re-cancels as a
safety), so panning is immediate and stable. File: PianoRollComponent.cpp.

## Feature — snap-to-scale menu on the Scale button

The Scale button's right-click menu (Root Note / Scale Type) now has a
separator + three snap actions that tune the ALREADY-DRAWN content onto the
scale:
- "Snap Notes to Scale (selected)" — moves selected notes' pitches to the
  nearest scale degree (disabled when nothing is selected).
- "Snap Pitch Bends (selected notes)" — snaps the bend nodes of selected
  notes' curves to the scale.
- "Snap Pitch Bends (all notes)" — same for every note with a drawn curve.
Undoable, bumps the paint revision, uses the CURRENT root/scale even if
scale lock is off (explicit action). Tie-breaking matches the existing
drag-snap (lower note wins). File: PianoRollComponent.h/.cpp.

## UI polish — menus & buttons redesign

New shared WebDAWLookAndFeel.h (LookAndFeel_V4 subclass) applied to all
popup menus and the theme-panel TextButtons:
- Popup menus (scale, global shape, pitch-bend resolution, pitch segment
  shape incl. submenus, VST browser menu): soft vertical gradient panel,
  hairline border, faint top highlight, rounded accent-tinted hover pills,
  accent checkmarks, styled separators (fade-out lines), dim section
  headers, right-aligned shortcut text, sub-menu chevrons, bolder ticked
  text.
- Toolbar buttons (drawToolbarButton): modern chips — 6px radius, subtle
  vertical gradient, hairline accent-tinted border, hover glow ring, rounded
  bottom accent bar when active, brighter hover text.
- Theme-panel TextButtons (B toggles, note-name show, ghost-pitch-lines):
  rounded gradient buttons with hover/pressed/toggled states via
  drawButtonBackground.
Files: WebDAWLookAndFeel.h (new), PianoRollComponent.cpp, PluginEditor.cpp,
CMakeLists.txt.

## Feature — note name size slider

The theme editor now has a "Note Name Size" slider (8-20 px, default 11,
label drawn above the slider) that controls the font size of note names
INSIDE the notes, replacing the hardcoded 11 px. Persisted as
pianoRollNoteNameFontSize in config + project state. Files:
PluginProcessor.h/.cpp, PianoRollComponent.h/.cpp.

## Feature — more font styles

The theme panel Font combo now offers 19 typefaces (was 11): added Palatino
Linotype, Lucida Console, Century Gothic, Franklin Gothic Medium, Garamond,
Rockwell, Bahnschrift, Candara. getModernFont cases 11-18; persisted range
widened to 0-18. Files: PianoRollComponent.cpp, PluginProcessor.cpp.

## Fix — note flash appears at creation, not release

The white placement flash on newly drawn notes used to fire on mouse RELEASE
(after the whole drag). It now fires the moment the note first appears
(mouseDown), and the paint cache is refreshed at the same time so the flash
renders on the very first frame. File: PianoRollComponent.cpp.

## Feature — razor selection colour (theme editor)

The razor edit selection area (fill + border) now uses a themeable colour.
The theme panel gained a "Razor Select" colour swatch + Reset row (opens the
standard colour picker; reset returns to the default teal). The fill is the
chosen colour at 14% alpha, the border at full alpha; the amber stretch
handles and "SELECT" label are unchanged. Persisted as pianoRollRazorColour
(config + project state). Files: PluginProcessor.h/.cpp,
PianoRollComponent.h/.cpp.

## CRITICAL FIX — build error C2065/C2059 cascade in PianoRollComponent.cpp

The razor-colour edit left a stray duplicated `repaint(); return; }` block in
mouseDown's theme-panel handling, which closed mouseDown early. Every
statement after it parsed at namespace scope, producing the huge error
cascade (C2059 at 2613, C2065 'Move', C4430, redefinitions, etc.).
Removed the stray block — brace balance verified (606/606, no negative
depth) and the same check run on all other files (all 0).

## Feature — more font styles (29 total)

Added 10 more Windows-bundled typefaces: Segoe Script, Segoe Print, Bookman
Old Style, Lucida Handwriting, Monotype Corsiva, Papyrus, Bauhaus 93,
Algerian, Broadway, Britannic Bold. getModernFont cases 19-28; combo items
20-29; persisted range widened to 0-28.

## Fix — font styles 24-28 did nothing

Papyrus / Bauhaus 93 / Algerian / Broadway / Britannic Bold are
Office-pack / single-weight decorative fonts: on a base Windows install JUCE
can't resolve them (or their bold style) and silently falls back to the
default font, so picking them changed nothing. Replaced those 5 slots with
guaranteed base-Windows fonts that have real bold weights: Cambria, Calibri,
Constantia, Corbel, Microsoft Sans Serif. File: PianoRollComponent.cpp.

## Feature — visual redesign pass (backup: WebDAW-halfbeat-grid-slider-backup-pre-visual-redesign.zip)

Per the mockup direction:
- Notes: rounded-TOP-only corners (square bottom), soft drop shadow (2px,
  alpha-scaled), velocity-driven shading (brighter = higher velocity,
  capped boost), thin bright 1px top edge, and a soft double-stroke accent
  glow ring on selected notes.
- Playhead: now has a soft 32px gradient beam around the line.
- Grid: subtle alternate-bar background banding (odd bars get a faint lift).
File: PianoRollComponent.cpp.

## Fix — low velocity notes turned red

Warm theme colours (Amber/Rose) darkened toward reddish-brown at low
velocity because darker() scales RGB toward black while keeping the red-heavy
ratio. Velocity now also fades SATURATION (0.35 at vel 0 -> 1.0 at vel 127),
so notes go darker and darker toward grey/black instead of turning red.
Applies to grid notes and velocity-lane lollipops (both use getNoteColour).

## Feature — design batch 2 (backup: WebDAW-halfbeat-grid-slider-backup-pre-design-batch.zip)

Applied from the design suggestion list (items already present were skipped:
playhead ruler tick, unified 12px panel corners, velocity-lane gradient):
- Canvas vignette: faint black 12% gradients at all four grid edges (70/90px
  fades) — soft-focus frame.
- Chord grouping: notes starting on the same beat get a faint accent pill
  behind them so chords read as clusters.
- Ruler diagonal shimmer: 3% white diagonal lines across the ruler strip.
- Note shadows now tinted with a very dark version of the theme accent
  instead of pure black (cohesive per theme).
- Selected-note counter chip: a small "N notes" pill at the top-right of the
  grid when 3+ notes are selected.
File: PianoRollComponent.cpp.

## Reverted — chord grouping pill

The faint "chord cluster" pill behind same-beat notes was removed (user
preference). The other design-batch 2 items (vignette, ruler shimmer, tinted
shadows, selection chip) remain.

## Feature — design batch 3 (backup: WebDAW-halfbeat-grid-slider-backup-pre-design-batch3.zip)

- Velocity heat bar: thin blue->teal->amber ramp along the bottom edge of
  each note (velocity-coded).
- Playing-key lamp: keys whose note is currently sounding get a faint accent
  tint (while transport runs).
- Octave banding: very faint white lift on C rows for pitch orientation.
- Measure beads: tiny dots under the ruler numbers at every measure.
- Ruler measure numbers now right-aligned at the bar line.
- Zoom-level chip: "N px/beat" pill shown briefly while Ctrl+wheel zooming.
- Note tail fade: subtle darker gradient at the right edge of long notes.
- Velocity-lane divider: grip lines replaced with three grip dots.
- Ambient selection glow: soft radial accent spotlight behind selected notes.
File: PianoRollComponent.h/.cpp.

## Reverted — ambient selection glow

The radial accent spotlight behind selected notes was removed (user
preference). The rest of design batch 3 remains (heat bar, key lamp, octave
banding, measure beads, number alignment, zoom chip, tail fade, grip dots).

## Reverted — zoom-level chip

The "px/beat" pill shown while Ctrl+wheel zooming was removed (user
preference). Rest of design batch 3 remains.

## Feature — workflow batch (backup: WebDAW-halfbeat-grid-slider-backup-pre-feature-batch.zip)

1. Double-click the RULER zooms to fit the whole arrangement (animated,
   2 beats of padding; empty project -> 16 beats).
2. Keyboard nudge: Ctrl+Left/Right moves the selection by one grid snap,
   Alt+Up/Down transposes by half-steps (undoable, works on all selected).
3. Velocity ramp: during a velocity-lane drag, the note under the cursor
   takes the exact mouse value while notes farther away horizontally stay
   closer to their original velocity — drag diagonally to create a smooth
   crescendo/decrescendo across notes (flat-setting still works when you
   drag straight up/down).
4. Note tail handle: hovering the right edge of a note shows a subtle
   accent grip on its tail (resize affordance; cursor already changes).
Files: PianoRollComponent.h/.cpp.

## Feature — Ctrl+click key selects all notes on that row

Ctrl+clicking a piano key on the left selects every note with that pitch
(replacing the current selection); plain click still previews the note sound.
File: PianoRollComponent.cpp.

## Fix — velocity drag now follows the cursor position

Velocity edits are now ABSOLUTE: while dragging in the velocity lane, the
value applied equals the velocity at the mouse cursor's vertical position
(top = 127, bottom = ~1) — same mapping as the click handler. Previously the
drag was delta-based (start value + vertical movement), which drifted from
the cursor on multi-note ramps. The horizontal ramp still works (note under
cursor = exact value; others interpolate). File: PianoRollComponent.h/.cpp.

## Reverted — velocity ramp

The horizontal interpolation (ramp) was removed entirely. Velocity edits are
now strictly flat absolute: click and drag, and every affected note takes the
velocity at the mouse cursor's vertical position. Files:
PianoRollComponent.h/.cpp.

## Fix — velocity drag: smooth on head-grab, jump otherwise

- Clicking a lollipop no longer changes the velocity instantly.
- If the drag STARTS ON a lollipop (stem column): smooth relative drag — each
  note moves up/down from its own original velocity (no jump).
- If the drag starts ANYWHERE ELSE in the lane (or in a selected note's time
  range): the velocity jumps to the mouse cursor's vertical position and
  follows it.
Files: PianoRollComponent.h/.cpp.

## CRITICAL FIX — velocity drag did nothing

The velocity mouseDown never set currentDragAction = EditVelocity (the
original code only changed velocity instantly on click, so the drag branch in
mouseDrag was dead code). The drag now starts properly: click and drag jumps
the velocity to the cursor position (stems / anywhere), and grabbing the
lollipop head adjusts it smoothly relative to its value. Files:
PianoRollComponent.cpp.
