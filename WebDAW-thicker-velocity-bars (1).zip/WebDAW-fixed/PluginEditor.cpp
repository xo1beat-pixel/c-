#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "WebDAWLookAndFeel.h"

#include <functional>
#include <cstdlib>

namespace
{
    constexpr juce::uint32 editorBg = 0xff13171c;
    constexpr juce::uint32 panelTop = 0xff13171c;
    constexpr juce::uint32 panelBottom = 0xff13171c;
    constexpr juce::uint32 outline = 0xff1c2128;
    constexpr juce::uint32 blueAccent = 0xff22c55e;
    constexpr juce::uint32 tealAccent = 0xff4ade80;

    class HostPageComponent : public juce::Component
    {
    public:
        void paint(juce::Graphics& g) override
        {
            juce::ColourGradient bg(juce::Colour(editorBg).brighter(0.02f), 0.0f, 0.0f,
                                    juce::Colour(editorBg), 0.0f, (float)getHeight(), false);
            g.setGradientFill(bg);
            g.fillAll();

            auto header = getLocalBounds().removeFromTop(58).toFloat();
            juce::ColourGradient headerFill(juce::Colour(panelTop), header.getX(), header.getY(),
                                            juce::Colour(panelBottom), header.getX(), header.getBottom(), false);
            g.setGradientFill(headerFill);
            g.fillRect(header);
            g.setColour(juce::Colour(outline));
            g.drawLine(header.getX(), header.getBottom() - 1.0f, header.getRight(), header.getBottom() - 1.0f, 1.0f);

            g.setFont(juce::Font(15.0f, juce::Font::bold));
            g.setColour(juce::Colour(0xffe5edf7));
            g.drawText("Kontakt Wrapper Host", header.withTrimmedLeft(164.0f).withTrimmedRight(92.0f),
                       juce::Justification::centredLeft, false);

            auto badge = header.withWidth(62.0f).withX(header.getRight() - 78.0f).reduced(0.0f, 17.0f);
            g.setColour(juce::Colour(tealAccent).withAlpha(0.14f));
            g.fillRoundedRectangle(badge, 6.0f);
            g.setColour(juce::Colour(tealAccent).withAlpha(0.65f));
            g.drawRoundedRectangle(badge.reduced(0.5f), 6.0f, 1.0f);
            g.setColour(juce::Colour(0xffd9fff8));
            g.setFont(juce::Font(11.0f, juce::Font::bold));
            g.drawText("VST3", badge, juce::Justification::centred, false);
        }
    };
}

void VUMeterComponent::paint (juce::Graphics& g)
{
    auto bounds = getLocalBounds().toFloat();
    g.setColour (juce::Colour (0xff1c222b));
    g.fillRoundedRectangle (bounds, 4.0f);

    const auto barArea = bounds.reduced (6.0f, 5.0f);
    const float barW = 8.0f;
    const float gap = 10.0f;

    auto drawBar = [&] (const juce::String& label, float level, float x)
    {
        auto bar = barArea.withX (x).withWidth (barW);
        g.setColour (juce::Colour (0xff0f1317));
        g.fillRoundedRectangle (bar, 2.0f);

        const float h = bar.getHeight() * juce::jlimit (0.0f, 1.0f, level);
        auto fill = bar.withTop (bar.getBottom() - h);
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff4ade80), 0.0f, bar.getBottom(),
                                                 juce::Colour (0xff16a34a), 0.0f, bar.getY(), false));
        g.fillRoundedRectangle (fill, 2.0f);

        g.setFont (juce::Font (9.0f, juce::Font::bold));
        g.setColour (juce::Colour (0xff9ca3af));
        g.drawText (label, bar.withX (x - 22.0f).withWidth (20.0f), juce::Justification::centredRight, false);
    };

    drawBar ("IN",  processor.inputLevel.load(),  barArea.getX() + 24.0f);
    drawBar ("OUT", processor.outputLevel.load(), barArea.getX() + 24.0f + gap + barW);

    // Hosted-plugin latency in ms (the DAW compensates for it automatically).
    const double sr = processor.getSampleRate() > 0 ? processor.getSampleRate() : 48000.0;
    const double ms = processor.hostedLatencySamples.load() * 1000.0 / sr;
    g.setFont (juce::Font (9.0f));
    g.setColour (juce::Colour (0xff6b7280));
    g.drawText (juce::String::formatted ("Lat: %.1f ms", ms),
                barArea.withLeft (barArea.getX() + 54.0f), juce::Justification::centredLeft, false);
}

WebDAWHostAudioProcessorEditor::WebDAWHostAudioProcessorEditor (WebDAWHostAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p), tabs(),
      pianoRoll(p) // Initialize the piano roll with the processor reference
{
    lookAndFeel.setColour(juce::ResizableWindow::backgroundColourId, juce::Colour(editorBg));
    lookAndFeel.setColour(juce::TextButton::buttonColourId, juce::Colour(blueAccent));
    lookAndFeel.setColour(juce::TextButton::buttonOnColourId, juce::Colour(tealAccent));
    lookAndFeel.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffffffff));
    lookAndFeel.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
    // Dark context-menu theme (right-click on a plugin in the browser)
    lookAndFeel.setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff1a1f26));
    lookAndFeel.setColour(juce::PopupMenu::textColourId, juce::Colour(0xffe5edf7));
    lookAndFeel.setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(blueAccent).withAlpha(0.35f));
    lookAndFeel.setColour(juce::PopupMenu::highlightedTextColourId, juce::Colours::white);
    lookAndFeel.setColour(juce::TabbedComponent::backgroundColourId, juce::Colour(editorBg));
    lookAndFeel.setColour(juce::TabbedComponent::outlineColourId, juce::Colour(outline));
    lookAndFeel.setColour(juce::TabbedButtonBar::tabTextColourId, juce::Colour(0xffaeb8c6));
    lookAndFeel.setColour(juce::TabbedButtonBar::frontTextColourId, juce::Colour(0xffffffff));
    setLookAndFeel(&lookAndFeel);

    setResizable(true, true);
    // Min width 680 keeps every toolbar button (incl. right-anchored Panic) on screen.
    setResizeLimits(680, 420, 3840, 2160);

    // Setup Tabs
    addAndMakeVisible(tabs);
    tabs.setTabBarDepth(34);
    tabs.setColour(juce::TabbedComponent::backgroundColourId, juce::Colour(editorBg));
    tabs.setColour(juce::TabbedComponent::outlineColourId, juce::Colour(outline));

    // Tab 1: Hosted Plugin (VST browser + hosted editor)
    auto* hostContainer = new HostPageComponent();

    // VST3 browser controls
    hostContainer->addAndMakeVisible(loadPluginButton);
    hostContainer->addAndMakeVisible(browseButton);
    hostContainer->addAndMakeVisible(vstSearchBox);
    hostContainer->addAndMakeVisible(categoryCombo);
    hostContainer->addAndMakeVisible(favouriteButton);
    hostContainer->addAndMakeVisible(scanStatusLabel);
    hostContainer->addAndMakeVisible(vstBrowserList);

    // Resizable + foldable divider between the VST browser and the hosted editor
    browserPanelWidth = juce::jlimit(160, 700, audioProcessor.browserPanelWidth.load());
    browserPanelCollapsed = audioProcessor.browserPanelCollapsed.load();
    panelDivider = std::make_unique<PanelDivider>(*this);
    hostContainer->addAndMakeVisible(panelDivider.get());

    loadPluginButton.setButtonText("Load");
    loadPluginButton.setColour(juce::TextButton::buttonColourId, juce::Colour(blueAccent));
    loadPluginButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(tealAccent));
    loadPluginButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    loadPluginButton.setTooltip("Load the selected VST3 from the list (or open the browser if none is selected)");
    loadPluginButton.onClick = [this] {
        const int sel = vstBrowserList.getSelectedRow();
        if (sel >= 0 && sel < vstFilteredPaths.size())
            loadPluginFromPath(vstFilteredPaths[sel]);
        else
            loadKontakt();
    };

    hostContainer->addAndMakeVisible(scanButton);
    scanButton.setButtonText("Scan");
    scanButton.setTooltip("Re-scan the configured folders (recursively) for VST3 plugins now");
    scanButton.onClick = [this] {
        scanVst3Folders();
        rebuildVstBrowserList();
    };
    // Secondary actions get a neutral dark fill so the primary Load button stands out.
    scanButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1c222b));
    scanButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xff242b36));
    scanButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffb6c2d1));
    scanButton.setColour(juce::TextButton::textColourOnId, juce::Colours::white);

    browseButton.setButtonText("Browse\u2026");
    browseButton.setTooltip("Open the file browser to pick any .vst3 file");
    browseButton.onClick = [this] { loadKontakt(); };
    browseButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1c222b));
    browseButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xff242b36));
    browseButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffb6c2d1));
    browseButton.setColour(juce::TextButton::textColourOnId, juce::Colours::white);

    hostContainer->addAndMakeVisible(scanPathsButton);
    scanPathsButton.setButtonText("Paths\u2026");
    scanPathsButton.setTooltip("Manage the folders scanned for VST3 plugins");
    scanPathsButton.onClick = [this] { openScanPathsDialog(); };
    scanPathsButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1c222b));
    scanPathsButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xff242b36));
    scanPathsButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffb6c2d1));
    scanPathsButton.setColour(juce::TextButton::textColourOnId, juce::Colours::white);

    // Undo: destroys the hosted plugin and closes its editor, i.e. it undoes
    // the last Load. Full-width red row at the bottom of the browser, only
    // visible while a plugin is loaded (see resized()).
    hostContainer->addAndMakeVisible(undoButton);
    undoButton.setButtonText("Undo");
    undoButton.setTooltip("Undo the load: unload the current plugin and close its editor (Ctrl+Z)");
    undoButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xffb91c1c));
    undoButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xffef4444));
    undoButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    undoButton.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
    undoButton.onClick = [this] { unloadPlugin(); };

    // Redo: reloads the plugin that Undo just unloaded. Shares the bottom row
    // with Undo — only one of the two is visible at a time (see resized()).
    hostContainer->addAndMakeVisible(redoButton);
    redoButton.setButtonText("Redo");
    redoButton.setTooltip("Redo the load: reload the plugin you just unloaded (Ctrl+Shift+Z)");
    redoButton.setColour(juce::TextButton::buttonColourId, juce::Colour(tealAccent));
    redoButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xff86efac));
    redoButton.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    redoButton.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
    redoButton.onClick = [this] { redoLoad(); };

    vstSearchBox.setTextToShowWhenEmpty("Search VST3\u2026", juce::Colour(0xff5a6472));
    vstSearchBox.setTooltip("Search installed VST3 plugins by name");
    vstSearchBox.onTextChange = [this] { rebuildVstBrowserList(); };
    vstSearchBox.setColour(juce::TextEditor::backgroundColourId, juce::Colour(0xff0d1117));
    vstSearchBox.setColour(juce::TextEditor::textColourId, juce::Colour(0xffc3cdda));
    vstSearchBox.setColour(juce::TextEditor::outlineColourId, juce::Colour(outline));
    vstSearchBox.setColour(juce::TextEditor::focusedOutlineColourId, juce::Colour(blueAccent).withAlpha(0.55f));
    vstSearchBox.setColour(juce::TextEditor::highlightColourId, juce::Colour(blueAccent).withAlpha(0.35f));

    // Browser category: all plugins or only favourites
    categoryCombo.addItem("All Plugins", 1);
    categoryCombo.addItem(juce::String(juce::CharPointer_UTF8("\xe2\x98\x85")) + " Favorites", 2);
    categoryCombo.setSelectedId(1, juce::dontSendNotification);
    categoryCombo.setTooltip("Show every plugin, or only the ones you've favourited");
    categoryCombo.onChange = [this] { rebuildVstBrowserList(); };
    categoryCombo.setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d1117));
    categoryCombo.setColour(juce::ComboBox::outlineColourId, juce::Colour(outline));
    categoryCombo.setColour(juce::ComboBox::textColourId, juce::Colour(0xffc3cdda));
    categoryCombo.setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffc3cdda));
    categoryCombo.setColour(juce::ComboBox::buttonColourId, juce::Colour(0xff1a1f26));

    // Favourite toggle for the selected plugin (right-clicking a row also works)
    favouriteButton.setButtonText(juce::String(juce::CharPointer_UTF8("\xe2\x98\x85")));
    favouriteButton.setTooltip("Add / remove the selected plugin from favourites");
    favouriteButton.setClickingTogglesState(false);
    favouriteButton.onClick = [this]
    {
        const int sel = vstBrowserList.getSelectedRow();
        if (sel >= 0 && sel < vstFilteredPaths.size())
        {
            toggleFavourite(vstFilteredPaths[sel]);
            rebuildVstBrowserList();
        }
    };
    // Neutral star that turns gold when the selected plugin is favourited.
    favouriteButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1c222b));
    favouriteButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xff4b3b10));
    favouriteButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff8a94a3));
    favouriteButton.setColour(juce::TextButton::textColourOnId, juce::Colour(0xfff5c542));

    scanStatusLabel.setColour(juce::Label::textColourId, juce::Colour(0xff8a94a3));
    scanStatusLabel.setFont(juce::Font(11.0f));
    scanStatusLabel.setTooltip("Shows the result of the last VST3 scan. Configure folders with the Paths... button.");

    loadedPluginLabel.setColour(juce::Label::textColourId, juce::Colour(tealAccent).withAlpha(0.9f));
    loadedPluginLabel.setFont(juce::Font(11.0f, juce::Font::bold));
    loadedPluginLabel.setTooltip("The VST3 currently loaded in the host");
    loadedPluginLabel.setVisible(false);

    vstBrowserList.setModel(this);
    vstBrowserList.setRowHeight(26);
    // Transparent list background: the BrowserListBox::paint override draws
    // the glass gradient underneath, so the panel reads as translucent glass.
    vstBrowserList.setColour(juce::ListBox::backgroundColourId, juce::Colour(0x00000000));
    vstBrowserList.setColour(juce::ListBox::outlineColourId, juce::Colour(outline));
    vstBrowserList.setColour(juce::ListBox::textColourId, juce::Colour(0xffc3cdda));
    vstBrowserList.setTooltip("Double-click to load \u00b7 click " + juce::String(juce::CharPointer_UTF8("\xe2\x98\x85")) + " to favourite \u00b7 right-click for options");
    juce::ScrollBar& sb = vstBrowserList.getVerticalScrollBar();
    sb.setColour(juce::ScrollBar::backgroundColourId, juce::Colour(0x00000000));
    sb.setColour(juce::ScrollBar::trackColourId, juce::Colour(0x00000000));
    sb.setColour(juce::ScrollBar::thumbColourId, juce::Colour(0x992a3340));

    loadFavourites();
    loadScanPaths();
    scanVst3Folders();
    rebuildVstBrowserList();

    tabs.addTab("VST Host", juce::Colour(panelBottom), hostContainer, true);

    // Tab 2: Piano Roll
    tabs.addTab("Piano Roll", juce::Colour(editorBg), &pianoRoll, false);

    // Remember which tab was open last time and restore it, so the plugin
    // doesn't always jump back to the VST Host tab on reopen.
    tabs.onTabChanged = [this] (int index) {
        audioProcessor.hostTabIndex.store (index);
        audioProcessor.saveGlobalSettings();

        // Follow the active tab: hide the GUI on the piano roll by moving the
        // embedded window OFF-SCREEN (native VST3 windows ignore visibility),
        // and bring it back on-screen on the host tab — CREATING it on demand
        // if needed (the remembered "closed" state may mean it was never
        // created after reopening). Closing/reopening the VST window restores
        // the remembered state separately (constructor handling).
        if (audioProcessor.getHostedPlugin() != nullptr)
        {
            const bool onHostTab = (index == 0);
            if (onHostTab)
            {
                if (pluginEditorComponent == nullptr)
                {
                    if (auto* plugin = audioProcessor.getHostedPlugin())
                    {
                        if (plugin->hasEditor())
                        {
                            pluginEditorComponent.reset (plugin->createEditorIfNeeded());
                            pluginEditorComponent->addComponentListener (this);
                            capturePluginEditorNaturalSize();
                        }
                    }
                }

                if (pluginEditorComponent != nullptr)
                {
                    pluginGuiShown = true;
                    if (auto* currentTab = tabs.getTabContentComponent (0))
                        currentTab->addAndMakeVisible (pluginEditorComponent.get());
                    resized(); // places it on-screen + re-grows the window
                }
            }
            else if (pluginEditorComponent != nullptr)
            {
                pluginGuiShown = false;
                pluginEditorComponent->setBounds (-20000, -20000, 1, 1);
                resized();
            }

            // Persist the ACTUAL state on every change (tab switches included)
            // so closing and reopening the VST window restores exactly what
            // was on screen when it was closed.
            audioProcessor.pluginGuiVisible.store (pluginGuiShown);
            audioProcessor.saveGlobalSettings();
            updateHostState(); // button text follows (Hide / Show)
        }
    };
    tabs.setCurrentTabIndex (audioProcessor.hostTabIndex.load());

    // --- Top utility strip: render, MIDI clock, VU meters ---
    addAndMakeVisible (renderButton);
    renderButton.setButtonText ("Render WAV\u2026");
    renderButton.setTooltip ("Bounce the whole arrangement (beat 0 to the last note + 2 s tail) to a 24-bit WAV file. The transport must be stopped.");
    renderButton.setColour (juce::TextButton::buttonColourId, juce::Colour (blueAccent));
    renderButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (tealAccent));
    renderButton.setColour (juce::TextButton::textColourOffId, juce::Colours::white);
    renderButton.onClick = [this]
    {
        if (isRendering || audioProcessor.isHostPlaying.load())
            return;
        renderChooser = std::make_unique<juce::FileChooser> ("Bounce arrangement to WAV",
            juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("Render.wav"), "*.wav");
        renderChooser->launchAsync (juce::FileBrowserComponent::saveMode
                                    | juce::FileBrowserComponent::warnAboutOverwriting,
            [this] (const juce::FileChooser& fc)
            {
                const auto f = fc.getResult();
                if (f != juce::File())
                    startRender (f);
            });
    };

    addAndMakeVisible (dragWavButton);
    dragWavButton.setButtonText ("Drag WAV");
    dragWavButton.setTooltip ("Render the arrangement to a temporary WAV, then drag it straight onto the DAW arrangement timeline (no save dialog). The transport must be stopped. When the drag cursor appears, HOLD the mouse button, move over the DAW timeline and release. The temp file is kept for 10 minutes — if the drop doesn't land, import it manually from the status bar text.");
    dragWavButton.setColour (juce::TextButton::buttonColourId, juce::Colour (blueAccent));
    dragWavButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (tealAccent));
    dragWavButton.setColour (juce::TextButton::textColourOffId, juce::Colours::white);
    dragWavButton.onClick = [this] { startDragRender(); };

    addAndMakeVisible (midiClockButton);
    midiClockButton.setClickingTogglesState (true);
    midiClockButton.setToggleState (audioProcessor.midiClockEnabled.load(), juce::dontSendNotification);
    midiClockButton.setButtonText ("MIDI Clock");
    midiClockButton.setTooltip ("Send MIDI clock (24 PPQ) + start/stop to the hosted plugin so tempo-synced plugins follow the transport");
    midiClockButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff1c222b));
    midiClockButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (blueAccent));
    midiClockButton.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffb6c2d1));
    midiClockButton.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
    midiClockButton.onClick = [this]
    {
        audioProcessor.midiClockEnabled.store (midiClockButton.getToggleState());
        audioProcessor.saveGlobalSettings();
    };

    addAndMakeVisible (renderStatusLabel);
    renderStatusLabel.setColour (juce::Label::textColourId, juce::Colour (0xff9ca3af));
    renderStatusLabel.setFont (juce::Font (11.0f));

    vuMeter = std::make_unique<VUMeterComponent> (audioProcessor);
    addAndMakeVisible (vuMeter.get());

    // "Show Plugin GUI" button: the hosted plugin's (Kontakt's) own window is
    // created ONLY on demand — loading the engine never waits for the GUI,
    // which is the biggest chunk of Kontakt's perceived boot time.
    addAndMakeVisible (pluginGuiButton);
    pluginGuiButton.setButtonText ("Show Plugin GUI");
    pluginGuiButton.setTooltip ("Opens the hosted plugin's (Kontakt's) own window on demand. The engine loads in the background without waiting for the GUI, so Kontakt boots much faster.");
    pluginGuiButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff1c222b));
    pluginGuiButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (blueAccent));
    pluginGuiButton.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffb6c2d1));
    pluginGuiButton.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
    pluginGuiButton.setEnabled (false);
    pluginGuiButton.onClick = [this] { togglePluginGui(); };

    updateHostState();

    // Remember the plugin GUI state across close/open: if the GUI was open
    // last time and the plugin is already loaded, restore it now; if a warm
    // load is still in flight, show the GUI when it finishes.
    pendingAutoShowGui = audioProcessor.pluginGuiVisible.load();
    if (audioProcessor.getHostedPlugin() != nullptr && audioProcessor.pluginGuiVisible.load())
    {
        if (auto* plugin = audioProcessor.getHostedPlugin())
        {
            if (plugin->hasEditor())
            {
                pluginEditorComponent.reset (plugin->createEditorIfNeeded());
                pluginEditorComponent->addComponentListener (this);
                capturePluginEditorNaturalSize();
                pluginGuiShown = true;
                if (tabs.getCurrentTabIndex() == 0) // only attach on the host tab
                {
                    if (auto* currentTab = tabs.getTabContentComponent (0))
                    {
                        currentTab->addAndMakeVisible (pluginEditorComponent.get());
                        resized();
                    }
                }
            }
        }
    }

    // Poll for warm loads (the hosted plugin boots on a background thread and
    // the editor attaches when it is ready); the timer stops itself when idle.
    startTimerHz (10);

    // Restore the remembered window size (if any).
    setSize (audioProcessor.editorWindowWidth.load(),
             audioProcessor.editorWindowHeight.load());
    sizeTrackingActive = true; // start remembering size changes now
    resized();
    repaint();
}

void WebDAWHostAudioProcessorEditor::timerCallback()
{
    if (audioProcessor.pluginLoading.load())
    {
        // Warm load in progress: tell the user, keep polling.
        loadedPluginLabel.setText ("Loading plugin\u2026", juce::dontSendNotification);
        loadedPluginLabel.setVisible (true);
        return;
    }

    stopTimer();

    // Load finished.
    if (pendingAutoShowGui && audioProcessor.getHostedPlugin() != nullptr)
    {
        // Manual loads (double-click / Load / Browse / Redo) open the plugin's
        // GUI right away — same as before the deferred-GUI change. Only the
        // automatic restore path keeps the GUI hidden until "Show Plugin GUI".
        pendingAutoShowGui = false;
        if (pluginEditorComponent == nullptr)
        {
            if (auto* plugin = audioProcessor.getHostedPlugin())
            {
                if (plugin->hasEditor())
                {
                    pluginEditorComponent.reset (plugin->createEditorIfNeeded());
                    pluginEditorComponent->addComponentListener (this);
                    capturePluginEditorNaturalSize();
                    pluginGuiShown = true;
                    if (tabs.getCurrentTabIndex() == 0) // only attach on the host tab
                    {
                        if (auto* currentTab = tabs.getTabContentComponent (0))
                        {
                            currentTab->addAndMakeVisible (pluginEditorComponent.get());
                            resized(); // grows the host window to fit
                        }
                    }
                    audioProcessor.pluginGuiVisible.store (true);
                    audioProcessor.saveGlobalSettings();
                }
            }
        }
    }
    else if (audioProcessor.getHostedPlugin() == nullptr)
    {
        pendingAutoShowGui = false; // load failed — don't leave a stale flag
    }

    updateHostState();
}

void WebDAWHostAudioProcessorEditor::capturePluginEditorNaturalSize()
{
    if (pluginEditorComponent == nullptr || pluginNaturalW > 0)
        return;
    if (pluginEditorComponent->getWidth() > 0 && pluginEditorComponent->getHeight() > 0)
    {
        pluginNaturalW = pluginEditorComponent->getWidth();
        pluginNaturalH = pluginEditorComponent->getHeight();
    }
}

void WebDAWHostAudioProcessorEditor::togglePluginGui()
{
    if (audioProcessor.getHostedPlugin() == nullptr)
        return;

    if (!pluginGuiShown)
    {
        // Show: create the editor on demand and attach it to the host tab.
        if (pluginEditorComponent == nullptr)
        {
            auto* plugin = audioProcessor.getHostedPlugin();
            if (!plugin->hasEditor())
                return;

            pluginEditorComponent.reset (plugin->createEditorIfNeeded());
            pluginEditorComponent->addComponentListener (this);
            capturePluginEditorNaturalSize();
        }

        pluginGuiShown = true;
        if (auto* currentTab = tabs.getTabContentComponent (0))
            currentTab->addAndMakeVisible (pluginEditorComponent.get());

        resized(); // places it on-screen + grows the host window to fit
        audioProcessor.pluginGuiVisible.store (true);
    }
    else
    {
        // Hide: native VST3 windows (Kontakt's real window) ignore
        // Component::isVisible and even parent-visibility changes, so the
        // reliable hide is moving the embedded window OFF-SCREEN. The editor
        // object stays alive and attached, so re-showing is instant.
        pluginGuiShown = false;
        pluginEditorComponent->setBounds (-20000, -20000, 1, 1);
        resized();
        audioProcessor.pluginGuiVisible.store (false);
    }

    audioProcessor.saveGlobalSettings(); // remember the state for next open
    updateHostState();
}

WebDAWHostAudioProcessorEditor::~WebDAWHostAudioProcessorEditor()
{
    // Remember the final window size on close.
    audioProcessor.editorWindowWidth.store (juce::jmax (680, getWidth()));
    audioProcessor.editorWindowHeight.store (juce::jmax (400, getHeight()));
    audioProcessor.saveGlobalSettings();

    if (renderThread.joinable())
        renderThread.join();
    if (pluginEditorComponent != nullptr)
        pluginEditorComponent->removeComponentListener(this);
    setLookAndFeel(nullptr);
}

void WebDAWHostAudioProcessorEditor::startRender (const juce::File& destFile)
{
    isRendering = true;
    renderButton.setEnabled (false);
    dragWavButton.setEnabled (false);
    renderButton.setButtonText ("Rendering\u2026");
    renderStatusLabel.setText ("Rendering " + destFile.getFileName() + "\u2026", juce::dontSendNotification);

    if (renderThread.joinable())
        renderThread.join();

    // Bounce on a background thread; the processor's processLock serialises
    // it against the audio thread.
    juce::Component::SafePointer<WebDAWHostAudioProcessorEditor> safe (this);
    renderThread = std::thread ([this, destFile, safe]
    {
        const bool ok = audioProcessor.renderToWavFile (destFile);
        juce::MessageManager::callAsync ([safe, ok, destFile]
        {
            if (safe == nullptr)
                return;
            safe->isRendering = false;
            safe->renderButton.setEnabled (true);
            safe->dragWavButton.setEnabled (true);
            safe->renderButton.setButtonText ("Render WAV\u2026");
            safe->renderStatusLabel.setText (ok ? ("Bounced: " + destFile.getFullPathName())
                                                : "Render failed (is the transport stopped?)",
                                             juce::dontSendNotification);
        });
    });
}

void WebDAWHostAudioProcessorEditor::startDragRender()
{
    if (isRendering || audioProcessor.isHostPlaying.load())
    {
        // Give feedback instead of silently doing nothing.
        renderStatusLabel.setText (audioProcessor.isHostPlaying.load()
                                       ? "Stop the transport first, then try Drag WAV"
                                       : "Already rendering\u2026",
                                   juce::dontSendNotification);
        return;
    }

    isRendering = true;
    renderButton.setEnabled (false);
    dragWavButton.setEnabled (false);
    renderButton.setButtonText ("Rendering\u2026");
    renderStatusLabel.setText ("Rendering for drag\u2026", juce::dontSendNotification);

    if (renderThread.joinable())
        renderThread.join();

    // Render to a timestamped temp file, then hand the OS drag straight to
    // the DAW (same pattern as the piano roll's "Drag MIDI" button).
    const juce::File tempWav = juce::File::getSpecialLocation (juce::File::tempDirectory)
                                   .getChildFile ("WebDAW_Render_" + juce::String (juce::Time::currentTimeMillis()) + ".wav");

    juce::Component::SafePointer<WebDAWHostAudioProcessorEditor> safe (this);
    renderThread = std::thread ([this, tempWav, safe]
    {
        const bool ok = audioProcessor.renderToWavFile (tempWav);
        juce::MessageManager::callAsync ([safe, ok, tempWav]
        {
            if (safe == nullptr)
                return;

            // Restores the render buttons; used on every exit path below so
            // the UI can never end up stuck.
            auto resetUi = [safe]
            {
                safe->isRendering = false;
                safe->renderButton.setEnabled (true);
                safe->dragWavButton.setEnabled (true);
                safe->renderButton.setButtonText ("Render WAV\u2026");
            };

            if (!ok)
            {
                tempWav.deleteFile(); // don't leak failed renders in the temp dir
                resetUi();
                safe->renderStatusLabel.setText ("Render failed (is the transport stopped?)", juce::dontSendNotification);
                return;
            }

            // A valid PCM WAV has a 44-byte header at minimum; anything
            // smaller means the writer never got any audio.
            if (tempWav.getSize() <= 44)
            {
                tempWav.deleteFile();
                resetUi();
                safe->renderStatusLabel.setText ("Render produced no audio (is a plugin loaded?)", juce::dontSendNotification);
                return;
            }

            safe->renderStatusLabel.setText ("Move the cursor over the DAW timeline and hold the mouse button to drop the WAV\u2026", juce::dontSendNotification);

            // IMPORTANT: on Windows JUCE's performExternalDragDropOfFiles is
            // ASYNC — it queues an OLE DoDragDrop on a background thread and
            // returns immediately, so its boolean only means "drag queued",
            // NOT "dropped". The drag really ends when the completion
            // callback fires (on the message thread). Only then may we start
            // the temp-file countdown: deleting earlier races the user's
            // drop and the DAW's import of a long render — the classic
            // "sometimes works, sometimes not" Drag WAV failure. The buttons
            // stay disabled until the drag ends so two renders can never
            // stack up behind each other in the OLE queue.
            juce::StringArray files;
            files.add (tempWav.getFullPathName());

            const bool dragQueued = juce::DragAndDropContainer::performExternalDragDropOfFiles (
                files, false, safe,
                [safe, tempWav, resetUi]
                {
                    // Runs on the message thread after the OS drag ended
                    // (dropped OR cancelled).
                    if (safe == nullptr)
                        return;

                    resetUi();
                    const juce::String doneMsg ("Drag finished - check the DAW timeline (import manually: " + tempWav.getFullPathName() + ")");
                    safe->renderStatusLabel.setText (doneMsg, juce::dontSendNotification);
                    safe->renderStatusLabel.setTooltip (doneMsg); // long path: hover for the full text

                    // Keep the file around: DAWs can take several minutes to
                    // import a long render, and deleting it early breaks the
                    // import silently.
                    juce::Timer::callAfterDelay (600000, [tempWav] { tempWav.deleteFile(); });
                });

            if (!dragQueued)
            {
                tempWav.deleteFile();
                resetUi();
                const juce::String failMsg ("Drag could not start - import manually: " + tempWav.getFullPathName());
                safe->renderStatusLabel.setText (failMsg, juce::dontSendNotification);
                safe->renderStatusLabel.setTooltip (failMsg);
            }
        });
    });
}

void WebDAWHostAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour(editorBg));
}

void WebDAWHostAudioProcessorEditor::resized()
{
    // Top utility strip: Render WAV | Drag WAV | MIDI Clock | Plugin GUI | status ... VU meters
    auto strip = getLocalBounds().removeFromTop (30);
    renderButton.setBounds (strip.removeFromLeft (92).reduced (0, 4));
    dragWavButton.setBounds (strip.removeFromLeft (84).reduced (0, 4));
    midiClockButton.setBounds (strip.removeFromLeft (86).reduced (0, 4));
    pluginGuiButton.setBounds (strip.removeFromLeft (104).reduced (0, 4));
    renderStatusLabel.setBounds (strip.removeFromLeft (juce::jmin (300, strip.getWidth() * 2 / 3)).reduced (4, 4));
    if (vuMeter != nullptr)
        vuMeter->setBounds (strip.removeFromRight (210));

    tabs.setBounds (getLocalBounds().withTop (30));

    if (auto* hostContent = tabs.getTabContentComponent(0))
    {
        auto area = hostContent->getLocalBounds().reduced(12);

        constexpr int dividerWidth = 12;

        if (browserPanelCollapsed)
        {
            // Folded: hide the whole browser; the divider sits at the left
            // edge so it can be clicked/dragged to expand again.
            vstSearchBox.setVisible(false);
            categoryCombo.setVisible(false);
            favouriteButton.setVisible(false);
            scanStatusLabel.setVisible(false);
            vstBrowserList.setVisible(false);
            loadPluginButton.setVisible(false);
            scanButton.setVisible(false);
            scanPathsButton.setVisible(false);
            browseButton.setVisible(false);
            undoButton.setVisible(false);
            redoButton.setVisible(false);
            loadedPluginLabel.setVisible(false);

            panelDivider->setBounds(area.removeFromLeft(dividerWidth));
        }
        else
        {
            // Expanded: left VST3 browser panel (search + list + load buttons)
            vstSearchBox.setVisible(true);
            categoryCombo.setVisible(true);
            favouriteButton.setVisible(true);
            scanStatusLabel.setVisible(true);
            vstBrowserList.setVisible(true);
            loadPluginButton.setVisible(true);
            scanButton.setVisible(true);
            scanPathsButton.setVisible(true);
            browseButton.setVisible(true);

            auto browserPanel = area.removeFromLeft(browserPanelWidth);
            auto topRow = browserPanel.removeFromTop(26);
            categoryCombo.setBounds(topRow.removeFromRight(88));
            favouriteButton.setBounds(topRow.removeFromRight(34));
            vstSearchBox.setBounds(topRow);
            scanStatusLabel.setBounds(browserPanel.removeFromTop(20));

            // "Loaded: <plugin>" row — only while a plugin is loaded.
            const bool hasPlugin = (audioProcessor.getHostedPlugin() != nullptr);
            loadedPluginLabel.setVisible(hasPlugin);
            if (hasPlugin)
                loadedPluginLabel.setBounds(browserPanel.removeFromTop(18));

            // Bottom action rows (removed bottom-up so they stack in this
            // order): 1) Undo (red) while a plugin is loaded, or Redo (green)
            // when one was just unloaded — full-width; 2) Load (stretches) +
            // Browse… / Scan / Paths….
            undoButton.setVisible(hasPlugin);
            redoButton.setVisible(!hasPlugin && redoPluginPath.isNotEmpty());
            if (hasPlugin)
            {
                auto undoRow = browserPanel.removeFromBottom(28);
                undoButton.setBounds(undoRow.reduced(0, 2));
            }
            else if (redoButton.isVisible())
            {
                auto undoRow = browserPanel.removeFromBottom(28);
                redoButton.setBounds(undoRow.reduced(0, 2));
            }

            auto btnRow = browserPanel.removeFromBottom(30);
            const int smallBtnW = juce::jmin(62, (btnRow.getWidth() - 12) / 3);
            if (smallBtnW > 0)
            {
                browseButton.setBounds(btnRow.removeFromRight(smallBtnW));
                btnRow.removeFromRight(6);
                scanButton.setBounds(btnRow.removeFromRight(smallBtnW));
                btnRow.removeFromRight(6);
                scanPathsButton.setBounds(btnRow.removeFromRight(smallBtnW));
                btnRow.removeFromRight(6);
            }
            loadPluginButton.setBounds(btnRow); // primary action: stretches to fill
            vstBrowserList.setBounds(browserPanel);

            // Draggable divider strip between the browser and the editor
            panelDivider->setBounds(area.removeFromLeft(dividerWidth));
        }

        // Right: hosted plugin editor at its FULL natural size. The host
        // window is grown to fit (see fitWindowToPluginEditor), so the VST
        // editor is never shrunk or clipped when it loads. A hidden GUI is
        // treated as absent (it is parked off-screen, not laid out).
        if (pluginEditorComponent != nullptr && pluginGuiShown)
        {
            int editorWidth = pluginEditorComponent->getWidth();
            int editorHeight = pluginEditorComponent->getHeight();

            // If the plugin has 0 size for some reason, give it a default
            if (editorWidth <= 0 || editorHeight <= 0) {
                editorWidth = 800;
                editorHeight = 600;
            }

            pluginEditorComponent->setBounds(area.getX(), area.getY(), editorWidth, editorHeight);
        }
    }

    fitWindowToPluginEditor();

    // Remember the window size (after the constructor, debounced so a resize
    // drag doesn't hammer the settings file).
    if (sizeTrackingActive)
    {
        const int w = getWidth(), h = getHeight();
        if (w != audioProcessor.editorWindowWidth.load() || h != audioProcessor.editorWindowHeight.load())
        {
            audioProcessor.editorWindowWidth.store (w);
            audioProcessor.editorWindowHeight.store (h);
            if (w != lastSavedW || h != lastSavedH)
            {
                lastSavedW = w;
                lastSavedH = h;
                juce::Component::SafePointer<WebDAWHostAudioProcessorEditor> safe (this);
                juce::Timer::callAfterDelay (1200, [safe]
                {
                    if (safe != nullptr)
                        safe->audioProcessor.saveGlobalSettings();
                });
            }
        }
    }
}

void WebDAWHostAudioProcessorEditor::fitWindowToPluginEditor()
{
    // While the divider is being dragged the window must NOT grow — the window
    // would move under the cursor and the drag would run away. A hidden plugin
    // GUI (deferred load) must not grow the window either.
    if (pluginEditorComponent == nullptr
        || !pluginGuiShown
        || pluginEditorComponent->getParentComponent() == nullptr
        || isResizingBrowserPanel)
        return;

    int editorWidth = pluginEditorComponent->getWidth();
    int editorHeight = pluginEditorComponent->getHeight();
    // Fit against the plugin editor's NATURAL size (captured at creation) —
    // its current bounds are whatever our layout squeezed it into, which
    // would otherwise make this a no-op.
    if (pluginNaturalW > 0 && pluginNaturalH > 0)
    {
        editorWidth = pluginNaturalW;
        editorHeight = pluginNaturalH;
    }
    if (editorWidth <= 0 || editorHeight <= 0)
    {
        editorWidth = 800;
        editorHeight = 600;
    }

    // Space around the plugin editor inside this host: 12px margins, the tab
    // bar (34px), the CURRENT browser-panel width (0 when folded) and the
    // 12px divider strip.
    constexpr int margin = 12;
    constexpr int tabBarHeight = 34;
    constexpr int dividerWidth = 12;

    const int panelWidth = browserPanelCollapsed ? 0 : browserPanelWidth;
    const int neededWidth  = margin + panelWidth + dividerWidth + editorWidth + margin;
    const int neededHeight = tabBarHeight + margin + editorHeight + margin;

    if (auto* top = getTopLevelComponent())
    {
        // The top-level window is larger than this editor by its chrome
        // (title bar, menu bar, borders), so add that on top.
        const int chromeW = juce::jmax(0, top->getWidth() - getWidth());
        const int chromeH = juce::jmax(0, top->getHeight() - getHeight());

        const int targetW = juce::jlimit(680, 3840, neededWidth + chromeW);
        const int targetH = juce::jlimit(420, 2160, neededHeight + chromeH);

        // Only ever GROW the window so the full editor is visible — a window
        // the user has enlarged manually is never shrunk back.
        if (top->getWidth() < targetW || top->getHeight() < targetH)
            top->setSize(juce::jmax(top->getWidth(), targetW),
                         juce::jmax(top->getHeight(), targetH));
    }
}

void WebDAWHostAudioProcessorEditor::componentMovedOrResized (juce::Component& component, bool, bool)
{
    // The plugin asked to resize its editor (e.g. VST3 resizeView) — grow the
    // host window so the new size is fully visible.
    if (&component == pluginEditorComponent.get())
        fitWindowToPluginEditor();
}

// --- PanelDivider (drag to resize, click to fold/unfold) ---

void WebDAWHostAudioProcessorEditor::PanelDivider::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1a1f26));
    g.setColour (juce::Colour (outline).brighter (0.35f));
    g.drawVerticalLine (getWidth() / 2, 0.0f, (float) getHeight());

    // Small chevron at the top: "«" when expanded (click to fold),
    // "»" when folded (click to unfold).
    juce::Path arrow;
    const float h = 6.0f;
    const float cx = (float) getWidth() / 2.0f;
    const float y = 14.0f;
    if (ownerRef.browserPanelCollapsed)
        arrow.addTriangle (cx - 2.0f, y - h, cx - 2.0f, y + h, cx + 2.5f, y);
    else
        arrow.addTriangle (cx + 2.0f, y - h, cx + 2.0f, y + h, cx - 2.5f, y);
    g.setColour (juce::Colour (0xff8a94a3));
    g.fillPath (arrow);
}

void WebDAWHostAudioProcessorEditor::PanelDivider::mouseDown (const juce::MouseEvent& e)
{
    ownerRef.isResizingBrowserPanel = true;
    // Screen positions are used throughout so the drag stays stable even if
    // the divider (or window) moves while dragging.
    dragStartScreenX = e.getMouseDownScreenPosition().x;
    dragStartWidth = ownerRef.browserPanelWidth;
    mouseDownCollapsed = ownerRef.browserPanelCollapsed;
}

void WebDAWHostAudioProcessorEditor::PanelDivider::mouseDrag (const juce::MouseEvent& e)
{
    // Dragging a folded divider unfolds it first, then resizes from the
    // remembered width.
    if (mouseDownCollapsed && ownerRef.browserPanelCollapsed)
        ownerRef.setBrowserPanelCollapsed (false);

    const int newWidth = juce::jlimit (160, 700,
                                       dragStartWidth + (e.getScreenPosition().x - dragStartScreenX));
    if (newWidth != ownerRef.browserPanelWidth)
    {
        ownerRef.browserPanelWidth = newWidth;
        ownerRef.resized();
    }
}

void WebDAWHostAudioProcessorEditor::PanelDivider::mouseUp (const juce::MouseEvent& e)
{
    ownerRef.isResizingBrowserPanel = false;

    const bool wasClick = (std::abs (e.getScreenPosition().x - dragStartScreenX)
                           + std::abs (e.getScreenPosition().y - e.getMouseDownScreenPosition().y)) < 4;

    if (wasClick)
    {
        // Click on the divider folds/unfolds the browser panel.
        ownerRef.setBrowserPanelCollapsed (!ownerRef.browserPanelCollapsed);
        return;
    }

    // Remember the width for next time, then re-fit the window so the full
    // plugin editor is visible again at the new panel width.
    ownerRef.audioProcessor.browserPanelWidth.store (ownerRef.browserPanelWidth);
    ownerRef.audioProcessor.saveGlobalSettings();
    ownerRef.fitWindowToPluginEditor();
}

void WebDAWHostAudioProcessorEditor::PanelDivider::mouseDoubleClick (const juce::MouseEvent&)
{
    ownerRef.isResizingBrowserPanel = false;
    ownerRef.setBrowserPanelCollapsed (false);
    ownerRef.browserPanelWidth = 280;
    ownerRef.audioProcessor.browserPanelWidth.store (ownerRef.browserPanelWidth);
    ownerRef.audioProcessor.saveGlobalSettings();
    ownerRef.resized();
    ownerRef.fitWindowToPluginEditor();
}

void WebDAWHostAudioProcessorEditor::setBrowserPanelCollapsed (bool collapsed)
{
    if (browserPanelCollapsed == collapsed)
        return;

    browserPanelCollapsed = collapsed;
    audioProcessor.browserPanelCollapsed.store (collapsed);
    audioProcessor.saveGlobalSettings();
    resized();
}

void WebDAWHostAudioProcessorEditor::loadKontakt()
{
    // 1. Initialize the file chooser
    fileChooser = std::make_unique<juce::FileChooser> ("Select a VST3 Plugin...", juce::File{}, "*.vst3");
    
    // 2. Define flags (we want to open an existing file)
    auto chooserFlags = juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;
    
    // 3. Launch asynchronously
    fileChooser->launchAsync (chooserFlags, [this] (const juce::FileChooser& fc)
    {
        auto file = fc.getResult();
        
        if (file.existsAsFile())
            loadPluginFromPath(file.getFullPathName());
    });
}

void WebDAWHostAudioProcessorEditor::loadPluginFromPath(const juce::String& path, bool showGui)
{
    if (!juce::File(path).exists())
        return;

    // A fresh load supersedes any pending redo (Redo reloads the plugin that
    // Undo unloaded — loading something new clears that history).
    redoPluginPath.clear();

    // CRITICAL FIX: Delete the old editor before destroying the old plugin
    if (pluginEditorComponent != nullptr)
        pluginEditorComponent->removeComponentListener(this);
    pluginEditorComponent.reset();

    // Warm load: kick off the load on a background thread and let the timer
    // attach the hosted editor + refresh the UI when it is ready.
    loadedPluginLabel.setText ("Loading plugin\u2026", juce::dontSendNotification);
    loadedPluginLabel.setVisible (true);
    pendingAutoShowGui = showGui;
    audioProcessor.loadPluginAsync (path);

    startTimerHz (10);
}

void WebDAWHostAudioProcessorEditor::redoLoad()
{
    if (redoPluginPath.isEmpty())
        return;

    // Copy first: loadPluginFromPath clears redoPluginPath, and it takes the
    // path by const reference — passing the member directly would hand it an
    // already-emptied string.
    const juce::String path = redoPluginPath;
    loadPluginFromPath(path);
}

void WebDAWHostAudioProcessorEditor::unloadPlugin()
{
    // Remember what was loaded so Redo can bring it back. Must happen before
    // the processor clears currentHostedPluginPath.
    if (audioProcessor.getHostedPlugin() != nullptr)
        redoPluginPath = audioProcessor.getHostedPluginPath();

    // Delete the editor FIRST — it references the plugin instance.
    if (pluginEditorComponent != nullptr)
        pluginEditorComponent->removeComponentListener(this);
    pluginEditorComponent.reset();
    pluginGuiShown = false;

    stopTimer(); // a warm load in flight must not re-attach after Undo
    pendingAutoShowGui = false;
    audioProcessor.unloadPlugin();

    updateHostState();

    // Shrink the host window back to its base size (it was grown to fit the
    // plugin editor via fitWindowToPluginEditor).
    if (auto* top = getTopLevelComponent())
    {
        const int chromeW = juce::jmax(0, top->getWidth() - getWidth());
        const int chromeH = juce::jmax(0, top->getHeight() - getHeight());
        top->setSize(1100 + chromeW, 720 + chromeH);
    }

    resized();
    repaint();
}

void WebDAWHostAudioProcessorEditor::updateHostState()
{
    if (auto* plugin = audioProcessor.getHostedPlugin())
    {
        loadedPluginLabel.setText("Loaded: " + plugin->getName(), juce::dontSendNotification);
        loadedPluginLabel.setVisible(true);

        pluginGuiButton.setEnabled (true);
        pluginGuiButton.setButtonText (pluginGuiShown ? "Hide Plugin GUI" : "Show Plugin GUI");
    }
    else
    {
        loadedPluginLabel.setVisible(false);
        pluginGuiButton.setEnabled (false);
        pluginGuiButton.setButtonText ("Show Plugin GUI");
    }
}

bool WebDAWHostAudioProcessorEditor::keyPressed (const juce::KeyPress& key)
{
    // Only act while the VST Host tab is active — the piano roll has its own
    // keyboard handling and must keep its keys.
    if (tabs.getCurrentTabIndex() != 0)
        return false;

    const bool cmd = key.getModifiers().isCommandDown();

    // Ctrl+Z = undo (unload), Ctrl+Shift+Z / Ctrl+Y = redo (reload).
    if (cmd && key.getKeyCode() == 'Z')
    {
        if (key.getModifiers().isShiftDown())
            redoLoad();
        else
            unloadPlugin();
        return true;
    }
    if (cmd && key.getKeyCode() == 'Y')
    {
        redoLoad();
        return true;
    }

    return false;
}

void WebDAWHostAudioProcessorEditor::scanVst3Folders()
{
    vstPluginPaths.clear();

    juce::StringArray folders;
#if JUCE_WINDOWS
    folders.add(juce::File("C:\\Program Files\\Common Files\\VST3").getFullPathName());
    folders.add(juce::File("C:\\Program Files (x86)\\Common Files\\VST3").getFullPathName());
    folders.add(juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("VST3").getFullPathName());
#elif JUCE_MAC
    folders.add("/Library/Audio/Plug-Ins/VST3");
    folders.add(juce::File::getSpecialLocation(juce::File::userHomeDirectory).getChildFile("Library/Audio/Plug-Ins/VST3").getFullPathName());
#elif JUCE_LINUX
    folders.add("/usr/lib/vst3");
    folders.add("/usr/local/lib/vst3");
    folders.add(juce::File::getSpecialLocation(juce::File::userHomeDirectory).getChildFile(".vst3").getFullPathName());
#endif

    // User-defined scan folders (chosen via the Paths... button, persisted in
    // scan_paths.txt so they are remembered across restarts)
    for (const auto& p : scanPaths)
        if (juce::File(p).isDirectory() && !folders.contains(p))
            folders.add(p);

    juce::StringArray seen;
    int scannedFolderCount = 0;
    int foundCount = 0;

    auto addResult = [&] (const juce::File& f)
    {
        const juce::String p = f.getFullPathName();
        if (!seen.contains(p))
        {
            seen.add(p);
            vstPluginPaths.add(p);
            ++foundCount;
        }
    };

    // Recursively walk a folder looking for *.vst3 bundles/files at ANY depth,
    // so plugins kept in subfolders (e.g. "D:\\VSTs\\Kontakt\\Kontakt.vst3")
    // are found too. A .vst3 bundle directory is added but NOT descended into
    // (its inner .vst3 binary would otherwise show up as a duplicate). Depth is
    // capped so scanning a large user folder (or even a whole drive) stays fast.
    std::function<void (const juce::File&, int)> walk = [&] (const juce::File& dir, int depth)
    {
        if (depth > 8)
            return;

        juce::Array<juce::File> children;
        dir.findChildFiles(children, juce::File::findFilesAndDirectories, false);

        for (const auto& child : children)
        {
            if (child.getFileName().endsWithIgnoreCase(".vst3"))
                addResult(child);
            else if (child.isDirectory())
                walk(child, depth + 1);
        }
    };

    for (const auto& folder : folders)
    {
        juce::File dir(folder);
        if (!dir.isDirectory())
            continue;

        ++scannedFolderCount;
        walk(dir, 0);
    }

    // A configured path that points DIRECTLY at a .vst3 file (not a folder)
    // is added on its own, so a single plugin path also works.
    for (const auto& p : scanPaths)
    {
        juce::File f(p);
        if (f.existsAsFile() && f.getFileName().endsWithIgnoreCase(".vst3"))
            addResult(f);
    }

    vstPluginPaths.sort(true);

    // Visible feedback so the Scan button always shows a result.
    if (foundCount > 0)
    {
        scanStatusLabel.setText("Found " + juce::String(foundCount) + " VST3 plugin(s) in "
                                + juce::String(scannedFolderCount) + " folder(s)",
                                juce::dontSendNotification);
    }
    else
    {
        scanStatusLabel.setText("No VST3 plugins found - check the folder in Paths...",
                                juce::dontSendNotification);
    }
}

void WebDAWHostAudioProcessorEditor::rebuildVstBrowserList()
{
    vstFilteredPaths.clear();

    const bool favouritesOnly = (categoryCombo.getSelectedId() == 2);
    const juce::String query = vstSearchBox.getText().trim().toLowerCase();

    for (const auto& p : vstPluginPaths)
    {
        if (favouritesOnly && !isFavourite(p))
            continue;

        if (query.isEmpty() || juce::File(p).getFileNameWithoutExtension().toLowerCase().contains(query))
            vstFilteredPaths.add(p);
    }

    // Favourites first, alphabetical within each group
    juce::StringArray favs, others;
    for (const auto& p : vstFilteredPaths)
        (isFavourite(p) ? favs : others).add(p);
    favs.sort(true);
    others.sort(true);
    vstFilteredPaths = favs;
    vstFilteredPaths.addArray(others);

    if (query.isNotEmpty())
    {
        scanStatusLabel.setText(juce::String(vstFilteredPaths.size()) + " of "
                                + juce::String(vstPluginPaths.size()) + " shown",
                                juce::dontSendNotification);
    }
    else if (favouritesOnly)
    {
        scanStatusLabel.setText(juce::String(vstFilteredPaths.size()) + " favourite(s)",
                                juce::dontSendNotification);
    }

    vstBrowserList.updateContent();
    updateFavouriteButtonState();
}

void WebDAWHostAudioProcessorEditor::updateFavouriteButtonState()
{
    const int sel = vstBrowserList.getSelectedRow();
    const bool isFav = (sel >= 0 && sel < vstFilteredPaths.size())
                       && isFavourite(vstFilteredPaths[sel]);
    favouriteButton.setToggleState(isFav, juce::dontSendNotification);
    favouriteButton.setTooltip(isFav ? "Remove the selected plugin from favourites"
                                     : "Add the selected plugin to favourites");
}

bool WebDAWHostAudioProcessorEditor::isFavourite(const juce::String& path) const
{
    return favouritePaths.contains(path);
}

void WebDAWHostAudioProcessorEditor::toggleFavourite(const juce::String& path)
{
    if (favouritePaths.contains(path))
        favouritePaths.removeString(path);
    else
        favouritePaths.add(path);
    saveFavourites();
}

void WebDAWHostAudioProcessorEditor::loadFavourites()
{
    favouritesFile = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                         .getChildFile("WebDAWHost")
                         .getChildFile("favourites.txt");
    favouritePaths.clear();
    if (favouritesFile.existsAsFile())
    {
        for (auto line : juce::StringArray::fromLines(favouritesFile.loadFileAsString()))
        {
            line = line.trim();
            if (line.isNotEmpty())
                favouritePaths.add(line);
        }
    }
}

void WebDAWHostAudioProcessorEditor::saveFavourites()
{
    favouritesFile.getParentDirectory().createDirectory();
    favouritesFile.replaceWithText(favouritePaths.joinIntoString("\n"));
}

void WebDAWHostAudioProcessorEditor::loadScanPaths()
{
    scanPathsFile = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                        .getChildFile("WebDAWHost")
                        .getChildFile("scan_paths.txt");
    scanPaths.clear();
    if (scanPathsFile.existsAsFile())
    {
        for (auto line : juce::StringArray::fromLines(scanPathsFile.loadFileAsString()))
        {
            line = line.trim();
            if (line.isNotEmpty())
                scanPaths.add(line);
        }
    }
}

void WebDAWHostAudioProcessorEditor::saveScanPaths()
{
    scanPathsFile.getParentDirectory().createDirectory();
    scanPathsFile.replaceWithText(scanPaths.joinIntoString("\n"));
}

void WebDAWHostAudioProcessorEditor::openScanPathsDialog()
{
    struct ScanPathsContent : public juce::Component
    {
        WebDAWHostAudioProcessorEditor& owner;
        juce::TextEditor pathEditor;
        juce::TextButton addButton { "Add Folder..." };
        juce::TextButton okButton { "OK" };
        juce::TextButton cancelButton { "Cancel" };

        ScanPathsContent (WebDAWHostAudioProcessorEditor& o) : owner (o)
        {
            addAndMakeVisible (pathEditor);
            addAndMakeVisible (addButton);
            addAndMakeVisible (okButton);
            addAndMakeVisible (cancelButton);

            pathEditor.setMultiLine (true, false);
            pathEditor.setScrollbarsShown (true);
            pathEditor.setFont (juce::Font (13.0f));
            pathEditor.setText (owner.scanPaths.joinIntoString ("\n"));
            pathEditor.setTooltip ("One folder per line - the list is saved automatically and scanned recursively for *.vst3 plugins.");

            addButton.onClick = [this]
            {
                owner.pathChooser = std::make_unique<juce::FileChooser> ("Choose a folder to scan...", juce::File{}, "*");
                owner.pathChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
                    [this] (const juce::FileChooser& fc)
                    {
                        const auto dir = fc.getResult();
                        if (dir.isDirectory())
                        {
                            auto lines = juce::StringArray::fromLines (pathEditor.getText());
                            if (!lines.contains (dir.getFullPathName()))
                                pathEditor.setText (pathEditor.getText() + (pathEditor.getText().isNotEmpty() ? "\n" : "") + dir.getFullPathName());
                        }
                    });
            };

            okButton.onClick = [this]
            {
                owner.scanPaths = juce::StringArray::fromLines (pathEditor.getText());
                owner.scanPaths.removeEmptyStrings();
                owner.saveScanPaths();
                owner.scanVst3Folders();
                owner.rebuildVstBrowserList();
                closeDialog (1);
            };

            cancelButton.onClick = [this] { closeDialog (0); };
        }

        void closeDialog (int result)
        {
            if (auto* dw = findParentComponentOfClass<juce::DialogWindow>())
                dw->exitModalState (result);
        }

        void resized() override
        {
            auto area = getLocalBounds().reduced (10);
            auto btnRow = area.removeFromBottom (30);
            addButton.setBounds (btnRow.removeFromLeft (110));
            btnRow.removeFromLeft (10);
            cancelButton.setBounds (btnRow.removeFromRight (90));
            btnRow.removeFromRight (10);
            okButton.setBounds (btnRow.removeFromRight (70));
            pathEditor.setBounds (area);
        }
    };

    juce::DialogWindow::LaunchOptions opts;
    opts.content.setOwned (new ScanPathsContent (*this));
    opts.dialogTitle = "VST Scan Paths";
    opts.dialogBackgroundColour = juce::Colour (0xff1a1f26);
    opts.escapeKeyTriggersCloseButton = true;
    opts.useNativeTitleBar = false;
    opts.resizable = true;
    opts.componentToCentreAround = this;
    opts.launchAsync();
}

// --- ListBoxModel ---

int WebDAWHostAudioProcessorEditor::getNumRows()
{
    return vstFilteredPaths.size();
}

void WebDAWHostAudioProcessorEditor::paintListBoxItem(int row, juce::Graphics& g, int width, int height, bool rowIsSelected)
{
    if (row < 0 || row >= vstFilteredPaths.size())
        return;

    juce::String name = juce::File(vstFilteredPaths[row]).getFileNameWithoutExtension();
    name = name.upToLastOccurrenceOf(".vst3", false, false);

    const bool hovered = (vstBrowserList.hoveredRow == row);

    if (rowIsSelected)
    {
        g.setColour(juce::Colour(blueAccent).withAlpha(0.16f));
        g.fillRect(0, 0, width, height);
        g.setColour(juce::Colour(blueAccent));
        g.fillRect(0, 2, 3, height - 4); // accent bar on the left edge
    }
    else if (hovered)
    {
        g.setColour(juce::Colours::white.withAlpha(0.05f));
        g.fillRect(0, 0, width, height);
    }

    g.setColour(rowIsSelected ? juce::Colours::white : juce::Colour(0xffc3cdda));
    g.setFont(juce::Font(13.0f));
    g.drawText(name, 12, 0, width - 34, height, juce::Justification::centredLeft, false);

    if (isFavourite(vstFilteredPaths[row]))
    {
        g.setColour(juce::Colour(0xfff5c542));
        g.setFont(juce::Font(13.0f));
        g.drawText(juce::String(juce::CharPointer_UTF8("\xe2\x98\x85")), width - 22, 0, 18, height,
                   juce::Justification::centred, false);
    }
}

void WebDAWHostAudioProcessorEditor::listBoxItemClicked(int row, const juce::MouseEvent& e)
{
    if (row < 0 || row >= vstFilteredPaths.size())
        return;

    if (e.mods.isRightButtonDown())
    {
        // Select the row under the cursor and show the context menu
        vstBrowserList.selectRow(row);
        updateFavouriteButtonState();

        const juce::String path = vstFilteredPaths[row];
        const bool isFav = isFavourite(path);
        const juce::String star = juce::String(juce::CharPointer_UTF8("\xe2\x98\x85"));

        juce::PopupMenu menu;
        menu.setLookAndFeel(&webDAWMenuLAF()); // shared modern menu styling
        menu.addItem(1, "Load Plugin", true, false);
        menu.addSeparator();
        menu.addItem(2, star + (isFav ? " Remove from Favourites" : " Add to Favourites"),
                     true, false);

        // Anchor the menu on the plugin's row so it appears right on the name
        auto rowArea = vstBrowserList.getRowPosition(row, true);
        rowArea.translate(vstBrowserList.getScreenX(), vstBrowserList.getScreenY());

        menu.showMenuAsync(juce::PopupMenu::Options()
                               .withTargetScreenArea(rowArea)
                               .withMinimumWidth(220),
            [this, path] (int result)
            {
                if (result == 1)
                    loadPluginFromPath(path);
                else if (result == 2)
                {
                    toggleFavourite(path);
                    rebuildVstBrowserList(); // re-sorts favourites to the top
                }
            });
    }
    else
    {
        updateFavouriteButtonState(); // reflect the newly selected plugin
    }
}

void WebDAWHostAudioProcessorEditor::listBoxItemDoubleClicked(int row, const juce::MouseEvent&)
{
    if (row < 0 || row >= vstFilteredPaths.size())
        return;

    loadPluginFromPath(vstFilteredPaths[row]);
}
