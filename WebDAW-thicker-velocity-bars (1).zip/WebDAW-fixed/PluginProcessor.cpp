#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <thread>
#include "MidiPitchHelpers.h"

using namespace MidiPitch;

namespace
{
    int beatToSampleOffset(double beat, double currentPpq, double blockLengthBeats, int numSamples)
    {
        if (blockLengthBeats <= 0.0 || numSamples <= 1)
            return 0;

        double sample = ((beat - currentPpq) / blockLengthBeats) * (double)numSamples;
        return juce::jlimit(0, numSamples - 1, (int)std::floor(sample));
    }

    // MIDI pitch to use for a note-off. The UI may have retuned (transposed /
    // dragged) the note AFTER its note-on was sent, so the instrument is
    // ringing the note-on pitch, NOT the current midiNote. Sending a note-off
    // with the wrong pitch never kills the voice — it hangs until Panic.
    int noteOffPitch(const NoteEvent& note)
    {
        return note.soundingMidiNote >= 0 ? note.soundingMidiNote : note.midiNote;
    }
}

WebDAWHostAudioProcessor::WebDAWHostAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )
#endif
{
    // JUCE >= 8.0.11: AudioPluginFormatManager::addDefaultFormats() was
    // removed (= delete). Use the free function addDefaultFormatsToManager()
    // (with UI support) from the juce_audio_processors module instead.
    addDefaultFormatsToManager(formatManager);

    // Piano roll starts empty
    loadGlobalSettings();
    loadPluginDescriptionCache();
}

WebDAWHostAudioProcessor::~WebDAWHostAudioProcessor()
{
}

void WebDAWHostAudioProcessor::loadGlobalSettings()
{
    juce::File settingsFile = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                                .getChildFile("WebDAWHost")
                                .getChildFile("settings.xml");
    
    if (auto xml = juce::XmlDocument::parse(settingsFile))
    {
        pianoRollThemeIndex.store(xml->getIntAttribute("themeIndex", pianoRollThemeIndex.load()));
        pianoRollPitchNodeSize.store((float)xml->getDoubleAttribute("pitchNodeSize", pianoRollPitchNodeSize.load()));
        pianoRollPitchLineThickness.store((float)xml->getDoubleAttribute("pitchLineThickness", pianoRollPitchLineThickness.load()));
        pianoRollGridOpacity.store((float)xml->getDoubleAttribute("gridOpacity", pianoRollGridOpacity.load()));
        pianoRollNoteCornerRadius.store((float)xml->getDoubleAttribute("noteCornerRadius", pianoRollNoteCornerRadius.load()));
        pianoRollPlayheadThickness.store((float)xml->getDoubleAttribute("playheadThickness", pianoRollPlayheadThickness.load()));
        pianoRollVelocityLaneHeight.store(xml->getIntAttribute("velocityLaneHeight", pianoRollVelocityLaneHeight.load()));
        pianoRollNoteContrast.store((float)xml->getDoubleAttribute("noteContrast", pianoRollNoteContrast.load()));
        pianoRollPitchLineContrast.store((float)xml->getDoubleAttribute("pitchLineContrast", pianoRollPitchLineContrast.load()));
        pianoRollNoteColour.store((uint32_t)xml->getStringAttribute("noteColour").getHexValue64());
        if (pianoRollNoteColour.load() != 0 && pianoRollNoteColour.load() < 0x01000000u)
            pianoRollNoteColour.store(0); // garbage from an older save format -> theme accent
        pianoRollRazorColour.store((uint32_t)xml->getStringAttribute("razorColour").getHexValue64());
        if (pianoRollRazorColour.load() == 0)
            pianoRollRazorColour.store(0xff5eead4); // default teal
        pianoRollPitchLineColour.store((uint32_t)xml->getStringAttribute("pitchLineColour").getHexValue64());
        if (pianoRollPitchLineColour.load() != 0 && pianoRollPitchLineColour.load() < 0x01000000u)
            pianoRollPitchLineColour.store(0); // garbage from an older save format -> theme accent
        pianoRollGridBgColour.store((uint32_t)xml->getStringAttribute("gridBgColour").getHexValue64());
        if (pianoRollGridBgColour.load() != 0 && pianoRollGridBgColour.load() < 0x01000000u)
            pianoRollGridBgColour.store(0);
        pianoRollGridLineColour.store((uint32_t)xml->getStringAttribute("gridLineColour").getHexValue64());
        if (pianoRollGridLineColour.load() != 0 && pianoRollGridLineColour.load() < 0x01000000u)
            pianoRollGridLineColour.store(0);
        pianoRollNoteTextColour.store((uint32_t)xml->getStringAttribute("noteTextColour").getHexValue64());
        if (pianoRollNoteTextColour.load() != 0 && pianoRollNoteTextColour.load() < 0x01000000u)
            pianoRollNoteTextColour.store(0);
        pianoRollNoteTextBold.store(xml->getBoolAttribute("noteTextBold", pianoRollNoteTextBold.load()));
        pianoRollToolbarTextColour.store((uint32_t)xml->getStringAttribute("toolbarTextColour").getHexValue64());
        if (pianoRollToolbarTextColour.load() != 0 && pianoRollToolbarTextColour.load() < 0x01000000u)
            pianoRollToolbarTextColour.store(0);
        pianoRollToolbarTextBold.store(xml->getBoolAttribute("toolbarTextBold", pianoRollToolbarTextBold.load()));
        pianoRollNoteNameColour.store((uint32_t)xml->getStringAttribute("noteNameColour").getHexValue64());
        if (pianoRollNoteNameColour.load() != 0 && pianoRollNoteNameColour.load() < 0x01000000u)
            pianoRollNoteNameColour.store(0);
        pianoRollNoteNameBold.store(xml->getBoolAttribute("noteNameBold", pianoRollNoteNameBold.load()));
        pianoRollShowNoteNames.store(xml->getBoolAttribute("showNoteNames", pianoRollShowNoteNames.load()));
        pianoRollGhostPitchLines.store(xml->getBoolAttribute("ghostPitchLines", pianoRollGhostPitchLines.load()));
        pianoRollNoteNameFontSize.store(juce::jlimit(8, 20, xml->getIntAttribute("noteNameFontSize", pianoRollNoteNameFontSize.load())));
        pianoRollGhostPitchLineOpacity.store(juce::jlimit(5, 70, xml->getIntAttribute("ghostPitchLineOpacity", pianoRollGhostPitchLineOpacity.load())));
        pianoRollFontTypefaceIndex.store(juce::jlimit(0, 28, xml->getIntAttribute("fontTypeface", pianoRollFontTypefaceIndex.load())));
        // Older saves had one gridLineThickness for every line type; migrate
        // it to all four per-type values when the new attributes are absent.
        if (xml->hasAttribute("gridLineThickness") && !xml->hasAttribute("gridSubBeatThickness"))
        {
            const float oldT = juce::jlimit(0.25f, 5.0f, (float)xml->getDoubleAttribute("gridLineThickness", 1.0f));
            pianoRollGridSubBeatThickness.store(oldT);
            pianoRollGridHalfBeatThickness.store(oldT);
            pianoRollGridBeatThickness.store(oldT);
            pianoRollGridBarThickness.store(oldT);
        }
        else
        {
            pianoRollGridSubBeatThickness.store(juce::jlimit(0.25f, 5.0f, (float)xml->getDoubleAttribute("gridSubBeatThickness", pianoRollGridSubBeatThickness.load())));
            pianoRollGridHalfBeatThickness.store(juce::jlimit(0.25f, 5.0f, (float)xml->getDoubleAttribute("gridHalfBeatThickness", pianoRollGridHalfBeatThickness.load())));
            pianoRollGridBeatThickness.store(juce::jlimit(0.25f, 5.0f, (float)xml->getDoubleAttribute("gridBeatThickness", pianoRollGridBeatThickness.load())));
            pianoRollGridBarThickness.store(juce::jlimit(0.25f, 5.0f, (float)xml->getDoubleAttribute("gridBarThickness", pianoRollGridBarThickness.load())));
        }
        pianoRollKeyHeight.store(juce::jlimit(4.0f, 80.0f, (float)xml->getDoubleAttribute("keyHeight", pianoRollKeyHeight.load())));
        pianoRollPixelsPerBeat.store(juce::jlimit(10.0f, 400.0f, (float)xml->getDoubleAttribute("pixelsPerBeat", pianoRollPixelsPerBeat.load())));
        pianoRollViewX.store(juce::jmax(0.0f, (float)xml->getDoubleAttribute("viewX", pianoRollViewX.load())));
        pianoRollViewY.store(juce::jmax(0.0f, (float)xml->getDoubleAttribute("viewY", pianoRollViewY.load())));
        pianoRollGridDivisorIndex.store(juce::jlimit(0, 5, xml->getIntAttribute("gridDivisorIndex", pianoRollGridDivisorIndex.load())));
        pianoRollToolMode.store(juce::jlimit(0, 1, xml->getIntAttribute("toolMode", pianoRollToolMode.load())));
        pianoRollPitchPreview.store(xml->getBoolAttribute("pitchPreview", pianoRollPitchPreview.load()));
        pianoRollShowPitchEnvelopes.store(xml->getBoolAttribute("showPitchEnvelopes", pianoRollShowPitchEnvelopes.load()));
        pianoRollShowVelocityLane.store(xml->getBoolAttribute("showVelocityLane", pianoRollShowVelocityLane.load()));

        // Last-used pitch-bend settings (fallback for new projects)
        pitchBendRange.store(juce::jlimit(0, 96, xml->getIntAttribute("pitchBendRange", pitchBendRange.load())));
        pitchShape.store(juce::jlimit(0, 5, xml->getIntAttribute("pitchShape", pitchShape.load())));
        {
            const int savedMicros = xml->getIntAttribute("pitchBendStepMicros", pitchBendStepMicros.load());
            pitchBendStepMicros.store((savedMicros == 250 || savedMicros == 500 || savedMicros == 1000) ? savedMicros : 0);
        }
        bendMode.store(juce::jlimit(0, 1, xml->getIntAttribute("bendMode", bendMode.load())));
        // Migrate the old 4-state legatoMode (0=off, 1=poly, 2=mono, 3=rtn)
        // to the new 3-state (0=off, 1=mono, 2=rtn): poly was removed.
        {
            const int savedLegato = xml->getIntAttribute("legatoMode", legatoMode.load());
            if (savedLegato >= 2) legatoMode.store(juce::jlimit(0, 2, savedLegato - 1)); // mono 2->1, rtn 3->2
            else                  legatoMode.store(savedLegato == 1 ? 0 : savedLegato); // poly 1->off
        }
        browserPanelWidth.store(juce::jlimit(160, 700, xml->getIntAttribute("browserPanelWidth", browserPanelWidth.load())));
        browserPanelCollapsed.store(xml->getBoolAttribute("browserPanelCollapsed", browserPanelCollapsed.load()));

        // Last-used scale (fallback for new projects)
        pianoRollScaleRoot.store(juce::jlimit(0, 11, xml->getIntAttribute("scaleRoot", pianoRollScaleRoot.load())));
        pianoRollScaleType.store(juce::jlimit(0, 5, xml->getIntAttribute("scaleType", pianoRollScaleType.load())));
        pianoRollScaleLockActive.store(xml->getBoolAttribute("scaleLockActive", pianoRollScaleLockActive.load()));
        hostTabIndex.store(juce::jlimit(0, 1, xml->getIntAttribute("hostTabIndex", hostTabIndex.load())));
        pluginGuiVisible.store(xml->getIntAttribute("pluginGuiVisible", pluginGuiVisible.load() ? 1 : 0) != 0);
        editorWindowWidth.store(juce::jmax(680, xml->getIntAttribute("editorWindowWidth", editorWindowWidth.load())));
        editorWindowHeight.store(juce::jmax(400, xml->getIntAttribute("editorWindowHeight", editorWindowHeight.load())));
    }
}

void WebDAWHostAudioProcessor::loadPluginDescriptionCache()
{
    juce::File cacheFile = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                               .getChildFile("WebDAWHost")
                               .getChildFile("pluginCache.xml");
    if (auto xml = juce::parseXML(cacheFile))
        pluginDescriptionCache.recreateFromXml(*xml);
}

void WebDAWHostAudioProcessor::savePluginDescriptionCache()
{
    if (pluginDescriptionCache.getNumTypes() == 0)
        return;
    juce::File cacheFile = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                               .getChildFile("WebDAWHost")
                               .getChildFile("pluginCache.xml");
    cacheFile.getParentDirectory().createDirectory();
    if (auto xml = pluginDescriptionCache.createXml())
        xml->writeTo(cacheFile);
}

void WebDAWHostAudioProcessor::saveGlobalSettings()
{
    juce::File settingsFile = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                                .getChildFile("WebDAWHost")
                                .getChildFile("settings.xml");
    settingsFile.getParentDirectory().createDirectory();

    juce::XmlElement xml("Settings");
    xml.setAttribute("themeIndex", pianoRollThemeIndex.load());
    xml.setAttribute("pitchNodeSize", (double)pianoRollPitchNodeSize.load());
    xml.setAttribute("pitchLineThickness", (double)pianoRollPitchLineThickness.load());
    xml.setAttribute("gridOpacity", (double)pianoRollGridOpacity.load());
    xml.setAttribute("noteCornerRadius", (double)pianoRollNoteCornerRadius.load());
    xml.setAttribute("playheadThickness", (double)pianoRollPlayheadThickness.load());
    xml.setAttribute("velocityLaneHeight", pianoRollVelocityLaneHeight.load());
    xml.setAttribute("noteContrast", (double)pianoRollNoteContrast.load());
    xml.setAttribute("pitchLineContrast", (double)pianoRollPitchLineContrast.load());
    xml.setAttribute("noteColour", juce::String::toHexString((juce::uint32)pianoRollNoteColour.load()));
    xml.setAttribute("razorColour", juce::String::toHexString((juce::uint32)pianoRollRazorColour.load()));
    xml.setAttribute("pitchLineColour", juce::String::toHexString((juce::uint32)pianoRollPitchLineColour.load()));
    xml.setAttribute("gridBgColour", juce::String::toHexString((juce::uint32)pianoRollGridBgColour.load()));
    xml.setAttribute("gridLineColour", juce::String::toHexString((juce::uint32)pianoRollGridLineColour.load()));
    xml.setAttribute("noteTextColour", juce::String::toHexString((juce::uint32)pianoRollNoteTextColour.load()));
    xml.setAttribute("noteTextBold", pianoRollNoteTextBold.load());
    xml.setAttribute("toolbarTextColour", juce::String::toHexString((juce::uint32)pianoRollToolbarTextColour.load()));
    xml.setAttribute("toolbarTextBold", pianoRollToolbarTextBold.load());
    xml.setAttribute("noteNameColour", juce::String::toHexString((juce::uint32)pianoRollNoteNameColour.load()));
    xml.setAttribute("noteNameBold", pianoRollNoteNameBold.load());
    xml.setAttribute("showNoteNames", pianoRollShowNoteNames.load());
    xml.setAttribute("ghostPitchLines", pianoRollGhostPitchLines.load());
    xml.setAttribute("ghostPitchLineOpacity", pianoRollGhostPitchLineOpacity.load());
    xml.setAttribute("noteNameFontSize", pianoRollNoteNameFontSize.load());
    xml.setAttribute("fontTypeface", pianoRollFontTypefaceIndex.load());
    // Per-type grid line thickness. gridLineThickness is kept (as the bar
    // value) so older versions that only read the single attribute still work.
    xml.setAttribute("gridSubBeatThickness", (double)pianoRollGridSubBeatThickness.load());
    xml.setAttribute("gridHalfBeatThickness", (double)pianoRollGridHalfBeatThickness.load());
    xml.setAttribute("gridBeatThickness", (double)pianoRollGridBeatThickness.load());
    xml.setAttribute("gridBarThickness", (double)pianoRollGridBarThickness.load());
    xml.setAttribute("gridLineThickness", (double)pianoRollGridBarThickness.load());
    xml.setAttribute("keyHeight", (double)pianoRollKeyHeight.load());
    xml.setAttribute("pixelsPerBeat", (double)pianoRollPixelsPerBeat.load());
    xml.setAttribute("viewX", (double)pianoRollViewX.load());
    xml.setAttribute("viewY", (double)pianoRollViewY.load());
    xml.setAttribute("gridDivisorIndex", pianoRollGridDivisorIndex.load());
    xml.setAttribute("toolMode", pianoRollToolMode.load());
    xml.setAttribute("pitchPreview", pianoRollPitchPreview.load());
    xml.setAttribute("showPitchEnvelopes", pianoRollShowPitchEnvelopes.load());
    xml.setAttribute("showVelocityLane", pianoRollShowVelocityLane.load());
    xml.setAttribute("pitchBendRange", pitchBendRange.load());
    xml.setAttribute("pitchShape", pitchShape.load());
    xml.setAttribute("pitchBendStepMicros", pitchBendStepMicros.load());
    xml.setAttribute("bendMode", bendMode.load());
    xml.setAttribute("legatoMode", legatoMode.load());
    xml.setAttribute("browserPanelWidth", browserPanelWidth.load());
    xml.setAttribute("browserPanelCollapsed", browserPanelCollapsed.load());
    xml.setAttribute("scaleRoot", pianoRollScaleRoot.load());
    xml.setAttribute("scaleType", pianoRollScaleType.load());
    xml.setAttribute("scaleLockActive", pianoRollScaleLockActive.load());
    xml.setAttribute("hostTabIndex", hostTabIndex.load());
    xml.setAttribute("pluginGuiVisible", pluginGuiVisible.load() ? 1 : 0);
    xml.setAttribute("editorWindowWidth", editorWindowWidth.load());
    xml.setAttribute("editorWindowHeight", editorWindowHeight.load());

    xml.writeTo(settingsFile);
}

void WebDAWHostAudioProcessor::triggerPanic()
{
    {
        juce::ScopedLock sl(liveMidiLock);
        for (int c = 1; c <= 16; ++c) {
            liveMidiBuffer.addEvent(juce::MidiMessage::allNotesOff(c), 0);
            liveMidiBuffer.addEvent(juce::MidiMessage::allSoundOff(c), 0);
            liveMidiBuffer.addEvent(juce::MidiMessage::allControllersOff(c), 0);
            for (int n = 0; n < 128; ++n) {
                liveMidiBuffer.addEvent(juce::MidiMessage::noteOff(c, n, (juce::uint8)0), 0);
            }
        }
    }
    
    {
        juce::ScopedLock sl(noteLock);
        for (auto& note : notes) {
            note.isPlaying = false;
            note.returnPending = false;
        }
        for (int c = 0; c < 16; ++c) { activeChannels[c] = false; }
    }
}

void WebDAWHostAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    lastPreparedSampleRate.store(sampleRate);
    lastPreparedBlockSize.store(samplesPerBlock);
    juce::ScopedLock sl(processLock);
    int maxChannels = 2;
    if (hostedPlugin != nullptr) {
        hostedPlugin->setPlayHead(getPlayHead());
        hostedPlugin->prepareToPlay(sampleRate, samplesPerBlock);
        setLatencySamples(hostedPlugin->getLatencySamples());
        hostedLatencySamples.store(hostedPlugin->getLatencySamples());
        cachedTailLengthSeconds.store(hostedPlugin->getTailLengthSeconds());
        maxChannels = juce::jmax(maxChannels, hostedPlugin->getTotalNumOutputChannels());
        maxChannels = juce::jmax(maxChannels, hostedPlugin->getTotalNumInputChannels());
    } else {
        setLatencySamples(0);
        hostedLatencySamples.store(0);
        cachedTailLengthSeconds.store(0.0);
    }
    // Allocate with headroom (8 channels) so a plugin loaded later that reports
    // more channels won't force a reallocation on the audio thread.
    pluginBuffer.setSize(juce::jmax(maxChannels, 8), samplesPerBlock);
}

void WebDAWHostAudioProcessor::releaseResources()
{
    if (hostedPlugin != nullptr)
        hostedPlugin->releaseResources();
}

namespace
{
    // Synthetic playhead used during offline render so the hosted plugin sees
    // a moving transport (ppq + timeInSamples) even though the DAW is stopped.
    class RenderPlayHead : public juce::AudioPlayHead
    {
    public:
        juce::Optional<juce::AudioPlayHead::PositionInfo> getPosition() const override { return current; }
        juce::AudioPlayHead::PositionInfo current;
    };
}

bool WebDAWHostAudioProcessor::renderToWavFile(const juce::File& destFile)
{
    // Refuse to bounce while the DAW transport is running.
    if (isHostPlaying.load())
        return false;

    const double sampleRate = lastPreparedSampleRate.load() > 0 ? lastPreparedSampleRate.load() : 48000.0;
    const int blockSize = juce::jmax(32, lastPreparedBlockSize.load());
    const int numOutChannels = juce::jmax(1, getTotalNumOutputChannels());

    // Tempo: prefer the current transport's BPM, fall back to 120.
    double bpm = 120.0;
    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
            bpm = pos->getBpm().orFallback(120.0);

    // Arrangement length: beat 0 .. max(note end) + 2 s tail (for reverb
    // tails), with a 4-beat minimum.
    float maxEndBeat = 0.0f;
    {
        const juce::ScopedLock sl(noteLock);
        for (const auto& n : notes)
            maxEndBeat = juce::jmax(maxEndBeat, n.startBeat + n.lengthBeats);
    }
    const double tailBeats = 2.0 * bpm / 60.0;
    const double totalBeats = juce::jmax(4.0, (double)maxEndBeat + tailBeats);
    const juce::int64 totalSamples = (juce::int64)std::ceil(totalBeats * 60.0 / bpm * sampleRate);

    std::unique_ptr<juce::FileOutputStream> out (destFile.createOutputStream());
    if (out == nullptr)
        return false;

    juce::WavAudioFormat wavFormat;
    std::unique_ptr<juce::AudioFormatWriter> writer(
        wavFormat.createWriterFor(out.get(), sampleRate, numOutChannels, 24, {}, 0));
    if (writer == nullptr)
        return false; // out is destroyed automatically, closing the file

    out.release(); // the writer now owns the stream

    // NOTE: we deliberately do NOT hold processLock for the whole bounce.
    // The DAW's audio thread calls processBlock continuously (even while the
    // transport is stopped); a long lock here would block it for seconds and
    // some hosts punish that (dropouts, plugin resets) — the source of the
    // intermittent Drag WAV failures. processBlock itself locks briefly per
    // block, so the audio thread only ever waits a few microseconds.
    RenderPlayHead renderHead;
    renderHead.current.setIsPlaying(true);
    renderHead.current.setIsLooping(false);
    renderHead.current.setBpm(bpm);

    {
        juce::ScopedLock sl(processLock);
        activeRenderPlayHead = &renderHead;
        if (hostedPlugin != nullptr)
            hostedPlugin->setPlayHead(&renderHead);
    }

    offlineRenderBpm.store(bpm);
    offlineRenderActive.store(true);
    renderThreadId = std::this_thread::get_id(); // only this thread synthesizes

    juce::AudioBuffer<float> blockBuf(numOutChannels, blockSize);
    blockBuf.clear();
    juce::MidiBuffer midi;

    juce::int64 done = 0;
    while (done < totalSamples)
    {
        const int n = (int)juce::jmin<juce::int64>(blockSize, totalSamples - done);
        const double blockStartPpq = (double)done * (bpm / 60.0) / sampleRate;
        offlineRenderPpqStart.store(blockStartPpq);
        renderHead.current.setPpqPosition(blockStartPpq);
        renderHead.current.setTimeInSamples(done);

        blockBuf.clear();
        midi.clear();
        juce::AudioBuffer<float> sub(blockBuf.getArrayOfWritePointers(), numOutChannels, n);
        processBlock(sub, midi);
        writer->writeFromAudioSampleBuffer(sub, 0, n);
        done += n;
    }

    offlineRenderActive.store(false);
    renderThreadId = std::thread::id(); // hand the audio thread back to normal
    {
        juce::ScopedLock sl(processLock);
        activeRenderPlayHead = nullptr;
        if (hostedPlugin != nullptr)
            hostedPlugin->setPlayHead(getPlayHead());
    }

    // Leave the sequencer in a clean, stopped state so the next real
    // transport run doesn't see stale state (e.g. a bogus "jump" detection).
    lastProcessedPpq = -1.0;
    isHostPlaying.store(false);
    clockTransportRunning = false;
    clockQuarters = 0.0;

    writer.reset(); // closes + finalises the WAV
    return true;
}

void WebDAWHostAudioProcessor::startPitchPreview(int midiNote, int noteIndex)
{
    pitchPreviewMidiNote.store(midiNote);
    pitchPreviewNoteIndex.store(noteIndex);
    pitchPreviewJumpBeat.store(-1.0f);
    pitchPreviewActive.store(true);
}

void WebDAWHostAudioProcessor::stopPitchPreview()
{
    pitchPreviewActive.store(false);
}

void WebDAWHostAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    // During an offline render the DAW's audio thread must stay silent and
    // must not touch the hosted plugin (the render thread owns it) — this
    // prevents hearing the bounce and the clicks from double processing.
    if (offlineRenderActive.load() && std::this_thread::get_id() != renderThreadId)
    {
        buffer.clear();
        return;
    }

    // Input metering (before any processing); smoothed with a fast falloff.
    {
        const int n = buffer.getNumSamples();
        float maxLvl = 0.0f;
        for (int ch = 0; ch < totalNumInputChannels; ++ch)
            maxLvl = juce::jmax(maxLvl, buffer.getRMSLevel(ch, 0, n));
        inputLevel.store(juce::jmax(maxLvl, inputLevel.load() * 0.90f));
    }

    // --- SEQUENCER LOGIC ---
    auto posInfo = getPlayHead() ? getPlayHead()->getPosition() : juce::Optional<juce::AudioPlayHead::PositionInfo>();
    
    // Offline render: synthesize the transport from the render position so the
    // sequencer plays the arrangement without a running audio device. The
    // render thread sets offlineRenderPpqStart before each block. Only the
    // render thread synthesizes — the DAW's audio thread was already silenced
    // above, so it must not run the sequencer either.
    if (offlineRenderActive.load() && std::this_thread::get_id() == renderThreadId)
    {
        const double sr = getSampleRate() > 0 ? getSampleRate() : 48000.0;
        const double bpm = offlineRenderBpm.load();
        juce::AudioPlayHead::PositionInfo syn;
        syn.setIsPlaying(true);
        syn.setIsLooping(false);
        syn.setBpm(bpm);
        syn.setTimeInSamples((juce::int64)(offlineRenderPpqStart.load() * 60.0 / juce::jmax(1.0, bpm) * sr));
        syn.setPpqPosition(offlineRenderPpqStart.load());
        posInfo = syn;
    }
    
    if (posInfo.hasValue()) 
    {
        bool playing = posInfo->getIsPlaying();
        bool wasPlaying = isHostPlaying.load();
        isHostPlaying.store(playing);
        
        if (wasPlaying && !playing) {
            const juce::ScopedLock sl (noteLock);
            for (auto& note : notes) {
                if (note.isPlaying) {
                    midiMessages.addEvent(juce::MidiMessage::noteOff(note.playingChannel, noteOffPitch(note), (juce::uint8)0), 0);
                    note.isPlaying = false;
                }
            }
            for (int c = 0; c < 16; ++c) { activeChannels[c] = false; }
        }
        
        auto loopPoints = posInfo->getLoopPoints();
        if (loopPoints.hasValue()) {
            isLooping.store(true);
            loopStartBeat.store((float)loopPoints->ppqStart);
            loopEndBeat.store((float)loopPoints->ppqEnd);
        } else {
            isLooping.store(posInfo->getIsLooping());
        }
        
        if (playing)
        {
            double currentPpq = posInfo->getPpqPosition().orFallback(0.0);
            double tempo = posInfo->getBpm().orFallback(120.0);
            currentPlayheadBeat.store((float)currentPpq);

            double blockLengthBeats = (buffer.getNumSamples() / getSampleRate()) * (tempo / 60.0);
            double nextPpq = currentPpq + blockLengthBeats;

            const juce::ScopedLock sl (noteLock);

            const int bendRangeForBlock = pitchBendRange.load();
            for (int c = 1; c <= 16; ++c)
            {
                const int chanIdx = c - 1;
                if (lastPitchBendRangeSent[chanIdx] != bendRangeForBlock)
                {
                    addPitchBendRangeMessages(midiMessages, c, bendRangeForBlock, 0);
                    lastPitchBendRangeSent[chanIdx] = bendRangeForBlock;
                    lastPitchBendValue[chanIdx] = -1;
                }
            }
            
            // Detect playhead jump (e.g. looping back to start, or user clicking timeline)
            if (lastProcessedPpq >= 0.0 && currentPpq < lastProcessedPpq - 0.001) 
            {
                for (auto& note : notes)
                {
                    if (note.isPlaying)
                    {
                        midiMessages.addEvent(juce::MidiMessage::noteOff(note.playingChannel, noteOffPitch(note), (juce::uint8)0), 0);
                        note.isPlaying = false;
                        note.returnPending = false;
                        if (note.playingChannel >= 1 && note.playingChannel <= 16) {
                            activeChannels[note.playingChannel - 1] = false;
                        }
                    }
                }
            }

            for (auto& note : notes)
            {
                // Trigger Note On
                if (note.startBeat >= currentPpq && note.startBeat < nextPpq && !note.isPlaying)
                {
                    int sampleOffset = (int)(((note.startBeat - currentPpq) / blockLengthBeats) * buffer.getNumSamples());
                    sampleOffset = juce::jlimit(0, buffer.getNumSamples() - 1, sampleOffset);

                    // Notes ALWAYS play on channels 2-16 (channel 1 stays free:
                    // in MPE mode it is the master, in Pitch Bend mode it
                    // carries the shared wheel).
                    const int legatoModeValue = legatoMode.load();
                    const bool monoLegato = (legatoModeValue == 1);
                    const bool returnLegato = (legatoModeValue == 2);
                    const bool cutLegato = monoLegato || returnLegato;

                    // MONO / RETURN legato: cut every other sounding note
                    // before this note's note-on, so only ONE note sounds at a
                    // time (the note still starts at its own pitch — legato
                    // never carries the wheel over). The last cut note's
                    // channel is reused for continuity. In RETURN mode each
                    // cut note is marked as a return candidate — retriggered
                    // when this note ends, if still held.
                    //
                    // The cut note-off is sent a few ms EARLY (not 1-2 samples
                    // before the note-on): a note-off/note-on pair that close
                    // together makes the old note click and can CHOKE the new
                    // note on instruments with voice stealing or on same-pitch
                    // retriggers. ~5 ms gives the instrument time to close the
                    // old voice cleanly before the new note-on lands.
                    int lastPlayingChannel = -1;
                    if (cutLegato)
                    {
                        const int earlyCutSamples = juce::jmax(2, (int)(getSampleRate() * 0.005)); // ~5 ms
                        for (auto& n2 : notes)
                        {
                            if (&n2 != &note && n2.isPlaying)
                            {
                                lastPlayingChannel = n2.playingChannel;
                                // The cut note-off must NEVER land before the cut
                                // note's own note-on. When both notes start inside
                                // the SAME audio block (e.g. the notes of a chord),
                                // the cut note's note-on is emitted this block at
                                // sampleOffset(n2)+1 — placing this note-off at
                                // sampleOffset - 5 ms (or sample 0) makes the
                                // instrument see off -> on: the cut voice starts
                                // ringing while isPlaying is already false, so the
                                // sequencer never sends its release and the voice
                                // hangs on sustain until Panic. Clamp the cut to at
                                // least 2 samples AFTER the cut note's onset.
                                const int n2OnsetSample = beatToSampleOffset(n2.startBeat, currentPpq, blockLengthBeats, buffer.getNumSamples());
                                const int cutSample = juce::jlimit(0, buffer.getNumSamples() - 1,
                                                                   juce::jmax(juce::jmax(0, sampleOffset - earlyCutSamples),
                                                                              n2OnsetSample + 2));
                                midiMessages.addEvent(juce::MidiMessage::noteOff(n2.playingChannel, noteOffPitch(n2), (juce::uint8)0), cutSample);
                                n2.isPlaying = false;
                                if (returnLegato)
                                    n2.returnPending = true; // may be retriggered later
                                if (n2.playingChannel >= 1 && n2.playingChannel <= 16)
                                    activeChannels[n2.playingChannel - 1] = false;
                            }
                        }
                    }

                    int assignedChannel = 1;
                    if (cutLegato && lastPlayingChannel >= 2)
                        assignedChannel = lastPlayingChannel; // reuse the cut note's channel
                    for (int c = 2; c <= 16 && assignedChannel == 1; ++c)
                    {
                        if (!activeChannels[c - 1])
                        {
                            assignedChannel = c;
                            break;
                        }
                    }
                    // All 15 note channels busy (dense polyphony): steal the
                    // channel of the OLDEST still-sounding note so the new note
                    // always lands on a real note channel — channel 1 must stay
                    // free (MPE master / shared pitch wheel).
                    if (assignedChannel == 1)
                    {
                        int oldestIndex = -1;
                        float oldestStartBeat = std::numeric_limits<float>::max();
                        for (int i = 0; i < (int)notes.size(); ++i)
                        {
                            if (&notes[i] != &note && notes[i].isPlaying && notes[i].playingChannel >= 2
                                && notes[i].startBeat < oldestStartBeat)
                            {
                                oldestStartBeat = notes[i].startBeat;
                                oldestIndex = i;
                            }
                        }
                        if (oldestIndex >= 0)
                        {
                            NoteEvent& victim = notes[oldestIndex];
                            midiMessages.addEvent(juce::MidiMessage::noteOff(victim.playingChannel, noteOffPitch(victim), (juce::uint8)0), 0);
                            victim.isPlaying = false;
                            victim.returnPending = false;
                            assignedChannel = victim.playingChannel;
                        }
                    }
                    if (assignedChannel >= 2)
                        activeChannels[assignedChannel - 1] = true;
                    note.playingChannel = assignedChannel;

                    // Back-to-back SAME-PITCH notes on the shared channel: the
                    // previous note's note-off (same note number, same channel)
                    // must land BEFORE this note's note-on, or it cuts the new
                    // note off instantly (heard as "no sound on the second
                    // note"). Delay the note-on until after any same-channel
                    // note that ends at/after this note's start. Also keeps the
                    // reset pitch-wheel strictly before the note-on.
                    int latestEndSample = sampleOffset;
                    for (const auto& n2 : notes)
                    {
                        if (&n2 != &note && n2.isPlaying && n2.playingChannel == assignedChannel)
                        {
                            const int n2End = beatToSampleOffset(n2.startBeat + n2.lengthBeats, currentPpq, blockLengthBeats, buffer.getNumSamples());
                            if (n2End >= sampleOffset)
                                latestEndSample = juce::jmax(latestEndSample, n2End);
                        }
                    }
                    const int noteOnOffset = juce::jmin(buffer.getNumSamples() - 1, juce::jmax(1, latestEndSample + 1));

                    // Never start a note at/after its own end. If the
                    // same-channel backlog pushes the onset past the note's end
                    // (dense polyphony, same-pitch retriggers), the note-off
                    // would be emitted BEFORE the note-on in the same buffer —
                    // the instrument would get a bare note-on with no release,
                    // i.e. a stuck voice that only Panic can kill.
                    if (note.startBeat + note.lengthBeats < nextPpq)
                    {
                        const int ownEndSample = beatToSampleOffset(note.startBeat + note.lengthBeats, currentPpq, blockLengthBeats, buffer.getNumSamples());
                        if (noteOnOffset >= ownEndSample)
                        {
                            if (assignedChannel >= 2)
                                activeChannels[assignedChannel - 1] = false;
                            continue; // onset swallowed by the backlog: stays silent
                        }
                    }
                    const int pitchSetupOffset = noteOnOffset - 1;

                    // Bend channel: Pitch Bend mode -> SHARED channel 1 (the
                    // wheel the instrument honors), MPE mode -> the note's own
                    // channel.
                    const bool perNoteWheel = (bendMode.load() == 1);
                    const int bendCh = perNoteWheel ? note.playingChannel : 1;
                    const int chanIdx = bendCh - 1;
                    int bendRange = pitchBendRange.load();

                    // ALWAYS re-send the RPN pitch-bend-range at note-on, even
                    // if the range hasn't changed. Some instruments (notably
                    // Kontakt) miss or ignore an RPN sent long before the note
                    // (e.g. after a previous note released the channel, or when
                    // the RPN and note-on share sample 0), leaving them bending
                    // with the WRONG range -> the slide undershoots the target.
                    addPitchBendRangeMessages(midiMessages, bendCh, bendRange, pitchSetupOffset);
                    lastPitchBendRangeSent[chanIdx] = bendRange;

                    const int initialPB = pitchBendToMidiValue(evaluatePitchBendAtBeat(note, 0.0f, pitchShape.load()), bendRange);

                    // ALWAYS reset the wheel to THIS note's own start pitch at
                    // note-on. The pitch points at the start of each note are
                    // authoritative: every note begins at its own curve value
                    // (usually 0 = no bend), in every legato mode. Legato only
                    // controls note cutting/retriggering — it never carries the
                    // wheel over from the previous note.
                    midiMessages.addEvent(juce::MidiMessage::pitchWheel(bendCh, initialPB), pitchSetupOffset);
                    lastPitchBendValue[chanIdx] = initialPB;

                    // Belt-and-braces: also place the reset wheel at the exact
                    // note-on instant (immediately before the note-on), so the
                    // bend channel's wheel always starts at this note's pitch.
                    midiMessages.addEvent(juce::MidiMessage::pitchWheel(bendCh, initialPB), noteOnOffset);

                    // Shared-wheel ownership (Pitch Bend mode): this note now
                    // owns the wheel, so every OLDER still-sounding note
                    // (started before this one, still ringing at its onset) is
                    // permanently silenced — otherwise its ongoing curve would
                    // override this note's reset and the new note would slide
                    // instead of starting at its own pitch. Legato OFF + two
                    // overlapping notes on the shared wheel: the newest note
                    // wins the wheel for the rest of its life. Notes starting
                    // at the SAME beat (a chord) are never marked — they keep
                    // streaming (their curves usually match).
                    note.wheelSuperseded = false;
                    note.wheelTakeoverBeat = -1.0f;
                    if (!perNoteWheel)
                    {
                        for (auto& n2 : notes)
                        {
                            if (&n2 != &note && n2.isPlaying
                                && note.startBeat > n2.startBeat + 0.0001f          // n2 is strictly older
                                && n2.startBeat + n2.lengthBeats > note.startBeat + 0.0001f) // still ringing
                            {
                                n2.wheelSuperseded = true;
                                if (n2.wheelTakeoverBeat < 0.0f || note.startBeat < n2.wheelTakeoverBeat)
                                    n2.wheelTakeoverBeat = note.startBeat;
                            }
                        }
                    }

                    midiMessages.addEvent(juce::MidiMessage::noteOn(note.playingChannel, note.midiNote, note.velocity), noteOnOffset);
                    note.isPlaying = true;
                    note.soundingMidiNote = note.midiNote; // remember the pitch actually sent
                }
            }

            // Calculate high-resolution pitch bend before processing note-offs.
            for (auto& note : notes) {
                if (note.isPlaying) {
                    int firstSample = 0;
                    int lastSample = buffer.getNumSamples() - 1;
                    double endBeat = note.startBeat + note.lengthBeats;

                    if (note.startBeat >= currentPpq && note.startBeat < nextPpq)
                        firstSample = beatToSampleOffset(note.startBeat, currentPpq, blockLengthBeats, buffer.getNumSamples());

                    if (endBeat >= currentPpq && endBeat < nextPpq)
                        lastSample = juce::jmax(firstSample, beatToSampleOffset(endBeat, currentPpq, blockLengthBeats, buffer.getNumSamples()) - 1);

                    // Bend channel: the note's own channel in MPE mode, the
                    // shared channel-1 wheel in Pitch Bend mode.
                    const bool perNoteWheel = (bendMode.load() == 1);
                    const int bendCh = perNoteWheel ? note.playingChannel : 1;
                    int chanIdx = bendCh - 1;
                    if (chanIdx < 0 || chanIdx >= 16)
                        continue;

                    // Shared-wheel ownership (Pitch Bend mode): only the
                    // NEWEST note on the channel-1 wheel may drive it. If a
                    // newer note took over the wheel while this note was still
                    // sounding, this note's bend stream is permanently
                    // silenced — otherwise its ongoing curve would override
                    // the newer note's reset and the new note would slide
                    // instead of starting at its own pitch (0). The takeover
                    // beat was recorded at note-on. In MPE mode every note has
                    // its own wheel, so this never applies.
                    if (!perNoteWheel && note.wheelSuperseded)
                    {
                        // Takeover already happened before this block: this
                        // note no longer touches the wheel at all.
                        if (note.wheelTakeoverBeat <= currentPpq + 1e-9)
                            continue;

                        // Takeover lands inside this block: stop streaming one
                        // sample BEFORE the newer note's onset so its reset
                        // wheel (emitted at onset-1 / onset) always wins — a
                        // same-sample collision would let the old note's bend
                        // override the new note's reset.
                        if (note.wheelTakeoverBeat < nextPpq)
                        {
                            const int takeoverSample = beatToSampleOffset(note.wheelTakeoverBeat, currentPpq, blockLengthBeats, buffer.getNumSamples());
                            lastSample = juce::jmin(lastSample, takeoverSample - 2);
                        }

                        // Nothing left to stream in this block (takeover landed
                        // at/before this note's first sample here).
                        if (lastSample < firstSample)
                            continue;
                    }

                    const int pitchStepSamples = getPitchBendStepSamples(getSampleRate(), pitchBendStepMicros.load());
                    const int bendRange = pitchBendRange.load();
                    const int shape = pitchShape.load();
                    const float sampleLengthBeats = (float)(blockLengthBeats / (double)buffer.getNumSamples());

                    if (lastPitchBendRangeSent[chanIdx] != bendRange) {
                        addPitchBendRangeMessages(midiMessages, bendCh, bendRange, firstSample);
                        lastPitchBendRangeSent[chanIdx] = bendRange;
                        lastPitchBendValue[chanIdx] = -1;
                    }

                    if (note.pitchCurve.empty())
                        continue;

                    // Flood protection: at "Maximum (1 sample)" a fast big
                    // slide can generate ~512 pitch-wheel events per note per
                    // block; many hosts/instruments (e.g. Kontakt) then drop or
                    // misorder the tail of the queue, so the slide never lands
                    // on the target pitch. We cap the intermediate stream and
                    // ALWAYS force the final (target) value at the note end.
                    int wheelEventsThisBlock = 0;
                    // ~96 events/block = ~0.11 ms effective steps at a 512
                    // block — still finer than "Fine (0.25 ms)" — but low
                    // enough that hosts/instruments (e.g. Kontakt) never
                    // choke on a Maximum-resolution fast slide.
                    const int maxWheelEventsPerBlock = 96;

                    auto emitPitchBendValueAtSample = [&] (int sampleOffset, float bendSemitones, bool forceFinal)
                    {
                        sampleOffset = juce::jlimit(firstSample, lastSample, sampleOffset);
                        int newPitchBendValue = pitchBendToMidiValue(bendSemitones, bendRange);

                        if (newPitchBendValue != lastPitchBendValue[chanIdx]
                            && (forceFinal || wheelEventsThisBlock < maxWheelEventsPerBlock))
                        {
                            midiMessages.addEvent(juce::MidiMessage::pitchWheel(bendCh, newPitchBendValue), sampleOffset);
                            lastPitchBendValue[chanIdx] = newPitchBendValue;
                            if (!forceFinal)
                                ++wheelEventsThisBlock;
                        }
                    };

                    auto emitPitchBendAtSample = [&] (int sampleOffset, bool forceFinal)
                    {
                        sampleOffset = juce::jlimit(firstSample, lastSample, sampleOffset);
                        double samplePpq = currentPpq + (sampleOffset / (double)buffer.getNumSamples()) * blockLengthBeats;
                        float beatOffset = (float)(samplePpq - note.startBeat);
                        float bendSemitones = evaluatePitchBendAtBeat(note, beatOffset, shape);
                        const float noteLength = juce::jmax(0.0f, note.lengthBeats);

                        if (shape == 1) {
                            // One full pitch-step window so square-shape nodes
                            // are caught at the coarser (~1 ms) step rate.
                            const float nodeLeadBeats = sampleLengthBeats * (float)pitchStepSamples;
                            for (const auto& point : note.pitchCurve) {
                                const float pointOffset = juce::jlimit(0.0f, noteLength, point.x);
                                if (pointOffset > beatOffset && pointOffset <= beatOffset + nodeLeadBeats) {
                                    bendSemitones = point.y;
                                    break;
                                }
                            }
                        }

                        emitPitchBendValueAtSample(sampleOffset, bendSemitones, forceFinal);
                    };

                    for (int sampleOffset = firstSample; sampleOffset <= lastSample; sampleOffset += pitchStepSamples) {
                        emitPitchBendAtSample(sampleOffset, false);
                    }

                    if (lastSample > firstSample && ((lastSample - firstSample) % pitchStepSamples) != 0)
                        emitPitchBendAtSample(lastSample, false);

                    // Guarantee the slide lands EXACTLY on the curve's end value
                    // (the target pitch). At the final sample of the note the
                    // curve is still interpolating toward the last node (a few
                    // cents short on fast slides), so on the block where the
                    // note ends, evaluate AT the last node position instead.
                    // A superseded note never forces its end value — the wheel
                    // belongs to the newer note now.
                    if (!note.wheelSuperseded && endBeat >= currentPpq && endBeat < nextPpq) {
                        const float exactEndBend = evaluatePitchBendAtBeat(note, juce::jmax(0.0f, note.lengthBeats), shape);
                        emitPitchBendValueAtSample(lastSample, exactEndBend, true);
                    } else if (!note.wheelSuperseded) {
                        emitPitchBendAtSample(lastSample, true);
                    }
                }
            }

            for (auto& note : notes)
            {
                double endBeat = note.startBeat + note.lengthBeats;

                if (note.isPlaying && endBeat < currentPpq)
                {
                    midiMessages.addEvent(juce::MidiMessage::noteOff(note.playingChannel, noteOffPitch(note), (juce::uint8)0), 0);
                    note.isPlaying = false;

                    if (note.playingChannel >= 1 && note.playingChannel <= 16) {
                        activeChannels[note.playingChannel - 1] = false;
                    }
                }
                else if (endBeat >= currentPpq && endBeat < nextPpq && note.isPlaying)
                {
                    int sampleOffset = beatToSampleOffset(endBeat, currentPpq, blockLengthBeats, buffer.getNumSamples());
                    // Never place a note-off on the very last sample of a block:
                    // a back-to-back note-on (same pitch) may be clamped there,
                    // and the note-off must precede it (1 sample early is
                    // inaudible).
                    if (sampleOffset >= buffer.getNumSamples() - 1)
                        sampleOffset = buffer.getNumSamples() - 2;

                    // If another note shares this note's BEND channel and
                    // starts at (or right before) this note's end, its RESET
                    // pitch-wheel must win — skip the end-pitch emission
                    // entirely. Otherwise the old note's end bend would be
                    // inserted after the new note's reset and override it at
                    // the new note's onset. (Pitch Bend mode: all notes share
                    // the channel-1 wheel, so ANY note conflicts.)
                    const bool perNoteWheel = (bendMode.load() == 1);
                    bool channelReusedAtEnd = false;
                    for (const auto& n2 : notes)
                    {
                        const bool sameBendChannel = perNoteWheel ? (n2.playingChannel == note.playingChannel) : true;
                        if (&n2 != &note && n2.isPlaying && sameBendChannel
                            && n2.startBeat <= endBeat + 0.0001)
                        {
                            channelReusedAtEnd = true;
                            break;
                        }
                    }

                    // Land EXACTLY on the target pitch at release. The exact
                    // curve-end value is emitted TWICE, unconditionally:
                    //   1) ~2 ms before the note-off, so the pitch has time to
                    //      SETTLE at the target before the release (important
                    //      for fast slides, where instruments like Kontakt may
                    //      smooth/delay dense pitch-wheel streams), and
                    //   2) again AT the note-off instant, as the last event.
                    // This bypasses dedupe so the target can never be skipped.
                    // A superseded note no longer owns the wheel: it must not
                    // re-assert its curve end value at release (that would jump
                    // the wheel away from the newer note's pitch).
                    if (!channelReusedAtEnd && !note.pitchCurve.empty() && !note.wheelSuperseded)
                    {
                        const int bendCh = perNoteWheel ? note.playingChannel : 1;
                        const int chanIdx = bendCh - 1;
                        if (chanIdx >= 0 && chanIdx < 16)
                        {
                            const float exactEndBend = evaluatePitchBendAtBeat(note, juce::jmax(0.0f, note.lengthBeats), pitchShape.load());
                            const int endValue = pitchBendToMidiValue(exactEndBend, pitchBendRange.load());

                            const int settleOffset = juce::jmax(0, sampleOffset - (int)juce::jmax(2.0, getSampleRate() * 0.002));
                            midiMessages.addEvent(juce::MidiMessage::pitchWheel(bendCh, endValue), settleOffset);
                            midiMessages.addEvent(juce::MidiMessage::pitchWheel(bendCh, endValue), sampleOffset);
                            lastPitchBendValue[chanIdx] = endValue;
                        }
                    }

                    midiMessages.addEvent(juce::MidiMessage::noteOff(note.playingChannel, noteOffPitch(note), (juce::uint8)0), sampleOffset);
                    note.isPlaying = false;

                    if (note.playingChannel >= 1 && note.playingChannel <= 16) {
                        activeChannels[note.playingChannel - 1] = false;
                    }

                    // RETURN legato: the top note just ended — retrigger the
                    // cut note underneath (latest-started still-held one) at
                    // its own start pitch. Only if the cut note is STILL HELD
                    // (its end is after this note's end); otherwise it stays
                    // silent.
                    if (legatoMode.load() == 2 && !note.returnPending)
                    {
                        NoteEvent* returnNote = nullptr;
                        for (auto& n2 : notes)
                        {
                            if (&n2 != &note && n2.returnPending
                                && (n2.startBeat + n2.lengthBeats) > endBeat + 0.0001
                                && (returnNote == nullptr || n2.startBeat > returnNote->startBeat))
                                returnNote = &n2;
                        }

                        if (returnNote != nullptr)
                        {
                            // Same stuck-note guard as the regular note-on: the
                            // retriggered note must not start at/after its own
                            // end (its note-off would be delivered before the
                            // note-on, leaving a ringing voice).
                            if (returnNote->startBeat + returnNote->lengthBeats < nextPpq)
                            {
                                const int returnEndSample = beatToSampleOffset(returnNote->startBeat + returnNote->lengthBeats, currentPpq, blockLengthBeats, buffer.getNumSamples());
                                const int retriggerOffset = juce::jmin(buffer.getNumSamples() - 1, sampleOffset + 1);
                                if (retriggerOffset >= returnEndSample)
                                {
                                    returnNote->returnPending = false; // stays silent
                                    continue;
                                }
                            }

                            returnNote->returnPending = false;

                            // Retrigger on the just-freed channel of the note
                            // that ended (continuity), right after its note-off.
                            returnNote->playingChannel = note.playingChannel;
                            if (note.playingChannel >= 1 && note.playingChannel <= 16)
                                activeChannels[note.playingChannel - 1] = true;
                            const int retriggerOffset = juce::jmin(buffer.getNumSamples() - 1, sampleOffset + 1);
                            midiMessages.addEvent(juce::MidiMessage::noteOn(returnNote->playingChannel, returnNote->midiNote, returnNote->velocity), retriggerOffset);
                            returnNote->isPlaying = true;
                            returnNote->soundingMidiNote = returnNote->midiNote;
                            // Fresh note-on: reclaim the shared wheel.
                            returnNote->wheelSuperseded = false;
                            returnNote->wheelTakeoverBeat = -1.0f;

                            // The retriggered note starts at ITS OWN pitch:
                            // reset the wheel to the returned note's start
                            // value right before its note-on.
                            const bool perNoteWheelR = (bendMode.load() == 1);
                            const int bendChR = perNoteWheelR ? returnNote->playingChannel : 1;
                            const int chanIdxR = bendChR - 1;
                            if (chanIdxR >= 0 && chanIdxR < 16)
                            {
                                const int retriggerPB = pitchBendToMidiValue(evaluatePitchBendAtBeat(*returnNote, 0.0f, pitchShape.load()), pitchBendRange.load());
                                midiMessages.addEvent(juce::MidiMessage::pitchWheel(bendChR, retriggerPB), juce::jmax(0, retriggerOffset - 1));
                                lastPitchBendValue[chanIdxR] = retriggerPB;
                            }
                        }

                        // Forget cut notes that are no longer held (they ended
                        // before/at this point) — never retrigger those.
                        for (auto& n2 : notes)
                            if (n2.returnPending && (n2.startBeat + n2.lengthBeats) <= endBeat + 0.0001)
                                n2.returnPending = false;
                    }
                }
            }
            
            lastProcessedPpq = currentPpq;
        }
        else
        {
            double currentPpq = posInfo->getPpqPosition().orFallback(0.0);
            currentPlayheadBeat.store((float)currentPpq);
            lastProcessedPpq = -1.0;
            
            // If DAW stopped, kill all playing notes
            const juce::ScopedLock sl (noteLock);
            for (auto& note : notes)
            {
                if (note.isPlaying)
                {
                    midiMessages.addEvent(juce::MidiMessage::noteOff(note.playingChannel, noteOffPitch(note), (juce::uint8)0), 0);
                    note.isPlaying = false;
                    note.returnPending = false;
                    if (note.playingChannel >= 1 && note.playingChannel <= 16) {
                        activeChannels[note.playingChannel - 1] = false;
                    }
                }
            }
        }
    }

    // --- Live pitch-bend preview (audio thread, WYSIWYG) ---
    // The UI toggles pitchPreviewActive when a pitch point is grabbed; here we
    // sustain the note and sweep its full bend curve using the SAME pitch-bend
    // math and resolution as real playback, so the preview is bit-exact.
    {
        const bool previewActive = pitchPreviewActive.load();
        const int pNoteIdx = pitchPreviewNoteIndex.load();
        const int pNote = pitchPreviewMidiNote.load();

        if (previewActive && !isHostPlaying.load() && pNote >= 0 && pNoteIdx >= 0 && (size_t)pNoteIdx < notes.size())
        {
            const juce::ScopedLock sl(noteLock);
            auto& pn = notes[(size_t)pNoteIdx];
            const double noteLen = juce::jmax(0.05, (double)pn.lengthBeats);

            // Tempo for sample->beat conversion (the sweep must advance even
            // while the transport is stopped and reports no ppq movement).
            double previewBpm = 120.0;
            if (posInfo.hasValue())
                previewBpm = posInfo->getBpm().orFallback(120.0);
            const double previewBlockBeats = ((double)buffer.getNumSamples() / getSampleRate()) * (previewBpm / 60.0);

            // Preview: the note always plays on channel 2; the pitch wheel
            // goes to channel 1 in Pitch Bend mode (shared wheel) or channel 2
            // in MPE mode (per-note wheel).
            const bool perNoteWheel = (bendMode.load() == 1);
            const int pChan = 2;
            const int pWheelCh = perNoteWheel ? 2 : 1;

            // Jump the sweep playhead to the dragged spot (set by the UI).
            const float jumpBeat = pitchPreviewJumpBeat.exchange(-1.0f);
            if (jumpBeat >= 0.0f)
                previewPlayheadBeats = juce::jmin((double)jumpBeat, noteLen - 0.001);

            if (!previewNoteSounding)
            {
                const int bendRange = pitchBendRange.load();
                addPitchBendRangeMessages(midiMessages, pWheelCh, bendRange, 0);
                const int initialPB = pitchBendToMidiValue(evaluatePitchBendAtBeat(pn, 0.0f, pitchShape.load()), bendRange);
                midiMessages.addEvent(juce::MidiMessage::pitchWheel(pWheelCh, initialPB), 0);
                midiMessages.addEvent(juce::MidiMessage::noteOn(pChan, pNote, (juce::uint8)100), 0);
                previewNoteSounding = true;
                previewSoundingNote = pNote;
                previewPlayheadBeats = 0.0;
            }

            const int stepSamples = getPitchBendStepSamples(getSampleRate(), pitchBendStepMicros.load());
            const int bendRange = pitchBendRange.load();
            const int shape = pitchShape.load();
            const int numSamples = buffer.getNumSamples();

            int lastValueSent = -1;
            int previewWheelEventsThisBlock = 0;
            const int maxPreviewWheelEventsPerBlock = 96; // same flood protection as playback
            for (int s = 0; s < numSamples; s += stepSamples)
            {
                const double beat = previewPlayheadBeats + ((double)s / (double)numSamples) * previewBlockBeats;
                if (beat >= noteLen)
                    break;
                const float bend = evaluatePitchBendAtBeat(pn, (float)beat, shape);
                const int v = pitchBendToMidiValue(bend, bendRange);
                if (v != lastValueSent && previewWheelEventsThisBlock < maxPreviewWheelEventsPerBlock)
                {
                    midiMessages.addEvent(juce::MidiMessage::pitchWheel(pWheelCh, v), s);
                    lastValueSent = v;
                    ++previewWheelEventsThisBlock;
                }
            }

            // Guarantee the sweep lands on the curve's final value this block.
            {
                const float finalBend = evaluatePitchBendAtBeat(pn, (float)juce::jmin(previewPlayheadBeats + previewBlockBeats, noteLen - 0.0001), shape);
                const int fv = pitchBendToMidiValue(finalBend, bendRange);
                if (fv != lastValueSent)
                    midiMessages.addEvent(juce::MidiMessage::pitchWheel(pWheelCh, fv), numSamples - 1);
            }

            previewPlayheadBeats += previewBlockBeats;
            if (previewPlayheadBeats >= noteLen)
            {
                // Clean loop pass: note-off at the end of this block, note-on
                // at the start of the next (a short gap, no pitch jump).
                midiMessages.addEvent(juce::MidiMessage::noteOff(pChan, previewSoundingNote, (juce::uint8)0), numSamples - 1);
                previewNoteSounding = false;
                previewPlayheadBeats = 0.0;
            }
        }
        else if (previewNoteSounding)
        {
            midiMessages.addEvent(juce::MidiMessage::noteOff(2, previewSoundingNote, (juce::uint8)0), 0);
            previewNoteSounding = false;
        }
    }

    // --- MIDI clock out (24 PPQ) to the hosted plugin ---
    // Emits start/continue/stop on transport edges and midiClock() ticks at
    // 24 per quarter note so tempo-synced plugins follow the host transport.
    if (midiClockEnabled.load() && !offlineRenderActive.load() && posInfo.hasValue())
    {
        const bool playing = posInfo->getIsPlaying();
        const double tempo = posInfo->getBpm().orFallback(120.0);

        if (playing != clockTransportRunning)
        {
            clockTransportRunning = playing;
            clockQuarters = 0.0;
            if (playing)
            {
                const double ppq = posInfo->getPpqPosition().orFallback(0.0);
                midiMessages.addEvent(ppq < 0.5 ? juce::MidiMessage::midiStart() : juce::MidiMessage::midiContinue(), 0);
            }
            else
            {
                midiMessages.addEvent(juce::MidiMessage::midiStop(), 0);
            }
        }

        if (playing)
        {
            const double blockBeats = (buffer.getNumSamples() / getSampleRate()) * (tempo / 60.0);
            const double startQuarters = clockQuarters;
            clockQuarters += blockBeats;
            const double t0 = startQuarters * 24.0;
            const double t1 = clockQuarters * 24.0;
            const int firstTick = (int)std::ceil(t0 - 1e-9);
            const int lastTick = (int)std::floor(t1 - 1e-9);
            for (int t = firstTick; t <= lastTick; ++t)
            {
                const double span = t1 - t0;
                const double frac = span > 1e-12 ? (t - t0) / span : 0.0;
                const int sample = juce::jlimit(0, buffer.getNumSamples() - 1, (int)(frac * buffer.getNumSamples()));
                midiMessages.addEvent(juce::MidiMessage::midiClock(), sample);
            }
        }
    }

    // Merge live MIDI from UI (preview clicks)
    {
        juce::ScopedLock sl(liveMidiLock);
        midiMessages.addEvents(liveMidiBuffer, 0, buffer.getNumSamples(), 0);
        liveMidiBuffer.clear();
    }

    // Pass processing to the hosted plugin (e.g., Kontakt)
    juce::ScopedLock slPlugin(processLock);
    if (hostedPlugin != nullptr)
    {
        int numSamples = buffer.getNumSamples();
        int pluginIns = hostedPlugin->getTotalNumInputChannels();
        int pluginOuts = hostedPlugin->getTotalNumOutputChannels();
        int ourIns = getTotalNumInputChannels();
        int ourOuts = getTotalNumOutputChannels();
        
        // Ensure pluginBuffer is internally large enough (should be handled in prepareToPlay)
        int maxChans = juce::jmax(pluginIns, pluginOuts, ourOuts);
        if (pluginBuffer.getNumChannels() < maxChans || pluginBuffer.getNumSamples() < numSamples)
            pluginBuffer.setSize(maxChans, numSamples, false, false, true); // avoidReallocating=true
            
        // Create an alias buffer pointing to our internal memory but with the exact block size
        juce::AudioBuffer<float> subBuffer (pluginBuffer.getArrayOfWritePointers(), maxChans, numSamples);
        subBuffer.clear();
        
        // Copy host inputs to plugin buffer
        for (int i = 0; i < pluginIns; ++i) {
            if (i < ourIns)
                subBuffer.copyFrom(i, 0, buffer, i, 0, numSamples);
        }
        
        // Process through the plugin (the synthetic render playhead wins
        // during an offline bounce so the plugin sees a moving transport).
        hostedPlugin->setPlayHead(activeRenderPlayHead != nullptr ? activeRenderPlayHead : getPlayHead());
        hostedPlugin->processBlock(subBuffer, midiMessages);
        
        // Copy plugin outputs back to host buffer
        buffer.clear();
        for (int i = 0; i < ourOuts; ++i) {
            if (i < pluginOuts)
                buffer.copyFrom(i, 0, subBuffer, i, 0, numSamples);
        }
    }

    // Output metering (post plugin); smoothed with a fast falloff.
    {
        const int n = buffer.getNumSamples();
        float maxLvl = 0.0f;
        for (int ch = 0; ch < totalNumOutputChannels; ++ch)
            maxLvl = juce::jmax(maxLvl, buffer.getRMSLevel(ch, 0, n));
        outputLevel.store(juce::jmax(maxLvl, outputLevel.load() * 0.90f));
    }
}

juce::AudioProcessorEditor* WebDAWHostAudioProcessor::createEditor()
{
    return new WebDAWHostAudioProcessorEditor (*this);
}

void WebDAWHostAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    juce::XmlElement state("WebDAWHostState");
    state.setAttribute("version", 4);
    state.setAttribute("pitchBendRange", pitchBendRange.load());
    state.setAttribute("pitchShape", pitchShape.load());
    state.setAttribute("pitchBendStepMicros", pitchBendStepMicros.load());
    state.setAttribute("mpeMode", bendMode.load());
    state.setAttribute("legatoMode", legatoMode.load());
    state.setAttribute("midiClockEnabled", midiClockEnabled.load() ? 1 : 0);

    juce::MemoryBlock hostedPluginState;
    {
        juce::ScopedLock sl(processLock);
        state.setAttribute("hostedPluginPath", currentHostedPluginPath);

        if (hostedPlugin != nullptr)
            hostedPlugin->getStateInformation(hostedPluginState);
    }

    if (hostedPluginState.getSize() > 0)
        state.createNewChildElement("HostedPluginState")->addTextElement(hostedPluginState.toBase64Encoding());

    auto* pianoRollState = state.createNewChildElement("PianoRoll");
    pianoRollState->setAttribute("gridDivisorIndex", pianoRollGridDivisorIndex.load());
    pianoRollState->setAttribute("toolMode", pianoRollToolMode.load());
    pianoRollState->setAttribute("showPitchEnvelopes", pianoRollShowPitchEnvelopes.load());
    pianoRollState->setAttribute("showVelocityLane", pianoRollShowVelocityLane.load());
    pianoRollState->setAttribute("scaleLockActive", pianoRollScaleLockActive.load());
    pianoRollState->setAttribute("scaleRoot", pianoRollScaleRoot.load());
    pianoRollState->setAttribute("scaleType", pianoRollScaleType.load());
    pianoRollState->setAttribute("keyHeight", (double)pianoRollKeyHeight.load());
    pianoRollState->setAttribute("pixelsPerBeat", (double)pianoRollPixelsPerBeat.load());
    pianoRollState->setAttribute("viewX", (double)pianoRollViewX.load());
    pianoRollState->setAttribute("viewY", (double)pianoRollViewY.load());

    pianoRollState->setAttribute("themeIndex", pianoRollThemeIndex.load());
    pianoRollState->setAttribute("pitchNodeSize", (double)pianoRollPitchNodeSize.load());
    pianoRollState->setAttribute("pitchLineThickness", (double)pianoRollPitchLineThickness.load());
    pianoRollState->setAttribute("gridOpacity", (double)pianoRollGridOpacity.load());
    pianoRollState->setAttribute("noteCornerRadius", (double)pianoRollNoteCornerRadius.load());
    pianoRollState->setAttribute("playheadThickness", (double)pianoRollPlayheadThickness.load());
    pianoRollState->setAttribute("velocityLaneHeight", pianoRollVelocityLaneHeight.load());
    pianoRollState->setAttribute("noteContrast", (double)pianoRollNoteContrast.load());
    pianoRollState->setAttribute("pitchLineContrast", (double)pianoRollPitchLineContrast.load());
    pianoRollState->setAttribute("noteColour", juce::String::toHexString((juce::uint32)pianoRollNoteColour.load()));
    pianoRollState->setAttribute("razorColour", juce::String::toHexString((juce::uint32)pianoRollRazorColour.load()));
    pianoRollState->setAttribute("pitchLineColour", juce::String::toHexString((juce::uint32)pianoRollPitchLineColour.load()));
    pianoRollState->setAttribute("gridBgColour", juce::String::toHexString((juce::uint32)pianoRollGridBgColour.load()));
    pianoRollState->setAttribute("gridLineColour", juce::String::toHexString((juce::uint32)pianoRollGridLineColour.load()));
    pianoRollState->setAttribute("noteTextColour", juce::String::toHexString((juce::uint32)pianoRollNoteTextColour.load()));
    pianoRollState->setAttribute("noteTextBold", pianoRollNoteTextBold.load());
    pianoRollState->setAttribute("toolbarTextColour", juce::String::toHexString((juce::uint32)pianoRollToolbarTextColour.load()));
    pianoRollState->setAttribute("toolbarTextBold", pianoRollToolbarTextBold.load());
    pianoRollState->setAttribute("noteNameColour", juce::String::toHexString((juce::uint32)pianoRollNoteNameColour.load()));
    pianoRollState->setAttribute("noteNameBold", pianoRollNoteNameBold.load());
    pianoRollState->setAttribute("showNoteNames", pianoRollShowNoteNames.load());
    pianoRollState->setAttribute("ghostPitchLines", pianoRollGhostPitchLines.load());
    pianoRollState->setAttribute("ghostPitchLineOpacity", pianoRollGhostPitchLineOpacity.load());
    pianoRollState->setAttribute("noteNameFontSize", pianoRollNoteNameFontSize.load());
    pianoRollState->setAttribute("fontTypeface", pianoRollFontTypefaceIndex.load());
    // Per-type grid line thickness. gridLineThickness is kept (as the bar
    // value) so older versions that only read the single attribute still work.
    pianoRollState->setAttribute("gridSubBeatThickness", (double)pianoRollGridSubBeatThickness.load());
    pianoRollState->setAttribute("gridHalfBeatThickness", (double)pianoRollGridHalfBeatThickness.load());
    pianoRollState->setAttribute("gridBeatThickness", (double)pianoRollGridBeatThickness.load());
    pianoRollState->setAttribute("gridBarThickness", (double)pianoRollGridBarThickness.load());
    pianoRollState->setAttribute("gridLineThickness", (double)pianoRollGridBarThickness.load());

    {
        juce::ScopedLock sl(noteLock);
        for (const auto& note : notes)
        {
            auto* noteState = pianoRollState->createNewChildElement("Note");
            noteState->setAttribute("midiNote", note.midiNote);
            noteState->setAttribute("startBeat", (double) note.startBeat);
            noteState->setAttribute("lengthBeats", (double) note.lengthBeats);
            noteState->setAttribute("velocity", (int) note.velocity);
            noteState->setAttribute("selected", note.selected);

            if (! note.pitchCurve.empty())
            {
                auto* pitchCurveState = noteState->createNewChildElement("PitchCurve");
                for (const auto& point : note.pitchCurve)
                {
                    auto* pointState = pitchCurveState->createNewChildElement("Point");
                    pointState->setAttribute("x", (double) point.x);
                    pointState->setAttribute("y", (double) point.y);
                    pointState->setAttribute("tension", (double) point.tension);
                    pointState->setAttribute("shape", point.shape);
                }
            }
        }
    }

    copyXmlToBinary(state, destData);
}

void WebDAWHostAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    auto state = getXmlFromBinary(data, sizeInBytes);

    if (state == nullptr || ! state->hasTagName("WebDAWHostState"))
        return;

    pitchBendRange.store(juce::jlimit(0, 96, state->getIntAttribute("pitchBendRange", pitchBendRange.load())));
    pitchShape.store(juce::jlimit(0, 5, state->getIntAttribute("pitchShape", pitchShape.load())));

    // Restore pitch-bend resolution; unknown values fall back to maximum (0).
    {
        const int savedMicros = state->getIntAttribute("pitchBendStepMicros", pitchBendStepMicros.load());
        pitchBendStepMicros.store((savedMicros == 250 || savedMicros == 500 || savedMicros == 1000) ? savedMicros : 0);
    }
    bendMode.store(juce::jlimit(0, 1, state->getIntAttribute("mpeMode", bendMode.load())));
    midiClockEnabled.store(state->getIntAttribute("midiClockEnabled", midiClockEnabled.load()) != 0);
    // Migrate the old 4-state legatoMode (0=off, 1=poly, 2=mono, 3=rtn)
    // to the new 3-state (0=off, 1=mono, 2=rtn): poly was removed.
    {
        const int savedLegato = state->getIntAttribute("legatoMode", legatoMode.load());
        if (savedLegato >= 2) legatoMode.store(juce::jlimit(0, 2, savedLegato - 1)); // mono 2->1, rtn 3->2
        else                  legatoMode.store(savedLegato == 1 ? 0 : savedLegato); // poly 1->off
    }

    auto pluginPath = state->getStringAttribute("hostedPluginPath");
    if (pluginPath.isNotEmpty())
    {
        juce::MemoryBlock hostedPluginState;
        if (auto* hostedState = state->getChildByName("HostedPluginState"))
            hostedPluginState.fromBase64Encoding(hostedState->getAllSubText().trim());

        // Warm load: the hosted plugin boots on a background thread so the
        // editor appears instantly; its saved state is applied once loaded.
        // If the same plugin is already loaded it is not reloaded at all.
        loadPluginAsync(pluginPath, hostedPluginState);
    }

    if (auto* pianoRollState = state->getChildByName("PianoRoll"))
    {
        const bool hasEditorState = pianoRollState->hasAttribute("gridDivisorIndex")
                                 || pianoRollState->hasAttribute("showPitchEnvelopes")
                                 || pianoRollState->hasAttribute("pixelsPerBeat");

        if (hasEditorState)
        {
            pianoRollHasSavedEditorState.store(true);
            pianoRollGridDivisorIndex.store(juce::jlimit(0, 5, pianoRollState->getIntAttribute("gridDivisorIndex", pianoRollGridDivisorIndex.load())));
            pianoRollToolMode.store(juce::jlimit(0, 1, pianoRollState->getIntAttribute("toolMode", pianoRollToolMode.load())));
            pianoRollShowPitchEnvelopes.store(pianoRollState->getBoolAttribute("showPitchEnvelopes", pianoRollShowPitchEnvelopes.load()));
            pianoRollShowVelocityLane.store(pianoRollState->getBoolAttribute("showVelocityLane", pianoRollShowVelocityLane.load()));
            pianoRollScaleLockActive.store(pianoRollState->getBoolAttribute("scaleLockActive", pianoRollScaleLockActive.load()));
            pianoRollScaleRoot.store(juce::jlimit(0, 11, pianoRollState->getIntAttribute("scaleRoot", pianoRollScaleRoot.load())));
            pianoRollScaleType.store(juce::jlimit(0, 5, pianoRollState->getIntAttribute("scaleType", pianoRollScaleType.load())));
            pianoRollKeyHeight.store(juce::jlimit(4.0f, 80.0f, (float)pianoRollState->getDoubleAttribute("keyHeight", pianoRollKeyHeight.load())));
            pianoRollPixelsPerBeat.store(juce::jlimit(10.0f, 400.0f, (float)pianoRollState->getDoubleAttribute("pixelsPerBeat", pianoRollPixelsPerBeat.load())));
            pianoRollViewX.store(juce::jmax(0.0f, (float)pianoRollState->getDoubleAttribute("viewX", pianoRollViewX.load())));
            pianoRollViewY.store(juce::jmax(0.0f, (float)pianoRollState->getDoubleAttribute("viewY", pianoRollViewY.load())));
            
            // Theme tweaks (theme index, colours, grid thicknesses, text
            // styles, font typeface) are GLOBAL preferences: they load from
            // settings.xml in the processor constructor and are intentionally
            // NOT restored from the DAW project here, so the most recent
            // adjustments always survive closing and reopening the VST.
        }
        stateRestoredFlag.store(true);

        std::vector<NoteEvent> restoredNotes;

        for (auto* noteState = pianoRollState->getFirstChildElement(); noteState != nullptr; noteState = noteState->getNextElement())
        {
            if (! noteState->hasTagName("Note"))
                continue;

            NoteEvent note {
                juce::jlimit(0, 127, noteState->getIntAttribute("midiNote", 60)),
                (float) noteState->getDoubleAttribute("startBeat", 0.0),
                juce::jmax(0.0001f, (float) noteState->getDoubleAttribute("lengthBeats", 1.0)),
                (juce::uint8) juce::jlimit(1, 127, noteState->getIntAttribute("velocity", 100)),
                false,
                noteState->getBoolAttribute("selected", false)
            };

            if (auto* pitchCurveState = noteState->getChildByName("PitchCurve"))
            {
                for (auto* pointState = pitchCurveState->getFirstChildElement(); pointState != nullptr; pointState = pointState->getNextElement())
                {
                    if (! pointState->hasTagName("Point"))
                        continue;

                    note.pitchCurve.push_back({
                        (float) pointState->getDoubleAttribute("x", 0.0),
                        (float) pointState->getDoubleAttribute("y", 0.0),
                        (float) pointState->getDoubleAttribute("tension", 0.0),
                        pointState->getIntAttribute("shape", 0)
                    });
                }

                std::stable_sort(note.pitchCurve.begin(), note.pitchCurve.end(),
                    [] (const PitchNode& a, const PitchNode& b)
                    {
                        return a.x < b.x;
                    });
            }

            restoredNotes.push_back(std::move(note));
        }

        {
            juce::ScopedLock sl(noteLock);
            notes = std::move(restoredNotes);
            notesRevision.fetch_add(1); // the piano roll's paint cache must refresh
            lastProcessedPpq = -1.0;

            for (int c = 0; c < 16; ++c)
            {
                lastPitchBendRangeSent[c] = -1;
                lastPitchBendValue[c] = 8192;
                activeChannels[c] = false;
            }
        }
    }
}

void WebDAWHostAudioProcessor::unloadPlugin()
{
    // Stop sequencer notes the hosted plugin might still be sounding, so
    // unloading never leaves stuck voices behind.
    {
        juce::ScopedLock sl(noteLock);
        for (auto& note : notes)
        {
            if (note.isPlaying)
            {
                addLiveMidiEvent(juce::MidiMessage::noteOff(note.playingChannel, noteOffPitch(note), (juce::uint8)0));
                note.isPlaying = false;
                note.returnPending = false;
                note.wheelSuperseded = false;
                note.wheelTakeoverBeat = -1.0f;
            }
        }
        for (int c = 0; c < 16; ++c) activeChannels[c] = false;
    }

    // Swap the hosted plugin out under processLock; the old instance is
    // destroyed on the message thread after the lock releases (same safe
    // pattern as loadPlugin), so the audio thread never touches a
    // half-deleted plugin.
    std::unique_ptr<juce::AudioPluginInstance> oldPlugin;
    {
        juce::ScopedLock sl(processLock);
        oldPlugin = std::move(hostedPlugin);
        currentHostedPluginPath.clear();
        setLatencySamples(0);
        cachedTailLengthSeconds.store(0.0);

        for (int c = 0; c < 16; ++c) {
            lastPitchBendRangeSent[c] = -1;
            lastPitchBendValue[c] = 8192;
        }
    }
    // oldPlugin is safely destroyed here on the message thread
}

void WebDAWHostAudioProcessor::loadPlugin(const juce::String& path)
{
    juce::OwnedArray<juce::PluginDescription> foundDescriptions;

    for (int i = 0; i < formatManager.getNumFormats() && foundDescriptions.isEmpty(); ++i)
    {
        if (auto* format = formatManager.getFormat(i))
        {
            if (format->fileMightContainThisPluginType(path))
            {
                // Persistent description cache: with dontRescanIfAlreadyInList
                // the metadata scan is skipped for known plugins, which is the
                // biggest load-time win over re-scanning the binary every time.
                pluginDescriptionCache.scanAndAddFile(path, true, foundDescriptions, *format);
            }
        }
    }
    if (!foundDescriptions.isEmpty())
        savePluginDescriptionCache(); // persist any newly discovered entries

    if (foundDescriptions.size() > 0)
    {
        juce::String errorMessage;
        // Single preparation: when the DAW hasn't prepared us yet (warm load),
        // skip prepareToPlay here with the fallback rate/block — our own
        // prepareToPlay will be the only preparation with the real values,
        // avoiding a double audio-graph initialisation in the hosted plugin.
        const double sr = getSampleRate() > 0 ? getSampleRate() : 0.0;
        const int bs = getBlockSize() > 0 ? getBlockSize() : 0;
        auto newPlugin = formatManager.createPluginInstance(*foundDescriptions[0],
                                                            sr > 0.0 ? sr : 44100.0,
                                                            bs > 0 ? bs : 512,
                                                            errorMessage);
        if (newPlugin != nullptr)
        {
            // Attempt to restrict to host layout
            newPlugin->setBusesLayout(getBusesLayout());
            newPlugin->setPlayHead(getPlayHead());
            if (sr > 0.0 && bs > 0)
                newPlugin->prepareToPlay(sr, bs);
            
            std::unique_ptr<juce::AudioPluginInstance> oldPlugin;
            {
                juce::ScopedLock sl(processLock);
                oldPlugin = std::move(hostedPlugin);
                hostedPlugin = std::move(newPlugin);
                currentHostedPluginPath = path;
                setLatencySamples(hostedPlugin->getLatencySamples());
                hostedLatencySamples.store(hostedPlugin->getLatencySamples());
                cachedTailLengthSeconds.store(hostedPlugin->getTailLengthSeconds());

                for (int c = 0; c < 16; ++c) {
                    lastPitchBendRangeSent[c] = -1;
                    lastPitchBendValue[c] = 8192;
                    activeChannels[c] = false;
                }
                
                int maxChans = 2;
                maxChans = juce::jmax(maxChans, hostedPlugin->getTotalNumOutputChannels());
                maxChans = juce::jmax(maxChans, hostedPlugin->getTotalNumInputChannels());
                pluginBuffer.setSize(juce::jmax(maxChans, 8), getBlockSize() > 0 ? getBlockSize() : 512);
            }
            // oldPlugin is safely destroyed here on the message thread, without blocking the audio thread
        }
    }
}

void WebDAWHostAudioProcessor::loadPluginAsync(const juce::String& path, const juce::MemoryBlock& hostedStateToRestore)
{
    if (pluginLoading.load())
        return;

    // Already warm with this exact plugin — skip the reload entirely so
    // repeated state restores don't force Kontakt to boot from scratch.
    {
        juce::ScopedLock sl(processLock);
        if (hostedPlugin != nullptr && currentHostedPluginPath == path)
            return;
    }

    // Resolve the plugin description (cached after the first time).
    juce::OwnedArray<juce::PluginDescription> foundDescriptions;
    for (int i = 0; i < formatManager.getNumFormats() && foundDescriptions.isEmpty(); ++i)
    {
        if (auto* format = formatManager.getFormat(i))
        {
            if (format->fileMightContainThisPluginType(path))
                pluginDescriptionCache.scanAndAddFile(path, true, foundDescriptions, *format);
        }
    }
    if (foundDescriptions.isEmpty())
        return;
    savePluginDescriptionCache();

    pluginLoading.store(true);
    const double sr = getSampleRate() > 0 ? getSampleRate() : 44100.0;
    const int bs = getBlockSize() > 0 ? getBlockSize() : 512;

    // JUCE's async loader pumps the message loop while the plugin boots, so
    // instantiating Kontakt during DAW startup can't deadlock the host (a raw
    // background thread + Kontakt's message handling is what froze it).
    auto desc = std::make_shared<juce::PluginDescription>(*foundDescriptions[0]);
    formatManager.createPluginInstanceAsync(*desc, sr, bs,
        [this, path, hostedStateToRestore, desc] (std::unique_ptr<juce::AudioPluginInstance> instance, const juce::String&)
        {
            if (instance != nullptr)
            {
                instance->setBusesLayout(getBusesLayout());
                instance->setPlayHead(getPlayHead());
                if (getSampleRate() > 0 && getBlockSize() > 0)
                    instance->prepareToPlay(getSampleRate(), getBlockSize());

                std::unique_ptr<juce::AudioPluginInstance> oldPlugin;
                {
                    juce::ScopedLock sl(processLock);
                    oldPlugin = std::move(hostedPlugin);
                    hostedPlugin = std::move(instance);
                    currentHostedPluginPath = path;
                    setLatencySamples(hostedPlugin->getLatencySamples());
                    hostedLatencySamples.store(hostedPlugin->getLatencySamples());
                    cachedTailLengthSeconds.store(hostedPlugin->getTailLengthSeconds());

                    for (int c = 0; c < 16; ++c) {
                        lastPitchBendRangeSent[c] = -1;
                        lastPitchBendValue[c] = 8192;
                        activeChannels[c] = false;
                    }

                    int maxChans = 2;
                    maxChans = juce::jmax(maxChans, hostedPlugin->getTotalNumOutputChannels());
                    maxChans = juce::jmax(maxChans, hostedPlugin->getTotalNumInputChannels());
                    pluginBuffer.setSize(juce::jmax(maxChans, 8), getBlockSize() > 0 ? getBlockSize() : 512);
                }
                // oldPlugin is safely destroyed here on the message thread.

                // Apply the hosted plugin's saved state now that it is loaded
                // (setStateInformation may run before the warm load finishes).
                if (hostedStateToRestore.getSize() > 0)
                {
                    juce::ScopedLock sl(processLock);
                    if (currentHostedPluginPath == path)
                        hostedPlugin->setStateInformation(hostedStateToRestore.getData(), (int)hostedStateToRestore.getSize());
                }
            }
            pluginLoading.store(false);
        });
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new WebDAWHostAudioProcessor(); }
