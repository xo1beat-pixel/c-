#include "PianoRollComponent.h"
#include "PluginProcessor.h"
#include "MidiPitchHelpers.h"
#include "WebDAWLookAndFeel.h"
#include <cmath>
#include <algorithm>
#include <limits>
#include <vector>

using namespace MidiPitch;

static const std::vector<std::vector<int>> scaleIntervals = {
    {0, 2, 4, 5, 7, 9, 11}, // Major
    {0, 2, 3, 5, 7, 8, 10}, // Natural Minor
    {0, 2, 3, 5, 7, 8, 11}, // Harmonic Minor
    {0, 2, 4, 7, 9},        // Pentatonic Major
    {0, 3, 5, 7, 10},       // Pentatonic Minor
    {0, 3, 5, 6, 7, 10}     // Blues
};
static const juce::StringArray scaleNames = {"Major", "Minor", "Harmonic Min", "Pent Major", "Pent Minor", "Blues"};
static const juce::StringArray scaleNoteNames = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};

namespace {

// Typeface index synced from the processor's pianoRollFontTypefaceIndex
// (the free getModernFont() helper below can't see the processor object).
static std::atomic<int> gPianoRollTypefaceIndex {0};

inline juce::Font getModernFont(float size, int style = juce::Font::plain) {
    juce::Font f(size, style);
    switch (gPianoRollTypefaceIndex.load()) {
        case 1:  f.setTypefaceName("Arial"); break;
        case 2:  f.setTypefaceName("Georgia"); break;
        case 3:  f.setTypefaceName("Consolas"); break;
        case 4:  f.setTypefaceName("Verdana"); break;
        case 5:  f.setTypefaceName("Tahoma"); break;
        case 6:  f.setTypefaceName("Trebuchet MS"); break;
        case 7:  f.setTypefaceName("Times New Roman"); break;
        case 8:  f.setTypefaceName("Courier New"); break;
        case 9:  f.setTypefaceName("Impact"); break;
        case 10: f.setTypefaceName("Comic Sans MS"); break;
        case 11: f.setTypefaceName("Palatino Linotype"); break;
        case 12: f.setTypefaceName("Lucida Console"); break;
        case 13: f.setTypefaceName("Century Gothic"); break;
        case 14: f.setTypefaceName("Franklin Gothic Medium"); break;
        case 15: f.setTypefaceName("Garamond"); break;
        case 16: f.setTypefaceName("Rockwell"); break;
        case 17: f.setTypefaceName("Bahnschrift"); break;
        case 18: f.setTypefaceName("Candara"); break;
        case 19: f.setTypefaceName("Segoe Script"); break;
        case 20: f.setTypefaceName("Segoe Print"); break;
        case 21: f.setTypefaceName("Bookman Old Style"); break;
        case 22: f.setTypefaceName("Lucida Handwriting"); break;
        case 23: f.setTypefaceName("Monotype Corsiva"); break;
        case 24: f.setTypefaceName("Cambria"); break;
        case 25: f.setTypefaceName("Calibri"); break;
        case 26: f.setTypefaceName("Constantia"); break;
        case 27: f.setTypefaceName("Corbel"); break;
        case 28: f.setTypefaceName("Microsoft Sans Serif"); break;
        default: f.setTypefaceName("Segoe UI"); break;
    }
    return f;
}

// Map the GLOBAL pitch-shape mode (0..5: Linear, Square, Smooth, Ease In,
// Ease Out, Sine) to an explicit per-node shape (1..6). Newly drawn curve
// nodes are BAKED with this shape at creation time, so changing the global
// mode later never reshapes curves that were already drawn.
inline int bakedNodeShapeFor(const WebDAWHostAudioProcessor& processor)
{
    return juce::jlimit(1, 6, processor.pitchShape.load() + 1);
}

    bool isNoteInScale(int midiNote, int root, int type) {
        int noteInOctave = (midiNote % 12);
        int relativeNote = (noteInOctave - root + 12) % 12;
        const auto& intervals = scaleIntervals[type];
        return std::find(intervals.begin(), intervals.end(), relativeNote) != intervals.end();
    }

    int snapNoteToScale(int midiNote, int root, int type) {
        if (isNoteInScale(midiNote, root, type)) return midiNote;
        for (int i = 1; i <= 6; ++i) {
            if (isNoteInScale(midiNote + i, root, type)) return midiNote + i;
            if (isNoteInScale(midiNote - i, root, type)) return midiNote - i;
        }
        return midiNote;
    }

    constexpr juce::uint32 panelBg = 0xff13171c;
constexpr juce::uint32 blueAccent = 0xff22c55e;
constexpr juce::uint32 amberAccent = 0xfff43f5e;
// Theme panel geometry: fixed header (title + divider) then one row per
// control. The panel scrolls vertically when the rows overflow the window.
constexpr int themePanelRowH = 35;
constexpr int themePanelRowCount = 20;
constexpr int themePanelHeaderH = 65;
    constexpr float pitchCurveSemitoneEpsilon = 0.000001f;

    bool isBlackMidiKey(int note) noexcept
    {
        const int noteInOctave = note % 12;
        return noteInOctave == 1 || noteInOctave == 3 || noteInOctave == 6 || noteInOctave == 8 || noteInOctave == 10;
    }

    bool isBeatMultiple(float beat, float division) noexcept
    {
        if (division <= 0.0f)
            return false;

        const float nearest = std::round(beat / division) * division;
        return std::abs(beat - nearest) < 0.0001f;
    }

    float snapValueToStep(float value, float step) noexcept
    {
        if (step <= 0.0f)
            return value;

        return std::round(value / step) * step;
    }

    float snapPitchBendToNoteCenter(float bendSemitones) noexcept
    {
        // Without Shift, pitch points snap to the semitone (note-row) grid;
        // hold Shift for free (microtonal) placement.
        return std::round(bendSemitones);
    }

    // Standard PPQ for exported MIDI. 960 is universally supported; the old
    // 96000 was capped/rejected by many DAWs and produced enormous files.
    constexpr int midiExportTicksPerQuarterNote = 960;

    int getNextPitchBendRange(int currentRange)
    {
        if (currentRange == 1) return 2;
        if (currentRange == 2) return 7;
        if (currentRange == 7) return 12;
        if (currentRange == 12) return 24;
        if (currentRange == 24) return 48;
        return 1;
    }

    juce::Colour getNoteColour(const NoteEvent& note, juce::Colour themeColour, float contrastModifier)
    {
        const float velRatio = note.velocity / 127.0f;
        // contrastModifier range is roughly 0.2 to 2.0 (1.0 is default).
        // A higher contrast means darker low velocities and brighter high velocities.
        
        float darkenAmount = (1.0f - velRatio) * 0.85f * contrastModifier; 
        // Low velocities darken TOWARD GREY (saturation fades with velocity)
        // so warm theme colours (amber/rose) never turn reddish-brown — they
        // simply go darker and darker toward black.
        const float satMul = juce::jlimit(0.22f, 1.0f, 0.22f + velRatio * 0.78f);
        // SOLID notes: always fully opaque, saturated colour (no desaturated
        // "frosted/glass" wash).
        juce::Colour base = themeColour.darker(darkenAmount).withMultipliedSaturation(satMul);
        
        if (note.selected)
            return base.brighter(0.12f); // subtle selection lift (0.4 washed notes out)
        return base;
    }

    void drawToolbarSeparator(juce::Graphics& g, float x, int toolbarHeight)
    {
        g.setColour(juce::Colour(0xff2b333d).withAlpha(0.72f));
        g.drawLine(x, 8.0f, x, (float)toolbarHeight - 8.0f, 0.8f);
    }

    void drawToolbarButton(juce::Graphics& g,
                           juce::Rectangle<int> bounds,
                           const juce::String& text,
                           bool active,
                           juce::Colour accent,
                           bool quiet,
                           juce::Point<int> mousePos,
                           int iconType = 0,
                           juce::Colour textOverride = juce::Colour(),
                           bool bold = true)
    {
        auto r = bounds.toFloat();
        const float radius = 6.0f;
        bool isHovered = bounds.contains(mousePos);

        // Modern chip: subtle vertical gradient, hairline border, hover glow,
        // accent tint + bottom accent bar when active.
        juce::Colour base = active ? accent.withAlpha(0.17f) : juce::Colour(0xff14181e);
        if (isHovered) base = base.brighter(0.15f);

        juce::ColourGradient grad(base.brighter(0.07f), 0.0f, r.getY(),
                                  base.darker(0.05f), 0.0f, r.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(r, radius);

        // Hairline border (accent-tinted when active).
        g.setColour(active ? accent.withAlpha(0.55f) : juce::Colour(0xff2a3340).withAlpha(0.75f));
        g.drawRoundedRectangle(r.reduced(0.5f), radius, 1.0f);

        // Hover glow ring on inactive buttons.
        if (isHovered && !active)
        {
            g.setColour(juce::Colours::white.withAlpha(0.07f));
            g.drawRoundedRectangle(r.reduced(1.5f), radius, 1.2f);
        }

        if (active)
        {
            g.setColour(accent);
            g.fillRoundedRectangle(r.getX() + 6.0f, r.getBottom() - 3.0f, r.getWidth() - 12.0f, 2.0f, 1.0f);
        }

        juce::Colour textColour = active ? accent.brighter(0.3f) : (isHovered ? juce::Colours::white : juce::Colour(0xffa5aebd));
        // Theme override (empty colour = keep the per-state default above).
        if (!textOverride.isTransparent())
            textColour = textOverride;
        
        // Draw icon if present
        float textXOffset = 0.0f;
        if (iconType != 0) {
            juce::Path iconPath;
            float cx = r.getX() + 14.0f;
            float cy = r.getCentreY();
            
            if (iconType == 1) { // Pencil
                iconPath.startNewSubPath(cx - 4.0f, cy + 4.0f);
                iconPath.lineTo(cx - 4.0f, cy + 1.0f);
                iconPath.lineTo(cx + 3.0f, cy - 6.0f);
                iconPath.lineTo(cx + 6.0f, cy - 3.0f);
                iconPath.lineTo(cx - 1.0f, cy + 4.0f);
                iconPath.closeSubPath();
                iconPath.startNewSubPath(cx - 4.0f, cy + 4.0f);
                iconPath.lineTo(cx - 6.0f, cy + 6.0f);
                iconPath.lineTo(cx - 1.5f, cy + 3.5f);
            } else if (iconType == 2) { // Cursor/Marquee
                iconPath.startNewSubPath(cx - 4.0f, cy - 5.0f);
                iconPath.lineTo(cx - 4.0f, cy + 6.0f);
                iconPath.lineTo(cx - 1.0f, cy + 3.0f);
                iconPath.lineTo(cx + 2.0f, cy + 7.0f);
                iconPath.lineTo(cx + 4.0f, cy + 6.0f);
                iconPath.lineTo(cx + 1.0f, cy + 2.0f);
                iconPath.lineTo(cx + 5.0f, cy + 2.0f);
                iconPath.closeSubPath();
            } else if (iconType == 3) { // Vel bars
                iconPath.addRoundedRectangle(cx - 5.0f, cy + 1.0f, 2.0f, 5.0f, 0.5f);
                iconPath.addRoundedRectangle(cx - 1.0f, cy - 2.0f, 2.0f, 8.0f, 0.5f);
                iconPath.addRoundedRectangle(cx + 3.0f, cy - 5.0f, 2.0f, 11.0f, 0.5f);
            } else if (iconType == 4) { // Grid: four subtle cells
                iconPath.startNewSubPath(cx - 3.5f, cy - 5.0f);
                iconPath.lineTo(cx - 3.5f, cy + 5.0f);
                iconPath.startNewSubPath(cx + 3.5f, cy - 5.0f);
                iconPath.lineTo(cx + 3.5f, cy + 5.0f);
                iconPath.startNewSubPath(cx - 6.0f, cy - 3.0f);
                iconPath.lineTo(cx + 6.0f, cy - 3.0f);
                iconPath.startNewSubPath(cx - 6.0f, cy + 3.0f);
                iconPath.lineTo(cx + 6.0f, cy + 3.0f);
            } else if (iconType == 5) { // Pitch bend: up arrow
                iconPath.startNewSubPath(cx, cy + 4.5f);
                iconPath.lineTo(cx, cy - 3.5f);
                iconPath.startNewSubPath(cx, cy - 3.5f);
                iconPath.lineTo(cx - 3.0f, cy - 0.5f);
                iconPath.startNewSubPath(cx, cy - 3.5f);
                iconPath.lineTo(cx + 3.0f, cy - 0.5f);
            } else if (iconType == 6) { // Theme: three colour dots
                iconPath.addEllipse(cx - 4.5f, cy - 2.5f, 3.0f, 3.0f);
                iconPath.addEllipse(cx + 0.5f, cy - 4.5f, 3.0f, 3.0f);
                iconPath.addEllipse(cx + 3.0f, cy - 0.5f, 3.0f, 3.0f);
            } else if (iconType == 7) { // Panic: exclamation mark
                iconPath.startNewSubPath(cx, cy - 4.0f);
                iconPath.lineTo(cx, cy + 0.5f);
                iconPath.addEllipse(cx - 1.2f, cy + 2.5f, 2.4f, 2.4f);
            }
            
            g.setColour(textColour);
            if (iconType == 3) {
                g.fillPath(iconPath);
            } else {
                g.strokePath(iconPath, juce::PathStrokeType(1.5f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
            }
            textXOffset = 8.0f; // Shift text right if we have an icon
        }

        g.setFont(getModernFont(14.0f, bold ? juce::Font::bold : juce::Font::plain));
        g.setColour(textColour);
        
        juce::Rectangle<int> textBounds = bounds.withTrimmedLeft((int)textXOffset);
        g.drawText(text, textBounds, juce::Justification::centred, false);
    }
}

PianoRollComponent::PianoRollComponent(WebDAWHostAudioProcessor& p) : processor(p)
{
    setOpaque(true);
    setWantsKeyboardFocus(true);
    startTimerHz(60); // 60 Hz for a smooth playhead
    viewY = (127 - 60) * keyHeight - 200.0f;
    if (viewY < 0.0f) viewY = 0.0f;
    loadPersistentEditorState();
    storePersistentEditorState();
    
    addAndMakeVisible(pitchNodeSizeSlider);
    pitchNodeSizeSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    pitchNodeSizeSlider.setRange(2.0, 24.0, 0.1);
    pitchNodeSizeSlider.setValue(pitchNodeSize);
    pitchNodeSizeSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 20);
    pitchNodeSizeSlider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    pitchNodeSizeSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    pitchNodeSizeSlider.onValueChange = [this] { pitchNodeSize = (float)pitchNodeSizeSlider.getValue(); repaint(); markPersistentEditorStateChanged(); };
    pitchNodeSizeSlider.setVisible(false);
    
    addAndMakeVisible(pitchLineThicknessSlider);
    pitchLineThicknessSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    pitchLineThicknessSlider.setRange(0.1, 5.0, 0.1);
    pitchLineThicknessSlider.setValue(pitchLineThickness);
    pitchLineThicknessSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 20);
    pitchLineThicknessSlider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    pitchLineThicknessSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    pitchLineThicknessSlider.onValueChange = [this] { pitchLineThickness = (float)pitchLineThicknessSlider.getValue(); repaint(); markPersistentEditorStateChanged(); };
    pitchLineThicknessSlider.setVisible(false);
    
    addAndMakeVisible(gridOpacitySlider);
    gridOpacitySlider.setSliderStyle(juce::Slider::LinearHorizontal);
    gridOpacitySlider.setRange(0.0, 20.0, 0.01);
    gridOpacitySlider.setValue(gridOpacityMultiplier);
    gridOpacitySlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 20);
    gridOpacitySlider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    gridOpacitySlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    gridOpacitySlider.onValueChange = [this] { gridOpacityMultiplier = (float)gridOpacitySlider.getValue(); repaint(); markPersistentEditorStateChanged(); };
    gridOpacitySlider.setVisible(false);
    
    addAndMakeVisible(noteCornerRadiusSlider);
    noteCornerRadiusSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    noteCornerRadiusSlider.setRange(0.0, 10.0, 0.1);
    noteCornerRadiusSlider.setValue(noteCornerRadius);
    noteCornerRadiusSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 20);
    noteCornerRadiusSlider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    noteCornerRadiusSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    noteCornerRadiusSlider.onValueChange = [this] { noteCornerRadius = (float)noteCornerRadiusSlider.getValue(); repaint(); markPersistentEditorStateChanged(); };
    noteCornerRadiusSlider.setVisible(false);

    addAndMakeVisible(playheadThicknessSlider);
    playheadThicknessSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    playheadThicknessSlider.setRange(0.5, 5.0, 0.1);
    playheadThicknessSlider.setValue(playheadThickness);
    playheadThicknessSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 20);
    playheadThicknessSlider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    playheadThicknessSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    playheadThicknessSlider.onValueChange = [this] { playheadThickness = (float)playheadThicknessSlider.getValue(); repaint(); markPersistentEditorStateChanged(); };
    playheadThicknessSlider.setVisible(false);

    addAndMakeVisible(noteContrastSlider);
    noteContrastSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    noteContrastSlider.setRange(0.0, 2.0, 0.01);
    noteContrastSlider.setValue(noteContrast);
    noteContrastSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 20);
    noteContrastSlider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    noteContrastSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    noteContrastSlider.onValueChange = [this] { 
        noteContrast = (float)noteContrastSlider.getValue(); 
        repaint(); 
        markPersistentEditorStateChanged();
    };
    noteContrastSlider.setVisible(false);

    // Three per-type grid line thickness sliders (sub-beats / beats / bars),
    // sharing one setup lambda. processor outlives this component, so the
    // captured atomic references stay valid. The multiplier range (0.25..5.0)
    // is wide on purpose: the sub-beat lines start from a 0.5 px base, so a
    // 0.5..3.0 range would make the slider feel almost dead (0.25..1.5 px).
    auto setupGridThicknessSlider = [this] (juce::Slider& s, std::atomic<float>& target, const juce::String& tip)
    {
        addAndMakeVisible(s);
        s.setSliderStyle(juce::Slider::LinearHorizontal);
        s.setRange(0.25, 5.0, 0.05);
        s.setValue(target.load());
        s.setTextBoxStyle(juce::Slider::TextBoxRight, false, 40, 20);
        s.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
        s.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
        s.setTooltip(tip);
        s.onValueChange = [this, &s, &target] {
            target.store((float)s.getValue());
            repaint();
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
        };
        s.setVisible(false);
    };
    setupGridThicknessSlider(gridSubBeatThicknessSlider, processor.pianoRollGridSubBeatThickness,
                             "Sub-beat line thickness (the fine lines between beats)");
    setupGridThicknessSlider(gridHalfBeatThicknessSlider, processor.pianoRollGridHalfBeatThickness,
                             "Half-beat line thickness (the lines halfway between beats)");
    setupGridThicknessSlider(gridBeatThicknessSlider, processor.pianoRollGridBeatThickness,
                             "Beat line thickness");
    setupGridThicknessSlider(gridBarThicknessSlider, processor.pianoRollGridBarThickness,
                             "Bar (measure) line thickness");

    // Bold toggles for the note-name and toolbar text (theme panel rows).
    auto setupTextBoldButton = [this] (juce::TextButton& b, std::atomic<bool>& target, const juce::String& tooltip)
    {
        addAndMakeVisible(b);
        b.setLookAndFeel(&webDAWMenuLAF()); // shared modern button styling
        b.setButtonText("B");
        b.setTooltip(tooltip);
        b.setClickingTogglesState(true);
        b.setToggleState(target.load(), juce::dontSendNotification);
        b.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1c222b));
        b.setColour(juce::TextButton::buttonOnColourId, juce::Colour(blueAccent));
        b.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff94a3b8));
        b.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
        b.onClick = [this, &b, &target] {
            target.store(b.getToggleState());
            repaint();
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
        };
        b.setVisible(false);
    };
    setupTextBoldButton(noteTextBoldButton, processor.pianoRollNoteTextBold, "Bold the note names on the keys");
    setupTextBoldButton(toolbarTextBoldButton, processor.pianoRollToolbarTextBold, "Bold the toolbar button labels");
    setupTextBoldButton(noteNameBoldButton, processor.pianoRollNoteNameBold, "Bold the note names inside the notes");

    // Show/hide the note names inside the notes (off by default: clean look).
    addAndMakeVisible(noteNameShowButton);
    noteNameShowButton.setLookAndFeel(&webDAWMenuLAF()); // shared modern button styling
    noteNameShowButton.setButtonText(processor.pianoRollShowNoteNames.load() ? "\xe2\x97\x89" : "\xe2\x97\x8b");
    noteNameShowButton.setTooltip("Show the note names inside the notes");
    noteNameShowButton.setClickingTogglesState(true);
    noteNameShowButton.setToggleState(processor.pianoRollShowNoteNames.load(), juce::dontSendNotification);
    noteNameShowButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1c222b));
    noteNameShowButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(blueAccent));
    noteNameShowButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff94a3b8));
    noteNameShowButton.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
    noteNameShowButton.onClick = [this] {
        processor.pianoRollShowNoteNames.store(noteNameShowButton.getToggleState());
        noteNameShowButton.setButtonText(noteNameShowButton.getToggleState() ? "\xe2\x97\x89" : "\xe2\x97\x8b");
        repaint();
        markPersistentEditorStateChanged();
        processor.saveGlobalSettings();
    };
    noteNameShowButton.setVisible(false);

    // Ghost pitch lines toggle (theme panel row): shows the real pitch
    // curves at low visibility on notes with bends when pitch mode is off.
    addAndMakeVisible(ghostPitchLinesButton);
    ghostPitchLinesButton.setLookAndFeel(&webDAWMenuLAF()); // shared modern button styling
    ghostPitchLinesButton.setButtonText("Ghost Pitch Lines");
    ghostPitchLinesButton.setTooltip("Show faint pitch-curve lines on notes with bends (when pitch mode is off)");
    ghostPitchLinesButton.setClickingTogglesState(true);
    ghostPitchLinesButton.setToggleState(processor.pianoRollGhostPitchLines.load(), juce::dontSendNotification);
    ghostPitchLinesButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1c222b));
    ghostPitchLinesButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(blueAccent));
    ghostPitchLinesButton.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff94a3b8));
    ghostPitchLinesButton.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
    ghostPitchLinesButton.onClick = [this] {
        processor.pianoRollGhostPitchLines.store(ghostPitchLinesButton.getToggleState());
        repaint();
        markPersistentEditorStateChanged();
        processor.saveGlobalSettings();
    };
    ghostPitchLinesButton.setVisible(false);

    // Ghost pitch line opacity slider (next to the toggle, same row).
    addAndMakeVisible(ghostPitchLinesOpacitySlider);
    ghostPitchLinesOpacitySlider.setSliderStyle(juce::Slider::LinearHorizontal);
    ghostPitchLinesOpacitySlider.setRange(5, 70, 1);
    ghostPitchLinesOpacitySlider.setValue(processor.pianoRollGhostPitchLineOpacity.load());
    ghostPitchLinesOpacitySlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    ghostPitchLinesOpacitySlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    ghostPitchLinesOpacitySlider.setTooltip("Ghost line visibility (%)");
    ghostPitchLinesOpacitySlider.onValueChange = [this] {
        processor.pianoRollGhostPitchLineOpacity.store((int)ghostPitchLinesOpacitySlider.getValue());
        repaint();
        markPersistentEditorStateChanged();
    };
    ghostPitchLinesOpacitySlider.setVisible(false);

    // Note name font size (px) inside the notes — theme panel slider.
    addAndMakeVisible(noteNameFontSizeSlider);
    noteNameFontSizeSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    noteNameFontSizeSlider.setRange(8, 20, 1);
    noteNameFontSizeSlider.setValue(processor.pianoRollNoteNameFontSize.load());
    noteNameFontSizeSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    noteNameFontSizeSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    noteNameFontSizeSlider.setTooltip("Note name font size (px) inside the notes");
    noteNameFontSizeSlider.onValueChange = [this] {
        processor.pianoRollNoteNameFontSize.store((int)noteNameFontSizeSlider.getValue());
        repaint();
        markPersistentEditorStateChanged();
    };
    noteNameFontSizeSlider.setVisible(false);

    addAndMakeVisible(pitchLineContrastSlider);
    pitchLineContrastSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    pitchLineContrastSlider.setRange(0.0, 2.0, 0.01);
    pitchLineContrastSlider.setValue(pitchLineContrast);
    pitchLineContrastSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 20);
    pitchLineContrastSlider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    pitchLineContrastSlider.setColour(juce::Slider::thumbColourId, juce::Colour(0xff3b82f6));
    pitchLineContrastSlider.onValueChange = [this] { 
        pitchLineContrast = (float)pitchLineContrastSlider.getValue(); 
        repaint(); 
        markPersistentEditorStateChanged();
    };
    pitchLineContrastSlider.setVisible(false);

    
    addAndMakeVisible(themeCombo);
    themeCombo.addItem("Emerald", 1);
    themeCombo.addItem("Blue", 2);
    themeCombo.addItem("Rose", 3);
    themeCombo.addItem("Amber", 4);
    themeCombo.addItem("Purple", 5);
    themeCombo.setSelectedId(currentThemeIndex + 1, juce::dontSendNotification);
    themeCombo.onChange = [this] { saveUndoState(); currentThemeIndex = themeCombo.getSelectedId() - 1; repaint(); markPersistentEditorStateChanged(); };
    themeCombo.setVisible(false);

    addAndMakeVisible(fontTypefaceCombo);
    fontTypefaceCombo.addItem("Segoe UI", 1);
    fontTypefaceCombo.addItem("Arial", 2);
    fontTypefaceCombo.addItem("Georgia", 3);
    fontTypefaceCombo.addItem("Consolas", 4);
    fontTypefaceCombo.addItem("Verdana", 5);
    fontTypefaceCombo.addItem("Tahoma", 6);
    fontTypefaceCombo.addItem("Trebuchet MS", 7);
    fontTypefaceCombo.addItem("Times New Roman", 8);
    fontTypefaceCombo.addItem("Courier New", 9);
    fontTypefaceCombo.addItem("Impact", 10);
    fontTypefaceCombo.addItem("Comic Sans MS", 11);
    fontTypefaceCombo.addItem("Palatino Linotype", 12);
    fontTypefaceCombo.addItem("Lucida Console", 13);
    fontTypefaceCombo.addItem("Century Gothic", 14);
    fontTypefaceCombo.addItem("Franklin Gothic Medium", 15);
    fontTypefaceCombo.addItem("Garamond", 16);
    fontTypefaceCombo.addItem("Rockwell", 17);
    fontTypefaceCombo.addItem("Bahnschrift", 18);
    fontTypefaceCombo.addItem("Candara", 19);
    fontTypefaceCombo.addItem("Segoe Script", 20);
    fontTypefaceCombo.addItem("Segoe Print", 21);
    fontTypefaceCombo.addItem("Bookman Old Style", 22);
    fontTypefaceCombo.addItem("Lucida Handwriting", 23);
    fontTypefaceCombo.addItem("Monotype Corsiva", 24);
    fontTypefaceCombo.addItem("Cambria", 25);
    fontTypefaceCombo.addItem("Calibri", 26);
    fontTypefaceCombo.addItem("Constantia", 27);
    fontTypefaceCombo.addItem("Corbel", 28);
    fontTypefaceCombo.addItem("Microsoft Sans Serif", 29);
    fontTypefaceCombo.setSelectedId(processor.pianoRollFontTypefaceIndex.load() + 1, juce::dontSendNotification);
    gPianoRollTypefaceIndex.store(processor.pianoRollFontTypefaceIndex.load());
    fontTypefaceCombo.onChange = [this] {
        processor.pianoRollFontTypefaceIndex.store(fontTypefaceCombo.getSelectedId() - 1);
        gPianoRollTypefaceIndex.store(fontTypefaceCombo.getSelectedId() - 1);
        repaint();
        markPersistentEditorStateChanged();
        processor.saveGlobalSettings();
    };
    fontTypefaceCombo.setVisible(false);

    // --- Pitch-bend settings panel controls ---
    addAndMakeVisible(pbRangeCombo);
    pbRangeCombo.addItem("1 st", 1);
    pbRangeCombo.addItem("2 st", 2);
    pbRangeCombo.addItem("7 st", 3);
    pbRangeCombo.addItem("12 st", 4);
    pbRangeCombo.addItem("24 st", 5);
    pbRangeCombo.addItem("48 st", 6);
    pbRangeCombo.onChange = [this] {
        const int ranges[6] = { 1, 2, 7, 12, 24, 48 };
        const int id = pbRangeCombo.getSelectedId();
        if (id >= 1 && id <= 6) {
            processor.pitchBendRange.store(ranges[id - 1]);
            processor.updateHostDisplay();
            markPersistentEditorStateChanged();
            repaint();
        }
    };
    pbRangeCombo.setVisible(false);

    addAndMakeVisible(pbShapeCombo);
    pbShapeCombo.addItem("Linear", 1);
    pbShapeCombo.addItem("Square", 2);
    pbShapeCombo.addItem("Smooth", 3);
    pbShapeCombo.addItem("Ease In", 4);
    pbShapeCombo.addItem("Ease Out", 5);
    pbShapeCombo.addItem("Sine", 6);
    pbShapeCombo.onChange = [this] {
        processor.pitchShape.store(juce::jlimit(0, 5, pbShapeCombo.getSelectedId() - 1));
        processor.updateHostDisplay();
        markPersistentEditorStateChanged();
        repaint();
    };
    pbShapeCombo.setVisible(false);

    addAndMakeVisible(pbResolutionCombo);
    // Delivery is floored at ~0.5 ms for instrument stability, so the labels
    // describe the evaluation granularity (audibly identical across all).
    pbResolutionCombo.addItem("Maximum (per-sample eval)", 1);
    pbResolutionCombo.addItem("Fine", 2);
    pbResolutionCombo.addItem("Balanced", 3);
    pbResolutionCombo.addItem("Economy", 4);
    pbResolutionCombo.onChange = [this] {
        const int micros[4] = { 0, 250, 500, 1000 };
        const int id = pbResolutionCombo.getSelectedId();
        if (id >= 1 && id <= 4) {
            processor.pitchBendStepMicros.store(micros[id - 1]);
            processor.updateHostDisplay();
            markPersistentEditorStateChanged();
        }
    };
    pbResolutionCombo.setVisible(false);

    addAndMakeVisible(pitchPreviewToggle);
    pitchPreviewToggle.setButtonText("Loop preview");
    pitchPreviewToggle.setTooltip("While ON, grab a pitch point: the whole note sustains and its full bend curve loops, so you hear the slide live.");
    pitchPreviewToggle.onClick = [this] {
        pitchPreviewEnabled = pitchPreviewToggle.getToggleState();
        processor.pianoRollPitchPreview.store(pitchPreviewEnabled);
        if (!pitchPreviewEnabled)
            stopPitchPreview();
        markPersistentEditorStateChanged();
        repaint();
    };
    pitchPreviewToggle.setVisible(false);

    addAndMakeVisible(pbModeCombo);
    pbModeCombo.addItem("Pitch Bend (shared wheel)", 1);
    pbModeCombo.addItem("MPE (per-note)", 2);
    pbModeCombo.setTooltip("Pitch Bend: notes on channels 2-16 but ALL bends on the shared channel-1 wheel (works with instruments that only honor channel 1, e.g. Kontakt without MPE). MPE: normal MPE, per-note wheels, channel 1 = master.");
    pbModeCombo.onChange = [this] {
        const int id = pbModeCombo.getSelectedId();
        if (id == 1 || id == 2) {
            processor.bendMode.store(id - 1);
            processor.updateHostDisplay();
            markPersistentEditorStateChanged();
            repaint();
        }
    };
    pbModeCombo.setVisible(false);
}

void PianoRollComponent::syncPbSettingsCombos()
{
    const int ranges[6] = { 1, 2, 7, 12, 24, 48 };
    const int range = processor.pitchBendRange.load();
    int rangeId = 1;
    for (int i = 0; i < 6; ++i)
        if (ranges[i] == range) { rangeId = i + 1; break; }
    pbRangeCombo.setSelectedId(rangeId, juce::dontSendNotification);

    pbShapeCombo.setSelectedId(juce::jlimit(0, 5, processor.pitchShape.load()) + 1, juce::dontSendNotification);

    const int micros = processor.pitchBendStepMicros.load();
    int resId = 1; // Maximum
    if (micros == 250) resId = 2;
    else if (micros == 500) resId = 3;
    else if (micros == 1000) resId = 4;
    pbResolutionCombo.setSelectedId(resId, juce::dontSendNotification);

    pitchPreviewEnabled = processor.pianoRollPitchPreview.load();
    pitchPreviewToggle.setToggleState(pitchPreviewEnabled, juce::dontSendNotification);
    pbModeCombo.setSelectedId(processor.bendMode.load() + 1, juce::dontSendNotification);
}

PianoRollComponent::~PianoRollComponent() 
{ 
    if (settingsDirty) {
        settingsDirty = false;
        storePersistentEditorState();
        processor.saveGlobalSettings();
    }
    stopTimer(); 
    previewNoteOff();
    stopPitchPreview();
}

void PianoRollComponent::changeListenerCallback (juce::ChangeBroadcaster* source)
{
    // Live-update the note / pitch-line colour while the user drags in the
    // selector (colourSelectorTarget tells which one is open).
    if (auto* cs = dynamic_cast<juce::ColourSelector*> (source))
    {
        if (colourSelectorTarget == 1)
            processor.pianoRollPitchLineColour.store(cs->getCurrentColour().getARGB());
        else if (colourSelectorTarget == 2)
            processor.pianoRollGridBgColour.store(cs->getCurrentColour().getARGB());
        else if (colourSelectorTarget == 3)
            processor.pianoRollGridLineColour.store(cs->getCurrentColour().getARGB());
        else if (colourSelectorTarget == 4)
            processor.pianoRollNoteTextColour.store(cs->getCurrentColour().getARGB());
        else if (colourSelectorTarget == 5)
            processor.pianoRollToolbarTextColour.store(cs->getCurrentColour().getARGB());
        else if (colourSelectorTarget == 6)
            processor.pianoRollNoteNameColour.store(cs->getCurrentColour().getARGB());
        else if (colourSelectorTarget == 7)
            processor.pianoRollRazorColour.store(cs->getCurrentColour().getARGB());
        else
            processor.pianoRollNoteColour.store(cs->getCurrentColour().getARGB());
        markPersistentEditorStateChanged();
        processor.saveGlobalSettings();
        repaint();
    }
}

void PianoRollComponent::launchColourPicker (int target, const juce::Rectangle<int>& anchor)
{
    colourSelectorTarget = target;
    // No alpha channel: notes and pitch lines are always fully opaque.
    auto* selector = new juce::ColourSelector(juce::ColourSelector::showSliders
                                              | juce::ColourSelector::showColourspace);
    selector->setName(target == 1 ? "Pitch Line Colour" : (target == 2 ? "Grid Background Colour" : (target == 3 ? "Grid Line Colour" : (target == 4 ? "Note Text Colour" : (target == 5 ? "Toolbar Text Colour" : (target == 6 ? "Note Name Colour" : (target == 7 ? "Razor Selection Colour" : "Note Colour")))))));
    selector->setSize(320, 300);
    selector->setCurrentColour(target == 1 ? getPitchLineBaseColour() : (target == 2 ? getThemeBackgroundColour() : (target == 3 ? getThemeGridLineColour(2) : (target == 4 ? getNoteTextColour() : (target == 5 ? getToolbarTextColour() : (target == 6 ? getNoteNameColour() : (target == 7 ? juce::Colour(processor.pianoRollRazorColour.load()) : getNoteBaseColour())))))));
    selector->addChangeListener(this);
    juce::CallOutBox::launchAsynchronously(std::unique_ptr<juce::Component>(selector),
                                           localAreaToGlobal(anchor), this);
}

void PianoRollComponent::timerCallback() 
{
    // Flush debounced settings (XML write + host refresh) at most ~3 Hz
    // (every 20th tick of the 60 Hz timer) so scrolling or dragging a slider
    // never triggers file-I/O / host-refresh storms on the message thread.
    if (settingsDirty && ++settingsFlushTick >= 20) {
        settingsFlushTick = 0;
        settingsDirty = false;
        storePersistentEditorState();
        processor.saveGlobalSettings();
        processor.updateHostDisplay();
    }

        if (processor.stateRestoredFlag.exchange(false)) {
        loadPersistentEditorState();
        themeCombo.setSelectedId(currentThemeIndex + 1, juce::dontSendNotification);
        fontTypefaceCombo.setSelectedId(processor.pianoRollFontTypefaceIndex.load() + 1, juce::dontSendNotification);
        gPianoRollTypefaceIndex.store(processor.pianoRollFontTypefaceIndex.load());
        pitchNodeSizeSlider.setValue(pitchNodeSize, juce::dontSendNotification);
        pitchLineThicknessSlider.setValue(pitchLineThickness, juce::dontSendNotification);
        pitchLineContrastSlider.setValue(pitchLineContrast, juce::dontSendNotification);
        gridOpacitySlider.setValue(gridOpacityMultiplier, juce::dontSendNotification);
        noteCornerRadiusSlider.setValue(noteCornerRadius, juce::dontSendNotification);
        playheadThicknessSlider.setValue(playheadThickness, juce::dontSendNotification);
        noteContrastSlider.setValue(noteContrast, juce::dontSendNotification);
        ghostPitchLinesOpacitySlider.setValue(processor.pianoRollGhostPitchLineOpacity.load(),
                                              juce::dontSendNotification);
        noteNameFontSizeSlider.setValue(processor.pianoRollNoteNameFontSize.load(),
                                        juce::dontSendNotification);
        syncPbSettingsCombos();
        repaint();
    }

    // Animated scroll/zoom easing: lerp toward the wheel-set targets
    // (exponential ease; settles in ~150-200 ms).
    if (viewAnimating)
    {
        const float ease = 0.35f;
        viewX += (animViewX - viewX) * ease;
        viewY += (animViewY - viewY) * ease;
        pixelsPerBeat += (animPixelsPerBeat - pixelsPerBeat) * ease;
        if (std::fabs(animViewX - viewX) < 0.5f
            && std::fabs(animViewY - viewY) < 0.5f
            && std::fabs(animPixelsPerBeat - pixelsPerBeat) < 0.05f)
        {
            viewX = animViewX;
            viewY = animViewY;
            pixelsPerBeat = animPixelsPerBeat;
            viewAnimating = false;
        }
        repaint();
    }

    // Note-placement flash decay.
    if (flashNoteIndex >= 0)
    {
        noteFlashAlpha *= 0.80f;
        if (noteFlashAlpha < 0.02f)
        {
            flashNoteIndex = -1;
            noteFlashAlpha = 0.0f;
        }
        repaint();
    }

    // If the transport starts while a pitch preview is armed, disarm it so it
    // never clashes with the sequencer (the audio thread ignores it anyway).
    if (processor.pitchPreviewActive.load() && processor.isHostPlaying.load())
        processor.stopPitchPreview();

    bool currentlyPlaying = processor.isHostPlaying.load();
    if (currentlyPlaying || wasPlaying) {
        int topOffset = rulerHeight + toolbarHeight;
        int bottomOffset = showVelocityLane ? velocityLaneHeight : 0;
        repaint(keysWidth, topOffset, juce::jmax(0, getWidth() - keysWidth), juce::jmax(0, getHeight() - topOffset - bottomOffset));
        if (showVelocityLane)
            repaint(keysWidth, getHeight() - velocityLaneHeight, juce::jmax(0, getWidth() - keysWidth), velocityLaneHeight);
    }
    wasPlaying = currentlyPlaying;
}

void PianoRollComponent::previewNoteOn(int note) 
{
    if (processor.isHostPlaying.load()) return;
    
    // Preview note always on channel 2; the wheel goes to channel 1 in Pitch
    // Bend mode (shared wheel) or channel 2 in MPE mode (per-note wheel).
    const int pChan = 2;
    const int pWheelCh = (processor.bendMode.load() == 1) ? 2 : 1;

    if (lastPreviewedNote != note) {
        if (lastPreviewedNote != -1) previewNoteOff();
        lastPreviewedNote = note;
        // Reset the pitch wheel to center (0 bend) before the note-on — a
        // previous slide may have left the wheel at a bend value (e.g. +12 st),
        // which would otherwise make the preview sound shifted.
        processor.addLiveMidiEvent(juce::MidiMessage::pitchWheel(pWheelCh, 8192));
        processor.addLiveMidiEvent(juce::MidiMessage::noteOn(pChan, note, (juce::uint8)100));
    }
}

void PianoRollComponent::previewNoteOff() 
{
    if (lastPreviewedNote != -1) {
        processor.addLiveMidiEvent(juce::MidiMessage::noteOff(2, lastPreviewedNote, (juce::uint8)0));
        lastPreviewedNote = -1;
    }
}

void PianoRollComponent::startPitchPreview(int midiNote, int noteIndex)
{
    if (!pitchPreviewEnabled || processor.isHostPlaying.load())
        return;

    // The audio thread takes it from here: sustained note + full curve sweep
    // at the exact playback pitch-bend resolution.
    processor.startPitchPreview(midiNote, noteIndex);
}

void PianoRollComponent::stopPitchPreview()
{
    processor.stopPitchPreview();
}

void PianoRollComponent::updatePitchPreviewBend(float bendSemitones, float beatOffset)
{
    // Nudge the audio-thread sweep playhead to the dragged position so the
    // bend at the cursor is heard immediately.
    juce::ignoreUnused(bendSemitones);
    processor.pitchPreviewJumpBeat.store(beatOffset);
}

void PianoRollComponent::ensurePitchStartPoints()
{
    // Every note gets its "reset" start point {0, 0} (pitch 0 at the note
    // onset). Seeding ALL notes up front (instead of lazily on click) means
    // stacked notes sharing the same grid line can never end up with a
    // missing start point. Idempotent: existing curves are untouched.
    const juce::ScopedLock sl(processor.noteLock);
    const int startShape = bakedNodeShapeFor(processor); // freeze the global mode into new curves
    for (auto& n : processor.notes)
        if (n.pitchCurve.empty())
            n.pitchCurve.push_back({0.0f, 0.0f, 0.0f, startShape});
}

void PianoRollComponent::loadPersistentEditorState()
{
    // Always load global theme settings
    currentThemeIndex = processor.pianoRollThemeIndex.load();
    pitchNodeSize = processor.pianoRollPitchNodeSize.load();
    pitchLineThickness = processor.pianoRollPitchLineThickness.load();
    gridOpacityMultiplier = processor.pianoRollGridOpacity.load();
    noteCornerRadius = processor.pianoRollNoteCornerRadius.load();
    playheadThickness = processor.pianoRollPlayheadThickness.load();
    velocityLaneHeight = processor.pianoRollVelocityLaneHeight.load();
    noteContrast = processor.pianoRollNoteContrast.load();
    pitchLineContrast = processor.pianoRollPitchLineContrast.load();
    pitchPreviewEnabled = processor.pianoRollPitchPreview.load();

    // FREEZE already-drawn pitch curves to the shape they are currently
    // rendered with. Curves drawn before this build used "auto" nodes
    // (shape 0, no tension) that silently re-shaped whenever the GLOBAL
    // pitch-shape mode changed. Bake every plain auto node to the global
    // mode as of NOW so existing curves keep their look, and the global
    // shape only affects curves drawn from here on. Idempotent (runs once
    // per state restore; tension nodes are left alone — tension already
    // overrides the global mode).
    {
        const juce::ScopedLock sl(processor.noteLock);
        const int bakedShape = bakedNodeShapeFor(processor);
        bool anyBaked = false;
        for (auto& n : processor.notes)
            for (auto& p : n.pitchCurve)
                if (p.shape == 0 && p.tension == 0.0f)
                {
                    p.shape = bakedShape;
                    anyBaked = true;
                }
        if (anyBaked)
            processor.notesRevision.fetch_add(1); // refresh the paint cache
    }

    if (!processor.pianoRollHasSavedEditorState.load())
        return;

    currentGridDivisorIndex = juce::jlimit(0, 5, processor.pianoRollGridDivisorIndex.load());
    currentTool = processor.pianoRollToolMode.load() == 1 ? SelectTool : DrawTool;
    showPitchEnvelopes = processor.pianoRollShowPitchEnvelopes.load();
    showVelocityLane = processor.pianoRollShowVelocityLane.load();
    isScaleLockActive = processor.pianoRollScaleLockActive.load();
    scaleRoot = juce::jlimit(0, scaleNoteNames.size() - 1, processor.pianoRollScaleRoot.load());
    scaleType = juce::jlimit(0, scaleNames.size() - 1, processor.pianoRollScaleType.load());
    keyHeight = juce::jlimit(4.0f, 80.0f, processor.pianoRollKeyHeight.load());
    pixelsPerBeat = juce::jlimit(10.0f, 400.0f, processor.pianoRollPixelsPerBeat.load());
    viewX = juce::jmax(0.0f, processor.pianoRollViewX.load());
    viewY = juce::jlimit(0.0f, (float)(numKeys * keyHeight), processor.pianoRollViewY.load());

    // If pitch mode is active after a reload, make sure every note has its
    // start point (covers stacked notes on the same grid line too).
    if (showPitchEnvelopes)
        ensurePitchStartPoints();
}

void PianoRollComponent::storePersistentEditorState() const
{
    processor.pianoRollHasSavedEditorState.store(true);
    processor.pianoRollPitchPreview.store(pitchPreviewEnabled);
    processor.pianoRollGridDivisorIndex.store(currentGridDivisorIndex);
    processor.pianoRollToolMode.store(currentTool == SelectTool ? 1 : 0);
    processor.pianoRollShowPitchEnvelopes.store(showPitchEnvelopes);
    processor.pianoRollShowVelocityLane.store(showVelocityLane);
    processor.pianoRollScaleLockActive.store(isScaleLockActive);
    processor.pianoRollScaleRoot.store(scaleRoot);
    processor.pianoRollScaleType.store(scaleType);
    processor.pianoRollKeyHeight.store(keyHeight);
    processor.pianoRollPixelsPerBeat.store(pixelsPerBeat);
    processor.pianoRollViewX.store(viewX);
    processor.pianoRollViewY.store(viewY);
    
    processor.pianoRollThemeIndex.store(currentThemeIndex);
    processor.pianoRollPitchNodeSize.store(pitchNodeSize);
    processor.pianoRollPitchLineThickness.store(pitchLineThickness);
    processor.pianoRollGridOpacity.store(gridOpacityMultiplier);
    processor.pianoRollNoteCornerRadius.store(noteCornerRadius);
    processor.pianoRollPlayheadThickness.store(playheadThickness);
    processor.pianoRollVelocityLaneHeight.store(velocityLaneHeight);
    processor.pianoRollNoteContrast.store(noteContrast);
    processor.pianoRollPitchLineContrast.store(pitchLineContrast);
}

void PianoRollComponent::markPersistentEditorStateChanged() const
{
    // Debounced: the 30 Hz timer performs the actual persistence, so rapid
    // events (wheel scrolling, slider drags) don't churn disk I/O.
    settingsDirty = true;
}

juce::String PianoRollComponent::getNoteName(int midiNote) const
{
    const char* noteNames[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    int safeNote = juce::jlimit(0, 127, midiNote);
    int octave = (safeNote / 12) - 1; 
    return juce::String(noteNames[safeNote % 12]) + juce::String(octave);
}

int PianoRollComponent::screenToNote(int y) const 
{
    float gridY = (float)y + viewY - (float)rulerHeight - (float)toolbarHeight;
    int row = (int)(gridY / keyHeight);
    return juce::jlimit(0, 127, 127 - row);
}

float PianoRollComponent::screenToBeat(int x) const 
{
    float gridX = (float)x + viewX - (float)keysWidth;
    return juce::jmax(0.0f, gridX / pixelsPerBeat);
}

juce::Rectangle<float> PianoRollComponent::getNoteRectGridSpace(int midiNote, float startBeat, float lengthBeats) const 
{
    float y = (127 - midiNote) * keyHeight;
    float x = startBeat * pixelsPerBeat;
    float w = lengthBeats * pixelsPerBeat;
    return juce::Rectangle<float>(x, y + 1.0f, w, keyHeight - 2.0f);
}

void PianoRollComponent::repaintPitchEditArea(const NoteEvent& note)
{
    int topOffset = rulerHeight + toolbarHeight;
    auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
    rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);

    float pitchPad = ((float)processor.pitchBendRange.load() * keyHeight) + 48.0f;
    auto area = rect.expanded(96.0f, pitchPad).getIntersection(getLocalBounds().toFloat());

    if (area.isEmpty())
        repaint();
    else
        repaint(area.getSmallestIntegerContainer().expanded(2));
}

void PianoRollComponent::repaintPitchCurveSegment(const NoteEvent& note, int nodeIndex, juce::Point<float> previousPoint)
{
    if (nodeIndex < 0 || nodeIndex >= (int)note.pitchCurve.size() || note.lengthBeats <= 0.0001f)
    {
        repaintPitchEditArea(note);
        return;
    }

    int topOffset = rulerHeight + toolbarHeight;
    auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
    rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
    const float cy = rect.getCentreY();

    auto toScreen = [&] (float px, float py)
    {
        return juce::Point<float>(rect.getX() + (px / note.lengthBeats) * rect.getWidth(),
                                  cy - (py * keyHeight));
    };

    juce::Rectangle<float> area;
    bool hasArea = false;
    auto includePoint = [&] (juce::Point<float> p)
    {
        const auto pointArea = juce::Rectangle<float>(p.x, p.y, 1.0f, 1.0f);
        area = hasArea ? area.getUnion(pointArea) : pointArea;
        hasArea = true;
    };

    includePoint(toScreen(previousPoint.x, previousPoint.y));
    includePoint(toScreen(note.pitchCurve[(size_t)nodeIndex].x, note.pitchCurve[(size_t)nodeIndex].y));

    if (nodeIndex > 0)
        includePoint(toScreen(note.pitchCurve[(size_t)nodeIndex - 1].x, note.pitchCurve[(size_t)nodeIndex - 1].y));

    if (nodeIndex + 1 < (int)note.pitchCurve.size())
        includePoint(toScreen(note.pitchCurve[(size_t)nodeIndex + 1].x, note.pitchCurve[(size_t)nodeIndex + 1].y));

    auto clipped = area.expanded(88.0f, 34.0f).getIntersection(getLocalBounds().toFloat());
    if (clipped.isEmpty())
        repaintPitchEditArea(note);
    else
        repaint(clipped.getSmallestIntegerContainer().expanded(2));
}

void PianoRollComponent::paint (juce::Graphics& g)
{
    g.fillAll(getThemeBackgroundColour());

    int topOffset = rulerHeight + toolbarHeight;
    int bottomOffset = showVelocityLane ? velocityLaneHeight : 0;

    std::vector<NoteEvent> localNotes;
    // Virtualized paint snapshot: re-copy only when the notes actually
    // changed (revision bump) or while a gesture is live-mutating them.
    // Steady-state repaints (scrolling, zooming, playback) reuse the cached
    // copy, so a 100k-note project no longer deep-copies every frame.
    const bool gestureActive = draggingNoteIndex >= 0 || currentDragAction != None
                            || isStretchingRazor || isResizingRazor || isRazorSelecting || isMarqueeSelecting
                            || editingPitchCurveNodeIndex >= 0 || editingPitchCurveTensionNodeIndex >= 0;
    if (gestureActive || processor.notesRevision.load() != cachedNotesRevision)
    {
        if (processor.noteLock.tryEnter()) {
            paintNotesCache = processor.notes;
            processor.noteLock.exit();
            cachedNotesRevision = processor.notesRevision.load();
        }
    }
    {
        localNotes = paintNotesCache;
    }

    int visibleStartKey = juce::jmax(0, (int)(viewY / keyHeight));
    int visibleEndKey = juce::jmin(numKeys, (int)((viewY + getHeight() - bottomOffset) / keyHeight) + 1);
    
    float visibleStartBeat = juce::jmax(0.0f, viewX / pixelsPerBeat);
    float visibleEndBeat = (viewX + getWidth()) / pixelsPerBeat;
    float gridDrawX = juce::jmax(0.0f, visibleStartBeat * pixelsPerBeat - 200.0f);
    float gridDrawW = ((visibleEndBeat - visibleStartBeat) * pixelsPerBeat) + 400.0f;

    // 1. Draw Grid and Notes
    {
        juce::Graphics::ScopedSaveState state(g);
        g.reduceClipRegion(keysWidth, topOffset, getWidth() - keysWidth, getHeight() - topOffset - bottomOffset);
        g.addTransform(juce::AffineTransform::translation((float)keysWidth - viewX, (float)topOffset - viewY));

        for (int i = visibleStartKey; i <= visibleEndKey; ++i) {
            int note = 127 - i;
            float y = i * keyHeight;
            
            // FL-style row shading: white-key rows a shade lighter, black-key
            // rows darker — the rows read as a piano keyboard across the grid.
            // Kept very SUBTLE so it never reads as a "highlighted scale" on
            // its own, and switched to uniform rows while a real scale
            // highlight is active so the two never interfere.
        // With a custom Grid Bg override, keep the scale-lock shading close
        // to the background too (0.30/0.42 would wash pure black out to grey).
        const float scaleLockLift = processor.pianoRollGridBgColour.load() != 0 ? 0.06f : 0.30f;
        g.setColour(isScaleLockActive ? getThemeBackgroundColour().brighter(scaleLockLift)
        : getThemeGridColour(isBlackMidiKey(note)));
            g.fillRect(gridDrawX, y, gridDrawW, keyHeight);

            // Octave banding: very faint lift on C rows for orientation.
            if (note % 12 == 0)
            {
                g.setColour(juce::Colours::white.withAlpha(0.015f));
                g.fillRect(gridDrawX, y, gridDrawW, keyHeight);
            }

            // Scale highlight: while scale lock is active, the scale rows get
            // a clear lift derived from the SAME background colour as the
            // rows (base = bg.brighter(0.30), scale rows = bg.brighter(0.42))
            // so the highlight always matches the piano roll background.
            if (isScaleLockActive && isNoteInScale(note, scaleRoot, scaleType)) {
                // With a custom Grid Bg override the highlight lift shrinks so
                // it stays a subtle tint instead of washing black out to grey.
                g.setColour(getThemeBackgroundColour().brighter(processor.pianoRollGridBgColour.load() != 0 ? 0.14f : 0.42f));
                g.fillRect(gridDrawX, y, gridDrawW, keyHeight);
            }
        }

        float currentSnap = getCurrentGridSnap();
        float snapStartBeat = std::floor(visibleStartBeat / currentSnap) * currentSnap;

        const float subBeatMult = processor.pianoRollGridSubBeatThickness.load();
        const float halfBeatMult = processor.pianoRollGridHalfBeatThickness.load();
        const float beatMult = processor.pianoRollGridBeatThickness.load();
        const float barMult = processor.pianoRollGridBarThickness.load();

        // Adaptive level-of-detail: fine lines fade out as they get denser
        // when zoomed out, so the grid never turns into a wall. Each factor
        // is 1.0 at the default zoom (pixelsPerBeat >= 20) and ramps to 0
        // below its threshold; lines at alpha < ~2% are skipped entirely.
        const float ppb = pixelsPerBeat;
        const float subBeatLod = juce::jlimit(0.0f, 1.0f, (ppb - 5.0f) / 7.0f);
        const float halfBeatLod = juce::jlimit(0.0f, 1.0f, (ppb - 9.0f) / 9.0f);
        const float beatLod = juce::jlimit(0.65f, 1.0f, ppb / 12.0f);
        const float barLod = juce::jlimit(0.80f, 1.0f, ppb / 10.0f);

        for (float beat = snapStartBeat; beat <= visibleEndBeat; beat += currentSnap) {
            // Snap to the pixel grid (half-pixel offset) so 1px lines render
            // crisp instead of anti-aliased across two pixels.
            const float x = std::floor(beat * pixelsPerBeat) + 0.5f;
            
            bool isBar = isBeatMultiple(beat, 4.0f);
            bool isBeat = isBeatMultiple(beat, 1.0f);
            bool isHalfBeat = ! isBeat && isBeatMultiple(beat, 0.5f);
            
            // Clearly distinct line hierarchy: measures = strong & bright,
            // beats = medium, half-beats = between, sub-beats = faint
            // (thickness scales with the theme slider).
            if (isBar) {
                const float a = juce::jlimit(0.0f, 1.0f, 0.8f * gridOpacityMultiplier * barLod);
                if (a < 0.02f) continue;
                // Subtle alternate-bar background banding for orientation.
                if (((int)std::floor(beat / 4.0f) % 2) != 0)
                {
                    g.setColour(juce::Colours::white.withAlpha(0.020f));
                    g.fillRect(x, 0.0f, pixelsPerBeat * 4.0f, numKeys * keyHeight);
                }
                g.setColour(getThemeGridLineColour(2).withAlpha(a));
                g.drawLine(x, 0.0f, x, numKeys * keyHeight, 1.6f * barMult);
            } else if (isBeat) {
                const float a = juce::jlimit(0.0f, 1.0f, 0.5f * gridOpacityMultiplier * beatLod);
                if (a < 0.02f) continue;
                g.setColour(getThemeGridLineColour(1).withAlpha(a));
                g.drawLine(x, 0.0f, x, numKeys * keyHeight, 0.9f * beatMult);
            } else if (isHalfBeat) {
                const float a = juce::jlimit(0.0f, 1.0f, 0.35f * gridOpacityMultiplier * halfBeatLod);
                if (a < 0.02f) continue;
                g.setColour(getThemeGridLineColour(1).withAlpha(a));
                g.drawLine(x, 0.0f, x, numKeys * keyHeight, 0.7f * halfBeatMult);
            } else {
                const float a = juce::jlimit(0.0f, 1.0f, 0.22f * gridOpacityMultiplier * subBeatLod);
                if (a < 0.02f) continue;
                g.setColour(getThemeGridLineColour(0).withAlpha(a));
                g.drawLine(x, 0.0f, x, numKeys * keyHeight, 0.5f * subBeatMult);
            }
        }

        // Very subtle horizontal lines at every key row (barely visible,
        // just enough to follow a row across the grid).
        {
            const float rowLineAlpha = juce::jlimit(0.0f, 1.0f, 0.16f * gridOpacityMultiplier);
            g.setColour(getThemeGridLineColour(0).withAlpha(rowLineAlpha));
            for (int i = visibleStartKey; i <= visibleEndKey; ++i)
            {
                const float rowY = std::floor((float)i * keyHeight) + 0.5f;
                g.drawLine(gridDrawX, rowY, gridDrawX + gridDrawW, rowY, 0.5f);
            }
        }
        
        if (processor.isLooping.load()) {
            float loopStart = processor.loopStartBeat.load();
            float loopEnd = processor.loopEndBeat.load();
            if (loopEnd > loopStart) {
                g.setColour(juce::Colour(0x5a000000));
                g.fillRect(0.0f, 0.0f, loopStart * pixelsPerBeat, numKeys * keyHeight);
                g.fillRect(loopEnd * pixelsPerBeat, 0.0f, gridDrawX + gridDrawW, numKeys * keyHeight);
                
                g.setColour(getThemeAccentColour().withAlpha(0.6f));
                g.drawLine(loopStart * pixelsPerBeat, 0.0f, loopStart * pixelsPerBeat, numKeys * keyHeight, 1.0f);
                g.drawLine(loopEnd * pixelsPerBeat, 0.0f, loopEnd * pixelsPerBeat, numKeys * keyHeight, 1.0f);
            }
        }

        // Draw Notes
        auto isPriorityNote = [&] (size_t noteIdx) noexcept
        {
            const int idx = (int)noteIdx;
            return idx == editingPitchCurveNoteIndex || idx == draggingNoteIndex;
        };

        auto drawNote = [&] (size_t noteIdx)
        {
            const auto& note = localNotes[noteIdx];
            if (note.startBeat > visibleEndBeat || (note.startBeat + note.lengthBeats) < visibleStartBeat)
                return;
            int noteRow = 127 - note.midiNote;
            if (noteRow < visibleStartKey || noteRow > visibleEndKey)
                return;

            auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
            const bool isPriority = isPriorityNote(noteIdx);
            
            const bool isPitchEditedNote = showPitchEnvelopes && (int)noteIdx == editingPitchCurveNoteIndex;
            const float globalAlpha = isPitchEditedNote ? 0.3f : 1.0f;
            
            // Uniform highlight: every note uses the theme accent colour.
            juce::Colour baseColour = getNoteColour(note, getNoteBaseColour(), noteContrast);
            baseColour = baseColour.withMultipliedAlpha(globalAlpha);

            // Velocity shading: brighter notes = higher velocity (capped
            // boost so dynamics read at a glance without washing the colour).
            baseColour = baseColour.brighter(juce::jlimit(-0.18f, 0.28f,
                                                          (note.velocity / 127.0f - 0.5f) * 0.55f));

            float currentCornerRadius = noteCornerRadius;

            // Rounded-top-only note shape (piano-roll convention: rounded top
            // corners, square bottom).
            const float r = juce::jmin(currentCornerRadius, rect.getHeight() * 0.5f, rect.getWidth() * 0.5f);
            juce::Path notePath;
            notePath.startNewSubPath(rect.getX(), rect.getBottom());
            notePath.lineTo(rect.getX(), rect.getY() + r);
            notePath.quadraticTo(rect.getX(), rect.getY(), rect.getX() + r, rect.getY());
            notePath.lineTo(rect.getRight() - r, rect.getY());
            notePath.quadraticTo(rect.getRight(), rect.getY(), rect.getRight(), rect.getY() + r);
            notePath.lineTo(rect.getRight(), rect.getBottom());
            notePath.closeSubPath();

            // Soft drop shadow (offset down, fades with the note's alpha;
            // tinted with a very dark version of the theme accent).
            g.setColour(getThemeAccentColour().darker(0.82f).withAlpha(0.30f * globalAlpha));
            g.fillPath(notePath, juce::AffineTransform::translation(0.0f, 2.0f));

            // Selection glow: soft double-stroke accent ring.
            if (note.selected)
            {
                g.setColour(getThemeAccentColour().withAlpha(0.32f));
                g.strokePath(notePath, juce::PathStrokeType(2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
                g.setColour(getThemeAccentColour().withAlpha(0.14f));
                g.strokePath(notePath, juce::PathStrokeType(5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            }

            g.setColour(baseColour);
            g.fillPath(notePath);

            // Thin bright top edge (subtle 3D lighting hint).
            g.setColour(juce::Colours::white.withAlpha(0.16f * globalAlpha));
            g.drawLine(rect.getX() + r + 0.5f, rect.getY() + 1.0f,
                       rect.getRight() - r - 0.5f, rect.getY() + 1.0f, 1.0f);

            // Note tail fade: subtle darker gradient at the right edge of
            // long notes (tape-tail feel).
            if (rect.getWidth() >= 24.0f)
            {
                const float tailW = juce::jmin(14.0f, rect.getWidth() * 0.18f);
                g.setGradientFill(juce::ColourGradient(juce::Colour(0x00000000), rect.getRight() - tailW, 0.0f,
                                                       baseColour.darker(0.4f).withAlpha(0.30f * globalAlpha),
                                                       rect.getRight(), 0.0f, false));
                g.fillRect(rect.getRight() - tailW, rect.getY() + 1.0f, tailW, rect.getHeight() - 2.0f);
            }

            // Velocity heat bar: thin ramp along the bottom edge
            // (blue -> teal -> amber as velocity rises).
            if (rect.getHeight() >= 6.0f)
            {
                const float hue = juce::jmap((float)note.velocity, 0.0f, 127.0f, 0.58f, 0.10f);
                const float bri = juce::jmap((float)note.velocity, 0.0f, 127.0f, 0.45f, 0.95f);
                g.setColour(juce::Colour::fromHSV(hue, 0.85f, bri, 0.5f * globalAlpha));
                g.fillRect(rect.getX() + 1.0f, rect.getBottom() - 2.0f, rect.getWidth() - 2.0f, 1.5f);
            }

            // Solid definition: crisp darker outline (full opacity) so notes
            // read as solid blocks with a defined edge, like the reference.
            g.setColour(baseColour.darker(0.45f));
            g.strokePath(notePath, juce::PathStrokeType(1.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            
            // Note Name (off by default for the clean look; toggle in the
            // Theme tweaks panel; colour + bold are themeable)
            if (processor.pianoRollShowNoteNames.load() && rect.getWidth() > 18.0f && keyHeight >= 10.0f) {
                float fontSize = juce::jmin((float)processor.pianoRollNoteNameFontSize.load(), keyHeight * 0.8f);
                g.setFont(getModernFont(fontSize, processor.pianoRollNoteNameBold.load() ? juce::Font::bold : juce::Font::plain));
                auto textRect = rect.withTrimmedLeft(4.0f);
                g.setColour(getNoteNameColour().withMultipliedAlpha(globalAlpha));
                g.drawText(getNoteName(note.midiNote), textRect, juce::Justification::centredLeft, false);
            }

            // Ghost pitch line: when pitch mode is OFF (and the theme-panel
            // toggle is on), draw the note's REAL pitch curve at low
            // visibility — same geometry as pitch mode (y = bend * keyHeight,
            // clamped to the bend range) — so bends are visible at a glance.
            if (!showPitchEnvelopes && processor.pianoRollGhostPitchLines.load()
                && note.pitchCurve.size() >= 2)
            {
                const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                const float range = (float)juce::jmax(1, processor.pitchBendRange.load());
                const int shape = processor.pitchShape.load();
                const float cy = rect.getCentreY();
                const int samples = 24;
                juce::Path ghostLine;
                for (int sIdx = 0; sIdx <= samples; ++sIdx)
                {
                    const float t = (float)sIdx / (float)samples;
                    const float bend = evaluatePitchBendAtBeat(note, noteLength * t, shape);
                    const float x = rect.getX() + rect.getWidth() * t;
                    const float y = cy - (juce::jlimit(-range, range, bend) * keyHeight);
                    if (sIdx == 0) ghostLine.startNewSubPath(x, y);
                    else ghostLine.lineTo(x, y);
                }
                const float ghostAlpha = (float)processor.pianoRollGhostPitchLineOpacity.load() / 100.0f;
                g.setColour(getPitchLineBaseColour().withMultipliedAlpha(ghostAlpha));
                g.strokePath(ghostLine, juce::PathStrokeType(1.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            }
            
            // Draw Pitch Envelope

            if (showPitchEnvelopes && (int)noteIdx == editingPitchCurveNoteIndex) {
                juce::Graphics::ScopedSaveState pitchState(g);
                
                float cy = rect.getCentreY();
                int range = processor.pitchBendRange.load();
                
                const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                const int shape = processor.pitchShape.load();
                auto pointToScreenX = [&] (float beatOffset)
                {
                    return rect.getX() + (juce::jlimit(0.0f, noteLength, beatOffset) / noteLength) * rect.getWidth();
                };
                auto pointToScreenY = [&] (float semitones)
                {
                    return cy - (juce::jlimit(-(float)range, (float)range, semitones) * keyHeight);
                };

                const auto pitchColour = getPitchLineBaseColour();

                // Draw pitch lane
                float pitchAreaY = cy - (range * keyHeight);
                float pitchAreaH = (range * 2) * keyHeight;
                juce::Rectangle<float> pitchArea(rect.getX(), pitchAreaY, rect.getWidth(), pitchAreaH);
                
                // Draw semitone grid lines
                g.setFont(getModernFont(juce::jmin(9.0f, keyHeight * 0.72f), juce::Font::bold));
                for (int st = -range; st <= range; ++st) {
                    if (st == 0) continue;
                    float sty = cy - (st * keyHeight);
                    const bool octaveLine = (st % 12) == 0;
                    g.setColour(juce::Colours::white.withAlpha(octaveLine ? 0.150f : 0.060f));
                    g.drawLine(rect.getX(), sty, rect.getRight(), sty, octaveLine ? 0.22f : 0.08f);
                    
                    if (keyHeight >= 10.0f && (octaveLine || std::abs(st) == range)) {
                        g.setColour(juce::Colour(0xffdffdfa).withAlpha(0.68f));
                        juce::String label = (st > 0 ? "+" : "") + juce::String(st);
                        g.drawText(label, rect.getRight() - 34.0f, (int)(sty - keyHeight * 0.5f), 30, (int)keyHeight, juce::Justification::centredRight, false);
                    }
                }

                // Center line (0 pitch bend)
                float dashLengths[] = { 4.0f, 4.0f };
                g.setColour(juce::Colour(0xff4ade80).withAlpha(0.3f));
                g.drawDashedLine(juce::Line<float>(rect.getX(), cy, rect.getRight(), cy), dashLengths, 2, 1.0f);
                
                // Internal vertical grid subdivisions (beat lines inside the note)
                float snap = getCurrentGridSnap();
                g.setColour(juce::Colours::white.withAlpha(0.105f));
                for (float b = snap; b < noteLength; b += snap) {
                    float bx = pointToScreenX(b);
                    g.drawLine(bx, pitchAreaY, bx, pitchAreaY + pitchAreaH, 0.05f);
                }
                 
                if (!note.pitchCurve.empty()) {
                    juce::Path curvePath;
                     
                    float firstY = pointToScreenY(evaluatePitchBendAtBeat(note, 0.0f, shape));
                    curvePath.startNewSubPath(rect.getX(), firstY);
                    
                    // Sample at least once per horizontal pixel AND enough
                    // steps to cover the curve's vertical extent, so steep
                    // slides stay smooth at any zoom level.
                    const float pitchRange = (float)juce::jmax(1, processor.pitchBendRange.load());
                    const float verticalPixels = pitchRange * 2.0f * keyHeight;
                    float numSteps = juce::jmax(8.0f, rect.getWidth(), verticalPixels);
                    // Whether the segment containing beatPos is effectively
                    // square (hold + jump): per-node shape wins, auto nodes
                    // fall back to the global mode.
                    auto isSquareSegment = [&](float beatPos) -> bool
                    {
                        const auto& curve = note.pitchCurve;
                        if (curve.empty())
                            return false;
                        int idx = 0;
                        for (size_t k = 0; k < curve.size(); ++k)
                        {
                            if (curve[k].x <= beatPos + 0.0001f)
                                idx = (int)k;
                            else
                                break;
                        }
                        const auto& left = curve[idx];
                        if (left.shape == 2) return true;
                        if (left.shape == 1 || left.shape == 3) return false;
                        if (left.tension != 0.0f) return false; // tension overrides the global mode
                        return shape == 1;
                    };

                    float prevBeat = 0.0f;
                    for (int i = 1; i <= (int)numSteps; ++i) {
                        float beatOffset = ((float)i / numSteps) * noteLength;
                        float px = pointToScreenX(beatOffset);
                        float py = pointToScreenY(evaluatePitchBendAtBeat(note, beatOffset, shape));

                        // Square segments draw hold + jump (horizontal to the
                        // previous height, then the step). Linear/Bezier draw
                        // straight to the point — no jagged micro-steps, so
                        // the stroke stays uniform and clean.
                        if (isSquareSegment(prevBeat))
                            curvePath.lineTo(px, pointToScreenY(evaluatePitchBendAtBeat(note, prevBeat, shape)));
                        curvePath.lineTo(px, py);
                        prevBeat = beatOffset;
                    }
                    
                    float endY = pointToScreenY(evaluatePitchBendAtBeat(note, noteLength, shape));
                    curvePath.lineTo(rect.getRight(), endY);
                    
                    // Pitch line colour: custom override or theme accent
                    juce::Colour pitchLineColor = getPitchLineBaseColour();
                    if (pitchLineContrast > 1.0f) {
                        pitchLineColor = pitchLineColor.brighter(pitchLineContrast - 1.0f);
                    } else if (pitchLineContrast < 1.0f) {
                        pitchLineColor = pitchLineColor.darker(1.0f - pitchLineContrast);
                    }

                    // Draw Gradient Fill under curve
                    juce::Path fillPath = curvePath;
                    fillPath.lineTo(rect.getRight(), cy);
                    fillPath.lineTo(rect.getX(), cy);
                    fillPath.closeSubPath();
                    
                    juce::ColourGradient grad(pitchLineColor.withAlpha(0.35f), rect.getX(), pitchAreaY,
                                              pitchLineColor.withAlpha(0.35f), rect.getX(), pitchAreaY + pitchAreaH, false);
                    grad.addColour(0.5, pitchLineColor.withAlpha(0.0f));
                    g.setGradientFill(grad);
                    g.fillPath(fillPath);

                    // ---- Cooler pitch curve rendering ----
                    const juce::Colour lineBright = pitchLineColor.brighter(0.45f);

                    // 1) Soft glow underlay (thick, faint)
                    // Curved joins: sharp corners (square steps, steep tension
                    // bends) would grow miter spikes and look thicker/jagged.
                    g.setColour(pitchLineColor.withAlpha(0.16f));
                    g.strokePath(curvePath, juce::PathStrokeType(pitchLineThickness * 3.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                    // 2) Main stroke with an along-curve gradient
                    //    (colour at the note start -> brighter at the end)
                    juce::ColourGradient strokeGrad(pitchLineColor, rect.getX(), 0.0f,
                                                    lineBright, rect.getRight(), 0.0f, false);
                    g.setGradientFill(strokeGrad);
                    g.strokePath(curvePath, juce::PathStrokeType(pitchLineThickness, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                    // 3) Endpoint marker: only the curve START dot remains —
                    // the END dot was removed (user doesn't want the end guard).
                    // Playback is unaffected: release still lands on the curve
                    // value at the note's end (evaluatePitchBendAtBeat(lengthBeats)).
                    {
                        const float s0 = pitchNodeSize / 6.2f;
                        g.setColour(pitchLineColor.withAlpha(0.9f));
                        g.fillEllipse(rect.getX() - 2.2f * s0, firstY - 2.2f * s0, 4.4f * s0, 4.4f * s0);
                    }

                    // 4) Pitch nodes: soft halo + dot (+ bright core while editing)
                    for (size_t i = 0; i < note.pitchCurve.size(); ++i) {
                        if (note.pitchCurve[i].x < -0.0001f || note.pitchCurve[i].x > noteLength + 0.0001f)
                            continue;

                        float px = pointToScreenX(note.pitchCurve[i].x);
                        float py = pointToScreenY(note.pitchCurve[i].y);
                        
                        bool isEditing = (editingPitchCurveNoteIndex == (int)noteIdx && editingPitchCurveNodeIndex == (int)i);
                        bool isSelected = isPitchNodeSelected((int)noteIdx, (int)i);
                        
                        float s = pitchNodeSize / 6.2f;
                        // Marquee-selected nodes get a bright ring + halo.
                        if (isSelected) {
                            g.setColour(juce::Colours::white.withAlpha(0.35f));
                            g.fillEllipse(px - 6.2f * s, py - 6.2f * s, 12.4f * s, 12.4f * s);
                            g.setColour(juce::Colours::white);
                            g.drawEllipse(px - 5.0f * s, py - 5.0f * s, 10.0f * s, 10.0f * s, 1.6f);
                        }
                        g.setColour(pitchLineColor.withAlpha(isEditing ? 0.55f : 0.28f));
                        g.fillEllipse(px - 5.0f * s, py - 5.0f * s, 10.0f * s, 10.0f * s);
                        g.setColour(isEditing ? lineBright : pitchLineColor);
                        g.fillEllipse(px - 3.5f * s, py - 3.5f * s, 7.0f * s, 7.0f * s);
                        if (isEditing) {
                            g.setColour(juce::Colours::white.withAlpha(0.9f));
                            g.fillEllipse(px - 1.4f * s, py - 1.4f * s, 2.8f * s, 2.8f * s);
                        } else {
                            g.setColour(juce::Colour(0xff15191e)); // Dark outline
                            g.drawEllipse(px - 3.5f * s, py - 3.5f * s, 7.0f * s, 7.0f * s, 1.0f * s);
                        }
                    }
                    
                    // Draw ghost point if hovering
                    if ((int)noteIdx == ghostPitchCurveNoteIndex && ghostPitchPoint.x >= 0.0f) {
                        float px = pointToScreenX(ghostPitchPoint.x);
                        float py = pointToScreenY(ghostPitchPoint.y);
                        
                        float s = pitchNodeSize / 6.2f;
                        g.setColour(pitchLineColor.withAlpha(0.2f));
                        g.drawLine(px, py - 6.0f * s, px, py + 6.0f * s, 1.0f);
                        g.drawLine(px - 6.0f * s, py, px + 6.0f * s, py, 1.0f);
                        g.fillEllipse(px - 1.5f * s, py - 1.5f * s, 3.0f * s, 3.0f * s);
                    }
                }
            }
        };

        for (size_t noteIdx = 0; noteIdx < localNotes.size(); ++noteIdx)
            if (!isPriorityNote(noteIdx))
                drawNote(noteIdx);

        for (size_t noteIdx = 0; noteIdx < localNotes.size(); ++noteIdx)
            if (isPriorityNote(noteIdx))
                drawNote(noteIdx);

        // Drag-preview ghost: while moving notes, dim-outline where they
        // were BEFORE the drag so the distance travelled is visible.
        if (showDragGhost && currentDragAction == Move && draggingNoteIndex >= 0)
        {
            for (const auto& state : selectedNotesDragState)
            {
                if (state.index < 0 || state.index >= (int)processor.notes.size())
                    continue;
                auto ghostRect = getNoteRectGridSpace(state.originalMidiNote, state.originalStartBeat,
                                                     state.originalLengthBeats);
                g.setColour(getThemeAccentColour().withAlpha(0.07f));
                g.fillRoundedRectangle(ghostRect, noteCornerRadius);
                g.setColour(getThemeAccentColour().withAlpha(0.32f));
                g.drawRoundedRectangle(ghostRect.reduced(0.5f), noteCornerRadius, 1.3f);
            }
        }

        // Subtle flash right after a note is placed (Draw tool).
        if (flashNoteIndex >= 0 && flashNoteIndex < (int)localNotes.size() && noteFlashAlpha > 0.02f)
        {
            const auto& fn = localNotes[(size_t)flashNoteIndex];
            auto flashRect = getNoteRectGridSpace(fn.midiNote, fn.startBeat, fn.lengthBeats);
            g.setColour(juce::Colours::white.withAlpha(noteFlashAlpha * 0.40f));
            g.fillRoundedRectangle(flashRect, noteCornerRadius);
            g.setColour(juce::Colours::white.withAlpha(noteFlashAlpha));
            g.drawRoundedRectangle(flashRect.reduced(0.5f), noteCornerRadius, 1.6f);
        }

        // Note tail handle: subtle grip at the right edge of the hovered note.
        if (hoverHandleRightEdge && hoverHandleNoteIndex >= 0
            && hoverHandleNoteIndex < (int)localNotes.size())
        {
            const auto& hn = localNotes[(size_t)hoverHandleNoteIndex];
            auto hrect = getNoteRectGridSpace(hn.midiNote, hn.startBeat, hn.lengthBeats);
            juce::Rectangle<float> grip(hrect.getRight() - 4.5f, hrect.getY() + 1.5f, 3.5f, hrect.getHeight() - 3.0f);
            g.setColour(getThemeAccentColour().withAlpha(0.12f));
            g.fillRoundedRectangle(grip.expanded(2.0f), 2.5f);
            g.setColour(getThemeAccentColour().withAlpha(0.40f));
            g.fillRoundedRectangle(grip, 1.5f);
        }

        // Playhead Line (with a soft gradient beam around it)
        float currentBeat = processor.currentPlayheadBeat.load();
        if (currentBeat >= visibleStartBeat && currentBeat <= visibleEndBeat) {
            float playheadX = currentBeat * pixelsPerBeat;
            const float beamHalf = 16.0f;
            juce::ColourGradient beam(juce::Colour(0x00000000), playheadX - beamHalf, 0.0f,
                                      juce::Colour(0x00000000), playheadX + beamHalf, 0.0f, false);
            beam.addColour(0.5, getThemeAccentColour().withAlpha(0.12f));
            g.setGradientFill(beam);
            g.fillRect(playheadX - beamHalf, 0.0f, beamHalf * 2.0f, numKeys * keyHeight);
            g.setColour(getThemeAccentColour().withAlpha(0.15f));
            g.fillRect(playheadX - playheadThickness, 0.0f, playheadThickness * 2.0f, numKeys * keyHeight);
            g.setColour(getThemeAccentColour());
            g.drawLine(playheadX, 0.0f, playheadX, numKeys * keyHeight, playheadThickness);
        }

        // Razor Selection Box
        if (hasRazorSelection || isRazorSelecting) {
            float x = razorStartBeat * pixelsPerBeat;
            float w = (razorEndBeat - razorStartBeat) * pixelsPerBeat;
            float y = (127 - razorTopNote) * keyHeight;
            float h = (razorTopNote - razorBottomNote + 1) * keyHeight;
            
            juce::Rectangle<float> razorRect(x, y, w, h);
            
            const juce::Colour razorCol = juce::Colour(processor.pianoRollRazorColour.load());
            g.setColour(razorCol.withAlpha(0.14f));
            g.fillRect(razorRect);
            
            g.setColour(razorCol);
            g.drawRect(razorRect, 1.1f);

            // Amber stretch handles on the time edges (Alt + drag stretches).
            g.setColour(juce::Colour(0xffffd166));
            g.fillRect(x - 2.0f, y + h * 0.18f, 3.0f, h * 0.64f);
            g.fillRect(x + w - 1.0f, y + h * 0.18f, 3.0f, h * 0.64f);

            // Draw tiny "SELECT" label at bottom right
            g.setFont(getModernFont(13.0f, juce::Font::bold));
            g.drawText("SELECT", razorRect.withTrimmedRight(4.0f).withTrimmedBottom(2.0f), juce::Justification::bottomRight, false);
        }

        // Marquee Selection Box
        if (isMarqueeSelecting) {
            float minX = (float)std::min(marqueeStartPos.x, marqueeCurrentPos.x);
            float minY = (float)std::min(marqueeStartPos.y, marqueeCurrentPos.y);
            float w = (float)std::abs(marqueeStartPos.x - marqueeCurrentPos.x);
            float h = (float)std::abs(marqueeStartPos.y - marqueeCurrentPos.y);
            
            juce::Rectangle<float> mRect(minX - ((float)keysWidth - viewX), minY - ((float)topOffset - viewY), w, h);
            
            g.setColour(juce::Colour(0x30ffffff));
            g.fillRect(mRect);
            g.setColour(juce::Colour(0x80ffffff));
            g.drawRect(mRect, 1.0f);
        }

        // Pitch-node marquee (Ctrl+drag in pitch mode)
        if (isMarqueeSelectingPitch) {
            float pminX = (float)std::min(pitchMarqueeStart.x, pitchMarqueeCurrent.x);
            float pminY = (float)std::min(pitchMarqueeStart.y, pitchMarqueeCurrent.y);
            float pw = (float)std::abs(pitchMarqueeStart.x - pitchMarqueeCurrent.x);
            float ph = (float)std::abs(pitchMarqueeStart.y - pitchMarqueeCurrent.y);
            juce::Rectangle<float> pmRect(pminX - ((float)keysWidth - viewX), pminY - ((float)topOffset - viewY), pw, ph);
            g.setColour(juce::Colour(0x30ffffff));
            g.fillRect(pmRect);
            g.setColour(juce::Colour(0x80ffffff));
            g.drawRect(pmRect, 1.0f);
        }
    }

    // Canvas vignette: very subtle darkening at the grid edges (screen
    // space, on top of the grid content — soft-focus frame effect).
    {
        const float gw = (float)(getWidth() - keysWidth);
        const float gh = (float)(numKeys * keyHeight);
        const float vh = 70.0f;
        const float hh = 90.0f;
        g.setGradientFill(juce::ColourGradient(juce::Colours::black.withAlpha(0.12f), 0.0f, (float)topOffset,
                                               juce::Colour(0x00000000), 0.0f, (float)topOffset + vh, false));
        g.fillRect((float)keysWidth, (float)topOffset, gw, vh);
        g.setGradientFill(juce::ColourGradient(juce::Colour(0x00000000), 0.0f, (float)topOffset + gh - vh,
                                               juce::Colours::black.withAlpha(0.12f), 0.0f, (float)topOffset + gh, false));
        g.fillRect((float)keysWidth, (float)topOffset + gh - vh, gw, vh);
        g.setGradientFill(juce::ColourGradient(juce::Colours::black.withAlpha(0.12f), (float)keysWidth, 0.0f,
                                               juce::Colour(0x00000000), (float)keysWidth + hh, 0.0f, false));
        g.fillRect((float)keysWidth, (float)topOffset, hh, gh);
        g.setGradientFill(juce::ColourGradient(juce::Colour(0x00000000), (float)getWidth() - hh, 0.0f,
                                               juce::Colours::black.withAlpha(0.12f), (float)getWidth(), 0.0f, false));
        g.fillRect((float)getWidth() - hh, (float)topOffset, hh, gh);
    }

    // Selected-note counter chip (3+ notes selected).
    {
        int selCount = 0;
        {
            const juce::ScopedLock sl(processor.noteLock);
            for (const auto& n : processor.notes)
                if (n.selected) ++selCount;
        }
        if (selCount >= 3)
        {
            const juce::Rectangle<int> chip(getWidth() - 104, topOffset + 8, 96, 20);
            g.setColour(juce::Colour(0xcc14181e));
            g.fillRoundedRectangle(chip.toFloat(), 10.0f);
            g.setColour(juce::Colour(0xff2a3340));
            g.drawRoundedRectangle(chip.toFloat(), 10.0f, 1.0f);
            g.setColour(juce::Colours::white);
            g.setFont(getModernFont(11.0f, juce::Font::bold));
            g.drawText(juce::String(selCount) + " notes", chip, juce::Justification::centred, false);
        }
    }

    // 2. Draw Piano Keys
    {
        juce::Graphics::ScopedSaveState state(g);
        g.reduceClipRegion(0, topOffset, keysWidth, getHeight() - topOffset - bottomOffset);
        g.addTransform(juce::AffineTransform::translation(0, (float)topOffset - viewY));

        for (int i = visibleStartKey - 1; i <= visibleEndKey + 1; ++i) {
            if (i < 0 || i > 127) continue;
            
            int note = 127 - i;
            float y = i * keyHeight;
            bool isBlack = isBlackMidiKey(note);
            
            juce::Rectangle<float> keyRect(0.0f, y, (float)keysWidth, keyHeight);

            // Playing-note key lamp: faint accent tint on keys whose note is
            // currently sounding.
            {
                bool keyPlaying = false;
                {
                    const juce::ScopedLock sl(processor.noteLock);
                    for (const auto& n : processor.notes)
                        if (n.isPlaying && n.midiNote == note) { keyPlaying = true; break; }
                }
                if (keyPlaying)
                {
                    g.setColour(getThemeAccentColour().withAlpha(0.16f));
                    g.fillRect(keyRect);
                }
            }
            
            // Theme-aware key colors. The scale highlight NEVER touches the
            // keys — they always keep their normal white/black look.
            g.setColour(getThemeKeyColour(isBlack));
            g.fillRect(keyRect);
            
            // Subtle border between keys
            g.setColour(getThemeBackgroundColour().darker(0.15f));
            g.drawLine(0.0f, y + keyHeight, (float)keysWidth, y + keyHeight, 1.0f);
            
            if (keyHeight >= 10.0f) {
                g.setColour(getNoteTextColour());
                g.setFont(getModernFont(juce::jmin(13.0f, keyHeight * 0.8f),
                                        processor.pianoRollNoteTextBold.load() ? juce::Font::bold : juce::Font::plain));
                g.drawText(getNoteName(note), 0, (int)y, keysWidth, (int)keyHeight, juce::Justification::centred, false);
            }
        }
        
        // Right border of keys
        g.setColour(juce::Colour(0xff000000));
        g.drawLine((float)keysWidth - 1.0f, visibleStartKey * keyHeight, (float)keysWidth - 1.0f, (visibleEndKey + 1) * keyHeight, 1.0f);
    }

    // 3. Draw Ruler
    {
        juce::Graphics::ScopedSaveState state(g);
        g.reduceClipRegion(keysWidth, toolbarHeight, getWidth() - keysWidth, rulerHeight);
        g.addTransform(juce::AffineTransform::translation((float)keysWidth - viewX, (float)toolbarHeight));

        juce::ColourGradient rulerGrad(getThemeToolbarColour(), viewX, 0.0f,
                                       getThemeToolbarColour(), viewX, (float)rulerHeight, false);
        g.setGradientFill(rulerGrad);
        g.fillRect(viewX, 0.0f, (float)getWidth(), (float)rulerHeight);

        // Diagonal shimmer: faint repeating diagonal lines across the ruler.
        {
            g.setColour(juce::Colours::white.withAlpha(0.030f));
            for (float sx = viewX - (float)rulerHeight; sx < viewX + (float)getWidth() + (float)rulerHeight; sx += 16.0f)
                g.drawLine(sx, (float)rulerHeight, sx + (float)rulerHeight, 0.0f, 1.0f);
        }
        
        g.setColour(getThemeGridLineColour(0));
        g.drawLine(viewX, (float)rulerHeight - 1.0f, viewX + getWidth(), (float)rulerHeight - 1.0f, 0.85f);
        
        float snapStartBeat = std::floor(visibleStartBeat / 1.0f) * 1.0f;

        // Ruler numbers: measures (only when bars are wide enough that the
        // numbers never overlap); beat numbers once there is more room; 16th
        // sub-beat numbers only when zoomed in far enough.
        const bool showMeasureNumbers = pixelsPerBeat * 4.0f >= 36.0f;
        const bool showBeatNumbers = pixelsPerBeat >= 40.0f;
        const bool showSubBeatNumbers = pixelsPerBeat >= 120.0f;

        for (float beat = snapStartBeat; beat <= visibleEndBeat; beat += 0.25f) {
            // Snap to the pixel grid (half-pixel offset) so 1px lines render
            // crisp instead of anti-aliased across two pixels.
            const float x = std::floor(beat * pixelsPerBeat) + 0.5f;
            if (isBeatMultiple(beat, 4.0f)) { 
                g.setColour(juce::Colour(0xffc9d3df));
                g.setFont(getModernFont(11.5f, juce::Font::bold));
                if (showMeasureNumbers)
                    g.drawText(juce::String((int)(beat / 4) + 1), (int)x - 44, 0, 40, rulerHeight, juce::Justification::centredRight);
                g.drawLine(x, rulerHeight - 6.0f, x, (float)rulerHeight);
                // Measure bead: tiny dot under the number as secondary orientation.
                if (pixelsPerBeat * 4.0f >= 12.0f)
                {
                    g.setColour(juce::Colours::white.withAlpha(0.55f));
                    g.fillEllipse(x - 1.5f, rulerHeight - 10.5f, 3.0f, 3.0f);
                }
            } else if (isBeatMultiple(beat, 1.0f)) { 
                g.setColour(juce::Colour(0xff6d7a8a));
                g.drawLine(x, rulerHeight - 5.0f, x, (float)rulerHeight);
                if (showBeatNumbers) {
                    g.setColour(juce::Colour(0xff8fa0b4));
                    g.setFont(getModernFont(10.0f));
                    g.drawText(juce::String((int)beat + 1), (int)x + 4, 0, 30, rulerHeight, juce::Justification::centredLeft);
                }
            } else {
                // 16th sub-beat: small tick always; number only when zoomed in
                g.setColour(juce::Colour(0xff4a5664));
                g.drawLine(x, rulerHeight - 4.0f, x, (float)rulerHeight);
                if (showSubBeatNumbers) {
                    g.setColour(juce::Colour(0xff6d7a8a));
                    g.setFont(getModernFont(8.0f));
                    g.drawText(juce::String((int)(beat * 4.0f) % 16 + 1), (int)x + 3, 0, 24, rulerHeight, juce::Justification::centredLeft);
                }
            }
        }

        if (processor.isLooping.load()) {
            float loopStart = processor.loopStartBeat.load();
            float loopEnd = processor.loopEndBeat.load();
            if (loopEnd > loopStart) {
                float sx = loopStart * pixelsPerBeat;
                float ex = loopEnd * pixelsPerBeat;

                // Dim the ruler OUTSIDE the loop (same language as the grid
                // and velocity lane) instead of painting a solid bar over the
                // ruler, so the numbers are never covered.
                g.setColour(juce::Colour(0x5a000000));
                g.fillRect(0.0f, 0.0f, juce::jmax(0.0f, sx), (float)rulerHeight);
                g.fillRect(ex, 0.0f, juce::jmax(0.0f, viewX + (float)getWidth() - ex), (float)rulerHeight);

                // Green boundary lines at the loop edges.
                g.setColour(getThemeAccentColour().withAlpha(0.6f));
                g.drawLine(sx, 0.0f, sx, (float)rulerHeight, 1.0f);
                g.drawLine(ex, 0.0f, ex, (float)rulerHeight, 1.0f);

                // Left marker (dark green box with left-pointing grey arrow)
                juce::Rectangle<float> leftMarker(sx, 0.0f, 13.0f, 13.0f);
                juce::Path pLeft;
                pLeft.addTriangle(sx + 8.0f, 3.5f, sx + 8.0f, 9.5f, sx + 3.5f, 6.5f);
                g.setColour(juce::Colour(0xff6c7383));
                g.fillPath(pLeft);

                // Right marker (right-pointing grey arrow)
                juce::Path pRight;
                pRight.addTriangle(ex - 8.0f, 3.5f, ex - 8.0f, 9.5f, ex - 3.5f, 6.5f);
                g.setColour(juce::Colour(0xff6c7383));
                g.fillPath(pRight);

                // End flag (green downward pentagon with number)
                juce::Path endFlag;
                endFlag.addRectangle(ex - 6.0f, 13.0f, 12.0f, 7.0f);
                endFlag.addTriangle(ex - 6.0f, 20.0f, ex + 6.0f, 20.0f, ex, 24.0f);
                g.setColour(juce::Colour(0xff15803d));
                g.fillPath(endFlag);
                g.setColour(juce::Colours::white);
                g.setFont(getModernFont(10.0f, juce::Font::bold));
                g.drawText(juce::String(std::round(loopEnd / 4 + 1)), juce::Rectangle<int>((int)ex - 6, 11, 12, 10), juce::Justification::centred, false);
            }
        }

        float currentBeat = processor.currentPlayheadBeat.load();
        if (currentBeat >= visibleStartBeat && currentBeat <= visibleEndBeat) {
            float playheadX = currentBeat * pixelsPerBeat;
            g.setColour(getThemeAccentColour());
            juce::Path p;
            p.addTriangle(playheadX - 5.0f, 0.0f, playheadX + 5.0f, 0.0f, playheadX, 7.0f); 
            g.fillPath(p);
        }
    }

    // 4. Fixed Top-Left Corner
    juce::ColourGradient cornerGrad(getThemeToolbarColour(), 0.0f, (float)toolbarHeight,
                                    getThemeToolbarColour(), 0.0f, (float)topOffset, false);
    g.setGradientFill(cornerGrad);
    g.fillRect(0, toolbarHeight, keysWidth, rulerHeight);
    g.setColour(getThemeGridLineColour(0));
    g.drawLine(0.0f, (float)topOffset - 1.0f, (float)keysWidth, (float)topOffset - 1.0f, 0.85f);
    g.drawLine((float)keysWidth, (float)toolbarHeight, (float)keysWidth, (float)topOffset, 0.85f);

    // 5. Toolbar
    juce::ColourGradient toolbarGrad(getThemeToolbarColour(), 0.0f, 0.0f,
                                     getThemeToolbarColour(), 0.0f, (float)toolbarHeight, false);
    g.setGradientFill(toolbarGrad);
    g.fillRect(0, 0, getWidth(), toolbarHeight);
    g.setColour(getThemeGridLineColour(0));
    g.drawLine(0.0f, (float)toolbarHeight - 1.0f, (float)getWidth(), (float)toolbarHeight - 1.0f, 0.85f);

    auto mPos = getMouseXYRelative();

    // Theme-driven toolbar text: colour override (empty = per-state default)
    // and bold style, applied to every toolbar button label and icon.
    const juce::Colour tbText = processor.pianoRollToolbarTextColour.load() != 0
                                    ? getToolbarTextColour()
                                    : juce::Colour();
    const bool tbBold = processor.pianoRollToolbarTextBold.load();

    drawToolbarButton(g, drawButtonRect, "Draw", currentTool == DrawTool, juce::Colour(blueAccent), false, mPos, 1, tbText, tbBold);
    drawToolbarButton(g, selectButtonRect, "Select", currentTool == SelectTool, juce::Colour(blueAccent), false, mPos, 2, tbText, tbBold);

    // Group separators sit between the logical groups; positions come from
    // the laid-out button rects so they always stay aligned with the buttons.
    drawToolbarSeparator(g, (float)(selectButtonRect.getRight() + 6), toolbarHeight);
    drawToolbarButton(g, gridButtonRect, "Grid " + gridNames[currentGridDivisorIndex], false, juce::Colour(0xff64748b), true, mPos, 4, tbText, tbBold);

    drawToolbarButton(g, velButtonRect, "Vel", showVelocityLane, getThemeAccentColour(), false, mPos, 3, tbText, tbBold);

    drawToolbarSeparator(g, (float)(velButtonRect.getRight() + 6), toolbarHeight);
    drawToolbarButton(g, dragMidiButtonRect, "Drag MIDI", false, juce::Colour(blueAccent), true, mPos, 0, tbText, tbBold);

    drawToolbarSeparator(g, (float)(dragMidiButtonRect.getRight() + 6), toolbarHeight);
    drawToolbarButton(g, pitchButtonRect, "Pitch", showPitchEnvelopes, getThemeAccentColour(), false, mPos, 5, tbText, tbBold);

    drawToolbarButton(g, pitchRangeButtonRect, "PB " + juce::String(processor.pitchBendRange.load()) + " st", false, getThemeAccentColour(), true, mPos, 0, tbText, tbBold);

    drawToolbarSeparator(g, (float)(pitchRangeButtonRect.getRight() + 6), toolbarHeight);

    // Right-anchored group (Legato / Scale / Shape / Theme / Panic) — laid
    // out in resized() so it never runs off-screen at narrow widths.
    juce::String lockTxt = scaleNoteNames[scaleRoot] + " " + scaleNames[scaleType];
    drawToolbarButton(g, scaleLockButtonRect, lockTxt, isScaleLockActive, getThemeAccentColour(), false, mPos, 0, tbText, tbBold);

    // LEGATO mode button: click cycles off -> mono -> rtn (see the
    // processor's legatoMode: 0 = off, 1 = mono, 2 = return).
    {
        const int lm = processor.legatoMode.load();
        juce::String legatoTxt;
        if (lm == 1)      legatoTxt = "Legato: mono";
        else if (lm == 2) legatoTxt = "Legato: rtn";
        else              legatoTxt = "Legato";
        drawToolbarButton(g, legatoButtonRect, legatoTxt, lm != 0, getThemeAccentColour(), false, mPos, 0, tbText, tbBold);
    }

    if (showPitchEnvelopes) {
        static const char* globalShapeNames[] = { "Linear", "Square", "Smooth", "Ease In", "Ease Out", "Sine" };
        const int gs = juce::jlimit(0, 5, processor.pitchShape.load());
        drawToolbarButton(g, shapeButtonRect, globalShapeNames[gs], false, getThemeAccentColour(), true, mPos, 0, tbText, tbBold);
    }

    drawToolbarButton(g, themeButtonRect, "Theme", false, getThemeAccentColour(), false, mPos, 6, tbText, tbBold);
    
    drawToolbarButton(g, panicButtonRect, "Panic!", false, juce::Colour(0xfff43f5e), false, mPos, 7, tbText, tbBold);

    // Hover tooltip for the toolbar button under the mouse
    if (hoveredToolbarHint.isNotEmpty()) {
        auto tipFont = getModernFont(12.0f);
        const float tw = juce::jmin((float)getWidth() - 24.0f, juce::GlyphArrangement::getStringWidth(tipFont, hoveredToolbarHint) + 16.0f);
        float tipX = (float)hoveredToolbarButtonRect.getCentreX() - tw * 0.5f;
        tipX = juce::jlimit(8.0f, (float)getWidth() - tw - 8.0f, tipX);
        juce::Rectangle<float> tipRect(tipX, (float)toolbarHeight + 5.0f, tw, 22.0f);
        g.setColour(getThemeBackgroundColour().darker(0.25f).withAlpha(0.95f));
        g.fillRoundedRectangle(tipRect, 4.0f);
        g.setColour(juce::Colour(0xffdbe4ee));
        g.setFont(tipFont);
        g.drawText(hoveredToolbarHint, tipRect, juce::Justification::centredLeft, false);
    }

    // 6. Draw Velocity Lane
    if (showVelocityLane) {
        int velY = getHeight() - velocityLaneHeight;
        juce::Graphics::ScopedSaveState state(g);
        
        const bool customBg = processor.pianoRollGridBgColour.load() != 0;
        juce::ColourGradient laneGrad(getThemeBackgroundColour().brighter(customBg ? 0.10f : 0.32f), (float)keysWidth, (float)velY,
                                      getThemeBackgroundColour().brighter(customBg ? 0.06f : 0.24f), (float)keysWidth, (float)getHeight(), false);
        g.setGradientFill(laneGrad);
        g.fillRect(keysWidth, velY, getWidth() - keysWidth, velocityLaneHeight);
        
        g.setColour(getThemeGridLineColour(0));
        g.drawLine(0.0f, (float)velY, (float)getWidth(), (float)velY, 1.2f);
        // Draggable-divider grip dots, centred above the lane's top edge.
        {
            const float gx = keysWidth + (getWidth() - keysWidth) * 0.5f;
            g.setColour(juce::Colour(0x66ffffff));
            for (int d = -1; d <= 1; ++d)
                g.fillEllipse(gx + (float)d * 10.0f - 1.2f, (float)velY - 4.2f, 2.4f, 2.4f);
        }
        
        g.setColour(getThemeGridColour(true));
        g.fillRect(0, velY, keysWidth, velocityLaneHeight);
        g.setColour(juce::Colour(0xffb8c2cf).withAlpha(0.86f));
        g.setFont(getModernFont(13.0f, juce::Font::bold));
        g.drawText("VEL", 0, velY, keysWidth, velocityLaneHeight, juce::Justification::centred, false);
        
        g.reduceClipRegion(keysWidth, velY, getWidth() - keysWidth, velocityLaneHeight);
        g.addTransform(juce::AffineTransform::translation((float)keysWidth - viewX, (float)velY));
        
        float currentSnap = getCurrentGridSnap();
        float snapStartBeat = std::floor(visibleStartBeat / currentSnap) * currentSnap;
        const float subBeatMult = processor.pianoRollGridSubBeatThickness.load();
        const float halfBeatMult = processor.pianoRollGridHalfBeatThickness.load();
        const float beatMult = processor.pianoRollGridBeatThickness.load();
        const float barMult = processor.pianoRollGridBarThickness.load();

        // Same adaptive level-of-detail as the main grid (see above).
        const float ppb = pixelsPerBeat;
        const float subBeatLod = juce::jlimit(0.0f, 1.0f, (ppb - 5.0f) / 7.0f);
        const float halfBeatLod = juce::jlimit(0.0f, 1.0f, (ppb - 9.0f) / 9.0f);
        const float beatLod = juce::jlimit(0.65f, 1.0f, ppb / 12.0f);
        const float barLod = juce::jlimit(0.80f, 1.0f, ppb / 10.0f);

        for (float beat = snapStartBeat; beat <= visibleEndBeat; beat += currentSnap) {
            // Snap to the pixel grid (half-pixel offset) so 1px lines render
            // crisp instead of anti-aliased across two pixels.
            const float x = std::floor(beat * pixelsPerBeat) + 0.5f;
            
            bool isBar = isBeatMultiple(beat, 4.0f);
            bool isBeat = isBeatMultiple(beat, 1.0f);
            bool isHalfBeat = ! isBeat && isBeatMultiple(beat, 0.5f);
            
            if (isBar) {
                const float a = juce::jlimit(0.0f, 1.0f, 0.6f * gridOpacityMultiplier * barLod);
                if (a < 0.02f) continue;
                g.setColour(getThemeGridLineColour(2).withAlpha(a));
                g.drawLine(x, 0.0f, x, (float)velocityLaneHeight, 1.2f * barMult);
            } else if (isBeat) {
                const float a = juce::jlimit(0.0f, 1.0f, 0.42f * gridOpacityMultiplier * beatLod);
                if (a < 0.02f) continue;
                g.setColour(getThemeGridLineColour(1).withAlpha(a));
                g.drawLine(x, 0.0f, x, (float)velocityLaneHeight, 0.8f * beatMult);
            } else if (isHalfBeat) {
                const float a = juce::jlimit(0.0f, 1.0f, 0.36f * gridOpacityMultiplier * halfBeatLod);
                if (a < 0.02f) continue;
                g.setColour(getThemeGridLineColour(1).withAlpha(a));
                g.drawLine(x, 0.0f, x, (float)velocityLaneHeight, 0.65f * halfBeatMult);
            } else {
                const float a = juce::jlimit(0.0f, 1.0f, 0.3f * gridOpacityMultiplier * subBeatLod);
                if (a < 0.02f) continue;
                g.setColour(getThemeGridLineColour(0).withAlpha(a));
                g.drawLine(x, 0.0f, x, (float)velocityLaneHeight, 0.5f * subBeatMult);
            }
        }

        if (processor.isLooping.load()) {
            float loopStart = processor.loopStartBeat.load();
            float loopEnd = processor.loopEndBeat.load();
            if (loopEnd > loopStart) {
                g.setColour(juce::Colour(0x66000000)); // Darken outside loop
                g.fillRect(0.0f, 0.0f, loopStart * pixelsPerBeat, (float)velocityLaneHeight);
                g.fillRect(loopEnd * pixelsPerBeat, 0.0f, gridDrawX + gridDrawW, (float)velocityLaneHeight);
                
                g.setColour(juce::Colour(0xaa60a5fa));
                g.drawLine(loopStart * pixelsPerBeat, 0.0f, loopStart * pixelsPerBeat, (float)velocityLaneHeight, 1.0f);
                g.drawLine(loopEnd * pixelsPerBeat, 0.0f, loopEnd * pixelsPerBeat, (float)velocityLaneHeight, 1.0f);
            }
        }
        
        for (const auto& note : localNotes) {
            if (note.startBeat > visibleEndBeat || (note.startBeat + note.lengthBeats) < visibleStartBeat) continue;
            
            float x = note.startBeat * pixelsPerBeat;
            
            float h = juce::jmax(3.0f, (note.velocity / 127.0f) * (velocityLaneHeight - 16.0f));
            float y = velocityLaneHeight - h - 8.0f;
            
            // Bar width follows the note length (clamped so short notes keep a
            // visible, grabbable target) — same formula as the mouse hit test.
            float barW = juce::jlimit(4.0f, 12.0f, note.lengthBeats * pixelsPerBeat * 0.28f);
            
            // Uniform highlight: every note uses the theme accent colour.
            juce::Colour baseColour = getNoteColour(note, getNoteBaseColour(), noteContrast);
            
            // Velocity bar body: thicker filled bar (was a 1.5px stem).
            juce::Rectangle<float> barRect(x - barW * 0.5f, y, barW, h);
            
            // Selection glow: soft white halo around the whole bar.
            if (note.selected)
            {
                g.setColour(juce::Colours::white.withAlpha(0.30f));
                g.fillRoundedRectangle(barRect.expanded(1.6f), 2.5f);
            }
            
            // Bar fill: accent colour, slightly brighter when selected.
            g.setColour(baseColour.brighter(note.selected ? 0.12f : 0.0f));
            g.fillRoundedRectangle(barRect, 1.5f);
            
            // Depth shading: darker strip on the left edge of the bar.
            g.setColour(juce::Colour(0x2e000000));
            g.fillRoundedRectangle(barRect.withWidth(barW * 0.30f), 1.5f);
            
            // Lollipop head caps the top of the bar (bright when selected).
            float radius = note.selected ? 4.5f : 3.5f;
            g.setColour(note.selected ? juce::Colours::white : baseColour.brighter(0.15f));
            g.fillEllipse(x - radius, y - radius, radius * 2.0f, radius * 2.0f);
            if (!note.selected)
            {
                g.setColour(juce::Colour(0xff12151a)); // inner shadow/border ring for depth
                g.drawEllipse(x - radius + 0.5f, y - radius + 0.5f, radius * 2.0f - 1.0f, radius * 2.0f - 1.0f, 1.0f);
            }
        }
    }
    
    if (showThemePanel) {
        // Clip everything to the panel: nothing (labels, swatches, rows) can
        // ever draw outside its bounds or cover other UI.
        juce::Graphics::ScopedSaveState themeClip(g);
        g.reduceClipRegion(themePanelRect);

        g.setColour(juce::Colour(0xff181a21).withAlpha(0.95f));
        g.fillRoundedRectangle(themePanelRect.toFloat(), 12.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(themePanelRect.toFloat(), 12.0f, 1.5f);
        
        g.setColour(juce::Colours::white);
        g.setFont(getModernFont(16.0f, juce::Font::bold));
        g.drawText("THEME TWEAKS", themePanelRect.withHeight(40).translated(0, -themePanelScrollY), juce::Justification::centred);
        
        g.setColour(juce::Colour(0xff3c4052));
        g.drawLine((float)themePanelRect.getX() + 20, (float)themePanelRect.getY() + 40 - themePanelScrollY,
                   (float)themePanelRect.getRight() - 20, (float)themePanelRect.getY() + 40 - themePanelScrollY, 1.0f);
        
        g.setColour(juce::Colour(0xff94a3b8));
        g.setFont(getModernFont(12.0f));
        g.drawText("Theme Color", themeCombo.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Font", fontTypefaceCombo.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Pitch Node Size", pitchNodeSizeSlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Pitch Line Thickness", pitchLineThicknessSlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Pitch Line Contrast", pitchLineContrastSlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Grid Opacity", gridOpacitySlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Note Corner Radius", noteCornerRadiusSlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Playhead Thickness", playheadThicknessSlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Note Name Size", noteNameFontSizeSlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Note Contrast", noteContrastSlider.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Note Color", noteColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);

        // Swatch: shows the current note colour (theme accent when no override).
        g.setColour(getNoteBaseColour());
        g.fillRoundedRectangle(noteColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(noteColourSwatchRect.toFloat(), 4.0f, 1.0f);

        // Reset button: back to the theme accent colour.
        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(noteColourResetRect.toFloat(), 4.0f);
        g.setColour(noteColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", noteColourResetRect, juce::Justification::centred);

        g.drawText("Pitch Line Color", pitchLineColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);
        g.setColour(getPitchLineBaseColour());
        g.fillRoundedRectangle(pitchLineColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(pitchLineColourSwatchRect.toFloat(), 4.0f, 1.0f);

        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(pitchLineColourResetRect.toFloat(), 4.0f);
        g.setColour(pitchLineColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", pitchLineColourResetRect, juce::Justification::centred);

        g.drawText("Grid Bg Color", gridBgColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);
        g.setColour(getThemeBackgroundColour());
        g.fillRoundedRectangle(gridBgColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(gridBgColourSwatchRect.toFloat(), 4.0f, 1.0f);

        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(gridBgColourResetRect.toFloat(), 4.0f);
        g.setColour(gridBgColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", gridBgColourResetRect, juce::Justification::centred);

        g.drawText("Grid Line Color", gridLineColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);
        g.setColour(getThemeGridLineColour(2));
        g.fillRoundedRectangle(gridLineColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(gridLineColourSwatchRect.toFloat(), 4.0f, 1.0f);

        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(gridLineColourResetRect.toFloat(), 4.0f);
        g.setColour(gridLineColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", gridLineColourResetRect, juce::Justification::centred);

        // Per-type grid line thickness: four mini-sliders in two rows
        // (Sub | Half on top, Beat | Bar below).
        g.setFont(getModernFont(11.0f));
        g.drawText("Sub", gridSubBeatThicknessSlider.getBounds().translated(0, -18), juce::Justification::centred);
        g.drawText("Half", gridHalfBeatThicknessSlider.getBounds().translated(0, -18), juce::Justification::centred);
        g.drawText("Beat", gridBeatThicknessSlider.getBounds().translated(0, -18), juce::Justification::centred);
        g.drawText("Bar", gridBarThicknessSlider.getBounds().translated(0, -18), juce::Justification::centred);
        g.setFont(getModernFont(12.0f));

        // Note-name text row: bold toggle (B button) + colour swatch + Reset.
        g.drawText("Note Text", noteTextColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);
        g.setColour(getNoteTextColour());
        g.fillRoundedRectangle(noteTextColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(noteTextColourSwatchRect.toFloat(), 4.0f, 1.0f);
        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(noteTextColourResetRect.toFloat(), 4.0f);
        g.setColour(noteTextColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", noteTextColourResetRect, juce::Justification::centred);

        // Toolbar text row: bold toggle (B button) + colour swatch + Reset.
        g.drawText("Toolbar Text", toolbarTextColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);
        g.setColour(getToolbarTextColour());
        g.fillRoundedRectangle(toolbarTextColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(toolbarTextColourSwatchRect.toFloat(), 4.0f, 1.0f);
        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(toolbarTextColourResetRect.toFloat(), 4.0f);
        g.setColour(toolbarTextColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", toolbarTextColourResetRect, juce::Justification::centred);

        // Note-name text inside the notes: bold toggle (B) + swatch + Reset.
        g.drawText("Note Name", noteNameColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);
        g.setColour(getNoteNameColour());
        g.fillRoundedRectangle(noteNameColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(noteNameColourSwatchRect.toFloat(), 4.0f, 1.0f);
        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(noteNameColourResetRect.toFloat(), 4.0f);
        g.setColour(noteNameColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", noteNameColourResetRect, juce::Justification::centred);

        // Razor selection colour row.
        g.drawText("Razor Select", razorColourSwatchRect.translated(0, -18), juce::Justification::bottomLeft);
        g.setColour(juce::Colour(processor.pianoRollRazorColour.load()));
        g.fillRoundedRectangle(razorColourSwatchRect.toFloat(), 4.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(razorColourSwatchRect.toFloat(), 4.0f, 1.0f);
        g.setColour(juce::Colour(0xff12151a));
        g.fillRoundedRectangle(razorColourResetRect.toFloat(), 4.0f);
        g.setColour(razorColourResetRect.contains(mPos) ? juce::Colours::white : juce::Colour(0xff94a3b8));
        g.drawText("Reset", razorColourResetRect, juce::Justification::centred);

        // "More content" hint when the panel is scrolled and rows overflow.
        if (themePanelScrollY > 0)
        {
            g.setColour(juce::Colour(0xff2b333d));
            g.fillRoundedRectangle(themePanelRect.getX() + 14, themePanelRect.getY() + 8, 12, 3, 1.5f);
        }
    }

    if (showPbSettingsPanel) {
        g.setColour(juce::Colour(0xff181a21).withAlpha(0.95f));
        g.fillRoundedRectangle(pbSettingsPanelRect.toFloat(), 12.0f);
        g.setColour(juce::Colour(0xff2a303a));
        g.drawRoundedRectangle(pbSettingsPanelRect.toFloat(), 12.0f, 1.5f);

        g.setColour(juce::Colours::white);
        g.setFont(getModernFont(16.0f, juce::Font::bold));
        g.drawText("PITCH BEND", pbSettingsPanelRect.withHeight(40), juce::Justification::centred);

        g.setColour(juce::Colour(0xff3c4052));
        g.drawLine((float)pbSettingsPanelRect.getX() + 20, (float)pbSettingsPanelRect.getY() + 40,
                   (float)pbSettingsPanelRect.getRight() - 20, (float)pbSettingsPanelRect.getY() + 40, 1.0f);

        g.setColour(juce::Colour(0xff94a3b8));
        g.setFont(getModernFont(12.0f));
        g.drawText("Bend Range", pbRangeCombo.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Curve Shape", pbShapeCombo.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Bend Resolution", pbResolutionCombo.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Loop preview", pitchPreviewToggle.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.drawText("Bend Mode", pbModeCombo.getBounds().translated(0, -18), juce::Justification::bottomLeft);
        g.setFont(getModernFont(11.0f));
        g.setColour(juce::Colour(0xff6b7280));
        g.drawText("Delivery floored at 0.5 ms — every setting reaches the target pitch.",
                   juce::Rectangle<int>(pbSettingsPanelRect.getX() + 16, pbModeCombo.getBounds().getBottom() + 8,
                                        pbSettingsPanelRect.getWidth() - 32, 30),
                   juce::Justification::topLeft);
    }
}

void PianoRollComponent::resized() {
    // Keep the file-local typeface in sync with the processor value (the
    // free getModernFont() helper can't see the processor).
    gPianoRollTypefaceIndex.store(processor.pianoRollFontTypefaceIndex.load());

    // --- Toolbar button layout: logical groups, adaptive to the window ---
    // (runs before the theme panel so the Theme button position is known.)
    const int bY = 6, bH = 24, gap = 8;
    int bx = 12;
    const auto place = [&] (juce::Rectangle<int>& r, int w) { r = { bx, bY, w, bH }; bx = r.getRight() + gap; };

    // Group 1: tools
    place(drawButtonRect, 72);
    place(selectButtonRect, 78);
    bx += 6;
    // Group 2: grid + velocity lane
    place(gridButtonRect, 85);
    place(velButtonRect, 70);
    bx += 6;
    // Group 3: MIDI drag-out
    place(dragMidiButtonRect, 95);
    bx += 6;
    // Group 4: pitch + bend range (Shape joins the right group when pitch on)
    place(pitchButtonRect, 65);
    place(pitchRangeButtonRect, 85);

    // Fixed group: Legato | Scale | [Shape] | Theme | Panic — placed right
    // after the left groups at STATIC positions, so resizing the window never
    // moves them (they no longer track the window's right edge).
    const bool pitchOn = processor.pianoRollShowPitchEnvelopes.load();
    bx += 6;
    place(legatoButtonRect, 85);
    if (pitchOn)
    {
        place(shapeButtonRect, 75);
        bx += 6;
    }
    place(scaleLockButtonRect, 120);
    bx += 6;
    place(themeButtonRect, 75);
    place(panicButtonRect, 65);

    // Panel height: clamped to the window so nothing is painted off-screen;
    // if all rows don't fit, the panel scrolls with the mouse wheel.
    const int rowH = themePanelRowH;
    const int panelH = juce::jmin(themePanelHeaderH + themePanelRowCount * rowH + 12,
                                  juce::jmax(220, getHeight() - themePanelRect.getY() - 12));
    // The theme panel drops down directly under the Theme button, centred on
    // it and clamped so it never runs off the window edges.
    themePanelRect = juce::Rectangle<int>(juce::jlimit(4, getWidth() - 250, themeButtonRect.getCentreX() - 120),
                                          toolbarHeight + 10, 240, panelH);
    themePanelScrollY = juce::jlimit(0,
                                     juce::jmax(0, themePanelHeaderH + themePanelRowCount * rowH - (panelH - 12)),
                                     themePanelScrollY);
    int y = themePanelRect.getY() + themePanelHeaderH - themePanelScrollY;
    int x = themePanelRect.getX() + 20;
    int w = themePanelRect.getWidth() - 40;
    
    themeCombo.setBounds(x, y, w, 24); y += rowH;
    fontTypefaceCombo.setBounds(x, y, w, 24); y += rowH;
    pitchNodeSizeSlider.setBounds(x, y, w, 24); y += rowH;
    pitchLineThicknessSlider.setBounds(x, y, w, 24); y += rowH;
    pitchLineContrastSlider.setBounds(x, y, w, 24); y += rowH;
    gridOpacitySlider.setBounds(x, y, w, 24); y += rowH;
    noteCornerRadiusSlider.setBounds(x, y, w, 24); y += rowH;
    playheadThicknessSlider.setBounds(x, y, w, 24); y += rowH;
    noteContrastSlider.setBounds(x, y, w, 24); y += rowH;

    // Note colour row: swatch (opens the colour selector) + Reset button.
    noteColourSwatchRect = juce::Rectangle<int>(x, y, w - 70, 16);
    noteColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Pitch line colour row.
    pitchLineColourSwatchRect = juce::Rectangle<int>(x, y, w - 70, 16);
    pitchLineColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Grid background colour row.
    gridBgColourSwatchRect = juce::Rectangle<int>(x, y, w - 70, 16);
    gridBgColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Grid line colour row.
    gridLineColourSwatchRect = juce::Rectangle<int>(x, y, w - 70, 16);
    gridLineColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Grid line thickness: four mini-sliders in two rows
    // (Sub | Half on top, Beat | Bar below).
    const int miniGap = 8;
    const int miniW = (w - miniGap) / 2;
    gridSubBeatThicknessSlider.setBounds(x, y, miniW, 24);
    gridHalfBeatThicknessSlider.setBounds(x + miniW + miniGap, y, miniW, 24);
    y += rowH;
    gridBeatThicknessSlider.setBounds(x, y, miniW, 24);
    gridBarThicknessSlider.setBounds(x + miniW + miniGap, y, miniW, 24);
    y += rowH;

    // Note-name text row: bold toggle (B) + colour swatch + Reset.
    noteTextBoldButton.setBounds(x, y, 26, 16);
    noteTextColourSwatchRect = juce::Rectangle<int>(x + 34, y, w - 34 - 62 - 6, 16);
    noteTextColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Toolbar text row: bold toggle (B) + colour swatch + Reset.
    toolbarTextBoldButton.setBounds(x, y, 26, 16);
    toolbarTextColourSwatchRect = juce::Rectangle<int>(x + 34, y, w - 34 - 62 - 6, 16);
    toolbarTextColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Note-name text inside the notes: show toggle (eye) + bold (B) +
    // colour swatch + Reset.
    noteNameShowButton.setBounds(x, y, 26, 16);
    noteNameBoldButton.setBounds(x + 32, y, 26, 16);
    noteNameColourSwatchRect = juce::Rectangle<int>(x + 64, y, w - 64 - 62 - 6, 16);
    noteNameColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Razor selection colour row.
    razorColourSwatchRect = juce::Rectangle<int>(x, y, w - 70, 16);
    razorColourResetRect = juce::Rectangle<int>(x + w - 62, y, 62, 16);
    y += rowH;

    // Note name font size slider (label drawn in paint() above it).
    noteNameFontSizeSlider.setBounds(x, y, w, 16);
    y += rowH;

    // Ghost pitch lines row: toggle button + visibility slider.
    ghostPitchLinesButton.setBounds(x, y, 128, 16);
    ghostPitchLinesOpacitySlider.setBounds(x + 134, y, w - 134, 16);
    y += rowH;

    // Pitch-bend settings panel — anchored directly under the PB range button.
    pbSettingsPanelRect = juce::Rectangle<int>(pitchRangeButtonRect.getX(), toolbarHeight + 10, 240, 300);
    int py = pbSettingsPanelRect.getY() + 55;
    int px = pbSettingsPanelRect.getX() + 20;
    int pw = pbSettingsPanelRect.getWidth() - 40;
    pbRangeCombo.setBounds(px, py, pw, 24); py += rowH;
    pbShapeCombo.setBounds(px, py, pw, 24); py += rowH;
    pbResolutionCombo.setBounds(px, py, pw, 24); py += rowH;
    pitchPreviewToggle.setBounds(px, py, pw, 24); py += rowH;
    pbModeCombo.setBounds(px, py, pw, 24);
}

void PianoRollComponent::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel)
{
    if (showThemePanel && themePanelRect.contains(e.x, e.y)) {
        // Scroll the theme tweaks panel when its rows overflow the window.
        const int viewH = themePanelRect.getHeight() - 12;
        const int maxScroll = juce::jmax(0, themePanelHeaderH + themePanelRowCount * themePanelRowH - viewH);
        if (maxScroll > 0)
        {
            const int step = 30;
            themePanelScrollY = juce::jlimit(0, maxScroll,
                                             themePanelScrollY + (wheel.deltaY > 0 ? -step : step));
            resized();
            repaint();
        }
        return;
    }
    
    int topOffset = rulerHeight + toolbarHeight;

    if (e.mods.isCtrlDown() && e.mods.isShiftDown()) 
    {
        if (e.y > topOffset) 
        {
            float pitchAtCursor = (e.y - topOffset + viewY) / keyHeight;
            // Multiplicative vertical zoom (~x1.5 per notch) — faster than
            // the old fixed +15 px step and constant-feeling at all zoom levels
            keyHeight *= (1.0f + wheel.deltaY * 0.5f);
            keyHeight = juce::jlimit(4.0f, 80.0f, keyHeight); 
            viewY = pitchAtCursor * keyHeight - (e.y - topOffset);
            viewY = juce::jlimit(0.0f, (float)(numKeys * keyHeight), viewY);
        }
    }
    else if (e.mods.isCtrlDown()) 
    {
        if (e.x > keysWidth) 
        {
            float beatAtCursor = (e.x - keysWidth + viewX) / pixelsPerBeat;
            // Multiplicative horizontal zoom (~x3.5 per notch) — noticeably
            // faster than the old fixed +30 px step, especially when zoomed in.
            // Animated: the targets lerp toward the current view in the timer.
            const float newPpb = juce::jlimit(10.0f, 400.0f,
                                              pixelsPerBeat * (1.0f + wheel.deltaY * 2.5f));
            const float newViewX = juce::jmax(0.0f, beatAtCursor * newPpb - (e.x - keysWidth));
            animateViewTo(newViewX, viewY, newPpb);
        }
    }
    else 
    {
        // Animated pan: smooth wheel scroll instead of instant jumps.
        animateViewTo(viewX - wheel.deltaX * 100.0f,
                      viewY - wheel.deltaY * 100.0f,
                      pixelsPerBeat);
    }
    markPersistentEditorStateChanged();
    repaint();
}

void PianoRollComponent::mouseMove (const juce::MouseEvent& e)
{
    int topOffset = rulerHeight + toolbarHeight;

    // Toolbar hover tooltip + hand cursor
    if (e.y < toolbarHeight) {
        const juce::String hint = getToolbarButtonHint(e.x, e.y);
        if (hint != hoveredToolbarHint) {
            hoveredToolbarHint = hint;
            hoveredToolbarButtonRect = {};
            if (drawButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = drawButtonRect;
            else if (selectButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = selectButtonRect;
            else if (gridButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = gridButtonRect;
            else if (velButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = velButtonRect;
            else if (dragMidiButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = dragMidiButtonRect;
            else if (pitchButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = pitchButtonRect;
            else if (pitchRangeButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = pitchRangeButtonRect;
            else if (showPitchEnvelopes && shapeButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = shapeButtonRect;
            else if (themeButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = themeButtonRect;
            else if (panicButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = panicButtonRect;
            else if (scaleLockButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = scaleLockButtonRect;
            else if (legatoButtonRect.contains(e.x, e.y)) hoveredToolbarButtonRect = legatoButtonRect;
            setMouseCursor(hint.isNotEmpty() ? juce::MouseCursor::PointingHandCursor : juce::MouseCursor::NormalCursor);
            repaint();
        }
        return;
    }

    if (hoveredToolbarHint.isNotEmpty()) {
        hoveredToolbarHint = {};
        hoveredToolbarButtonRect = {};
        setMouseCursor(juce::MouseCursor::NormalCursor);
        repaint();
    }

    // Velocity-lane divider: resize cursor while hovering the strip.
    if (showVelocityLane)
    {
        const int velYDiv = getHeight() - velocityLaneHeight;
        if (e.x >= keysWidth && e.y >= velYDiv - 4 && e.y <= velYDiv + 4)
        {
            setMouseCursor(juce::MouseCursor::UpDownResizeCursor);
            return;
        }
    }
    
    if (hasRazorSelection) {
        float rx = keysWidth + (razorStartBeat * pixelsPerBeat) - viewX;
        float rw = (razorEndBeat - razorStartBeat) * pixelsPerBeat;
        float ry = topOffset + ((127 - razorTopNote) * keyHeight) - viewY;
        float rh = (razorTopNote - razorBottomNote + 1) * keyHeight;
        juce::Rectangle<float> rRect(rx, ry, rw, rh);
        
        float tol = 6.0f;
        if ((std::abs(e.x - rRect.getX()) <= tol || std::abs(e.x - rRect.getRight()) <= tol) && e.y >= rRect.getY() && e.y <= rRect.getBottom()) {
            setMouseCursor(juce::MouseCursor::LeftRightResizeCursor);
            return;
        } else if ((std::abs(e.y - rRect.getY()) <= tol || std::abs(e.y - rRect.getBottom()) <= tol) && e.x >= rRect.getX() && e.x <= rRect.getRight()) {
            setMouseCursor(juce::MouseCursor::UpDownResizeCursor);
            return;
        }
    }
    
    if (e.y >= topOffset && e.x >= keysWidth) 
    {
        bool hoveringRightEdge = false;
        hoverHandleNoteIndex = -1;
        hoverHandleRightEdge = false;
        
        // Viewport cull: skip notes outside the visible beat/key range before
        // doing any rect math, so hover stays cheap on huge projects.
        const float cullStartBeat = juce::jmax(0.0f, viewX / pixelsPerBeat);
        const float cullEndBeat = (viewX + (float)getWidth()) / pixelsPerBeat;
        const int cullStartKey = juce::jmax(0, (int)(viewY / keyHeight));
        const int cullEndKey = juce::jmin(numKeys, (int)((viewY + (float)getHeight()) / keyHeight) + 1);
        const juce::ScopedLock sl (processor.noteLock);
        for (int i = (int)processor.notes.size() - 1; i >= 0; --i)
        {
            const auto& note = processor.notes[i];
            if (note.startBeat > cullEndBeat || (note.startBeat + note.lengthBeats) < cullStartBeat) continue;
            const int noteRow = 127 - note.midiNote;
            if (noteRow < cullStartKey || noteRow > cullEndKey) continue;
            auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);

            if (rect.contains(e.getPosition().toFloat()))
            {
                if (e.x > rect.getRight() - 10.0f) {
                    hoveringRightEdge = true;
                    // Note tail handle: remember the hovered note so paint()
                    // can draw a subtle resize grip on its right edge.
                    hoverHandleNoteIndex = i;
                    hoverHandleRightEdge = true;
                }
                break;
            }
        }
        
        if (hoveringRightEdge) {
            setMouseCursor(juce::MouseCursor::LeftRightResizeCursor);
        } else {
            setMouseCursor(juce::MouseCursor::NormalCursor);
        }

        int newGhostNoteIndex = -1;
        juce::Point<float> newGhostPoint { -1.0f, -1.0f };

        if (showPitchEnvelopes) {
            float bestLineScore = 20.0f; // pixel tolerance
            int range = processor.pitchBendRange.load();
            const int shape = processor.pitchShape.load();
            for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
                auto& note = processor.notes[i];
                if (i != editingPitchCurveNoteIndex) continue;
                auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
                float cy = rect.getCentreY();
                const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                
                if (e.x >= rect.getX() && e.x <= rect.getRight() && e.y >= cy - range * keyHeight && e.y <= cy + range * keyHeight) {
                    const float beatOffset = ((e.x - rect.getX()) / rect.getWidth()) * noteLength;
                    const float bendAtCursor = evaluatePitchBendAtBeat(note, beatOffset, shape);
                    const float curveY = cy - (juce::jlimit(-(float)range, (float)range, bendAtCursor) * keyHeight);
                    float score = std::abs((float)e.y - curveY);
                    if (rect.contains(e.getPosition().toFloat()))
                        score -= keyHeight;
                    if (score < bestLineScore) {
                        bestLineScore = score;
                        newGhostNoteIndex = i;
                        
                        float snapBeatOffset = beatOffset;
                        float snapBendY = (cy - e.y) / keyHeight;

                        const bool snapPitchPoint = !e.mods.isShiftDown();
                        if (snapPitchPoint) {
                            float globalBeat = note.startBeat + snapBeatOffset;
                            globalBeat = snapValueToStep(globalBeat, getCurrentGridSnap());
                            snapBeatOffset = globalBeat - note.startBeat;
                        }
                          
                        snapBeatOffset = juce::jlimit(0.0f, noteLength, snapBeatOffset);
                        if (snapPitchPoint) {
                            snapBendY = snapPitchBendToNoteCenter(snapBendY);
                            if (snapBendY != 0.0f)
                                snapBendY = quantizeToScale(note.midiNote, snapBendY);
                        }
                        snapBendY = juce::jlimit(-(float)processor.pitchBendRange.load(), (float)processor.pitchBendRange.load(), snapBendY);
                        
                        newGhostPoint = { snapBeatOffset, snapBendY };
                    }
                }
            }
        }

        if (newGhostNoteIndex != ghostPitchCurveNoteIndex || newGhostPoint != ghostPitchPoint) {
            int oldGhostNoteIndex = ghostPitchCurveNoteIndex;
            ghostPitchCurveNoteIndex = newGhostNoteIndex;
            ghostPitchPoint = newGhostPoint;
            if (oldGhostNoteIndex != -1) {
                if (oldGhostNoteIndex < processor.notes.size())
                    repaintPitchEditArea(processor.notes[oldGhostNoteIndex]);
            }
            if (newGhostNoteIndex != -1) {
                if (newGhostNoteIndex < processor.notes.size())
                    repaintPitchEditArea(processor.notes[newGhostNoteIndex]);
            }
        }

    } else {
        hoverHandleNoteIndex = -1;
        hoverHandleRightEdge = false;
        setMouseCursor(juce::MouseCursor::NormalCursor);
    }
}

void PianoRollComponent::mouseDoubleClick (const juce::MouseEvent& e)
{
    int topOffset = rulerHeight + toolbarHeight;

    // Double-click on the ruler: zoom to fit the whole arrangement.
    if (e.y < topOffset && e.x >= keysWidth)
    {
        float minBeat = 1e9f, maxBeat = -1e9f;
        {
            const juce::ScopedLock sl(processor.noteLock);
            for (const auto& n : processor.notes)
            {
                minBeat = std::min(minBeat, n.startBeat);
                maxBeat = std::max(maxBeat, n.startBeat + n.lengthBeats);
            }
        }
        if (minBeat > maxBeat) { minBeat = 0.0f; maxBeat = 16.0f; }
        const float span = juce::jmax(1.0f, maxBeat - minBeat);
        const float pad = 2.0f; // beats of padding on each side
        const float availW = (float)(getWidth() - keysWidth - 24);
        const float newPpb = juce::jlimit(10.0f, 400.0f, availW / (span + pad * 2.0f));
        const float newViewX = juce::jmax(0.0f, (minBeat - pad) * newPpb);
        animateViewTo(newViewX, viewY, newPpb);
        return;
    }

    if (e.x >= keysWidth && e.y >= topOffset) {
        const float cullStartBeat = juce::jmax(0.0f, viewX / pixelsPerBeat);
        const float cullEndBeat = (viewX + (float)getWidth()) / pixelsPerBeat;
        const int cullStartKey = juce::jmax(0, (int)(viewY / keyHeight));
        const int cullEndKey = juce::jmin(numKeys, (int)((viewY + (float)getHeight()) / keyHeight) + 1);
        const juce::ScopedLock sl (processor.noteLock);
        for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
            auto& note = processor.notes[i];
            if (note.startBeat > cullEndBeat || (note.startBeat + note.lengthBeats) < cullStartBeat) continue;
            const int noteRow = 127 - note.midiNote;
            if (noteRow < cullStartKey || noteRow > cullEndKey) continue;
            auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
            
            if (rect.contains(e.getPosition().toFloat())) {
                if (!showPitchEnvelopes) {
                    showPitchEnvelopes = true; // Enter pitch mode
                    markPersistentEditorStateChanged();
                } else {
                    if (editingPitchCurveNoteIndex == i) {
                        return;
                    }
                }
                
                if (processor.notes[i].pitchCurve.empty()) {
                    // Only the starting point by default — the user draws the
                    // rest of the curve themselves. The start point's shape is
                    // baked from the CURRENT global mode so the first segment
                    // keeps the shape it was drawn with.
                    processor.notes[i].pitchCurve.push_back({0.0f, 0.0f, 0.0f, bakedNodeShapeFor(processor)});
                    markPersistentEditorStateChanged();
                }
                
                for (int j = 0; j < (int)processor.notes.size(); ++j) {
                    processor.notes[j].selected = (j == i);
                }

                editingPitchCurveNoteIndex = i;
                editingPitchCurveNodeIndex = -1; editingPitchCurveTensionNodeIndex = -1;
                repaint();
                return;
            }
        }
    }

    if (hasRazorSelection && e.y >= topOffset && e.x >= keysWidth)
    {
        float rx = keysWidth + (razorStartBeat * pixelsPerBeat) - viewX;
        float rw = (razorEndBeat - razorStartBeat) * pixelsPerBeat;
        float ry = topOffset + ((127 - razorTopNote) * keyHeight) - viewY;
        float rh = (razorTopNote - razorBottomNote + 1) * keyHeight;
        juce::Rectangle<float> rRect(rx, ry, rw, rh);
        
        if (rRect.contains(e.getPosition().toFloat())) {
            hasRazorSelection = false;
            repaint();
            return;
        }
    }
}

void PianoRollComponent::mouseDown (const juce::MouseEvent& e)
{
    grabKeyboardFocus();
    
    if (showThemePanel && themePanelRect.contains(e.x, e.y)) {
        // Colour swatches: open the colour selector in a callout.
        if (noteColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(0, noteColourSwatchRect);
            return;
        }
        // Reset buttons: back to the theme accent colour.
        if (noteColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollNoteColour.store(0);
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        if (pitchLineColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(1, pitchLineColourSwatchRect);
            return;
        }
        if (pitchLineColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollPitchLineColour.store(0);
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        if (gridBgColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(2, gridBgColourSwatchRect);
            return;
        }
        if (gridBgColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollGridBgColour.store(0);
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        if (gridLineColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(3, gridLineColourSwatchRect);
            return;
        }
        if (gridLineColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollGridLineColour.store(0);
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        if (noteTextColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(4, noteTextColourSwatchRect);
            return;
        }
        if (noteTextColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollNoteTextColour.store(0);
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        if (toolbarTextColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(5, toolbarTextColourSwatchRect);
            return;
        }
        if (toolbarTextColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollToolbarTextColour.store(0);
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        if (noteNameColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(6, noteNameColourSwatchRect);
            return;
        }
        if (noteNameColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollNoteNameColour.store(0);
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        if (razorColourSwatchRect.contains(e.x, e.y))
        {
            launchColourPicker(7, razorColourSwatchRect);
            return;
        }
        if (razorColourResetRect.contains(e.x, e.y))
        {
            processor.pianoRollRazorColour.store(0xff5eead4); // default teal
            markPersistentEditorStateChanged();
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        return;
    }

    if (showPbSettingsPanel && pbSettingsPanelRect.contains(e.x, e.y)) {
        return;
    }
    
    undoStateSavedForDrag = false;
    lastDragPos = e.getPosition();

    if (e.y < toolbarHeight) {
        // Hit-test against the same button rects used by paint() so the
        // clickable area always matches what the user sees.
        if (drawButtonRect.contains(e.x, e.y)) currentTool = DrawTool;
        else if (selectButtonRect.contains(e.x, e.y)) currentTool = SelectTool;
        else if (gridButtonRect.contains(e.x, e.y)) {
            saveUndoState(); // grid changes are undoable
            currentGridDivisorIndex = (currentGridDivisorIndex + 1) % 6;
        }
        else if (velButtonRect.contains(e.x, e.y)) {
            showVelocityLane = !showVelocityLane;
        }
        else if (dragMidiButtonRect.contains(e.x, e.y)) {
            isDraggingMidiButton = true;
        }
        else if (pitchButtonRect.contains(e.x, e.y)) {
            showPitchEnvelopes = !showPitchEnvelopes;
            if (showPitchEnvelopes) {
                // Seed the start point for EVERY note up front — including
                // notes stacked on the same grid line — so none can be left
                // without its automatic reset-to-0 point.
                ensurePitchStartPoints();
                editingPitchCurveNoteIndex = -1;
                for (int i = 0; i < (int)processor.notes.size(); ++i) {
                    if (processor.notes[i].selected) {
                        editingPitchCurveNoteIndex = i;
                        break;
                    }
                }
            } else {
                editingPitchCurveNoteIndex = -1;
            }
            editingPitchCurveNodeIndex = -1; editingPitchCurveTensionNodeIndex = -1;
        }
        else if (pitchRangeButtonRect.contains(e.x, e.y)) {
            if (e.mods.isRightButtonDown()) {
                // Right-click: quick access to the bend-resolution menu.
                // "Maximum" = every sample, so extremely fast micro-bends are
                // fully reproduced (at the cost of higher MIDI throughput).
                const int micros = processor.pitchBendStepMicros.load();
                juce::PopupMenu m;
                m.setLookAndFeel(&webDAWMenuLAF());
                m.addSectionHeader("Pitch Bend Resolution");
                m.addItem(1, "Maximum (per-sample eval)", true, micros == 0);
                m.addItem(2, "Fine", true, micros == 250);
                m.addItem(3, "Balanced", true, micros == 500);
                m.addItem(4, "Economy", true, micros == 1000);
                m.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(this).withTargetScreenArea(localAreaToGlobal(pitchRangeButtonRect)),
                    [this](int result) {
                        int newMicros = 1000;
                        if (result == 1) newMicros = 0;
                        else if (result == 2) newMicros = 250;
                        else if (result == 3) newMicros = 500;
                        else if (result == 4) newMicros = 1000;
                        else return;

                        processor.pitchBendStepMicros.store(newMicros);
                        processor.updateHostDisplay();
                        markPersistentEditorStateChanged();
                        syncPbSettingsCombos();
                        repaint();
                    });
                return;
            }

            // Left-click: toggle the pitch-bend settings panel (mutually
            // exclusive with the theme panel).
            showPbSettingsPanel = !showPbSettingsPanel;
            if (showPbSettingsPanel) {
                showThemePanel = false;
                themeCombo.setVisible(false);
                pitchNodeSizeSlider.setVisible(false);
                pitchLineThicknessSlider.setVisible(false);
                pitchLineContrastSlider.setVisible(false);
                gridOpacitySlider.setVisible(false);
                noteCornerRadiusSlider.setVisible(false);
                playheadThicknessSlider.setVisible(false);
                noteContrastSlider.setVisible(false);
                ghostPitchLinesOpacitySlider.setVisible(false);
                noteNameFontSizeSlider.setVisible(false);
                syncPbSettingsCombos();
            }
            pbRangeCombo.setVisible(showPbSettingsPanel);
            pbShapeCombo.setVisible(showPbSettingsPanel);
            pbResolutionCombo.setVisible(showPbSettingsPanel);
            pitchPreviewToggle.setVisible(showPbSettingsPanel);
            pbModeCombo.setVisible(showPbSettingsPanel);
            repaint();
            return;
        }
        else if (showPitchEnvelopes && shapeButtonRect.contains(e.x, e.y)) {
            if (e.mods.isRightButtonDown()) {
                // Right-click: pick the global shape directly.
                juce::PopupMenu shapeMenu;
                shapeMenu.setLookAndFeel(&webDAWMenuLAF());
                shapeMenu.addItem(1, "Linear");
                shapeMenu.addItem(2, "Square");
                shapeMenu.addItem(3, "Smooth");
                shapeMenu.addItem(4, "Ease In");
                shapeMenu.addItem(5, "Ease Out");
                shapeMenu.addItem(6, "Sine");
                shapeMenu.showMenuAsync(juce::PopupMenu::Options()
                    .withTargetComponent(this)
                    .withTargetScreenArea(shapeButtonRect.translated(getScreenX(), getScreenY())),
                    [this] (int result)
                    {
                        if (result > 0)
                        {
                            processor.pitchShape.store(juce::jlimit(0, 5, result - 1));
                            processor.updateHostDisplay();
                            repaint();
                        }
                    });
            } else {
                processor.pitchShape.store((processor.pitchShape.load() + 1) % 6); // Linear -> Square -> Smooth -> Ease In -> Ease Out -> Sine
                processor.updateHostDisplay();
            }
        }
        else if (themeButtonRect.contains(e.x, e.y)) {
            showThemePanel = !showThemePanel;
            if (showThemePanel) {
                // Start scrolled to the top when re-opening the panel.
                themePanelScrollY = 0;
                // Close the pitch-bend panel so the two panels never overlap.
                showPbSettingsPanel = false;
                pbRangeCombo.setVisible(false);
                pbShapeCombo.setVisible(false);
                pbResolutionCombo.setVisible(false);
                pitchPreviewToggle.setVisible(false);
                pbModeCombo.setVisible(false);
            }
            themeCombo.setVisible(showThemePanel);
            fontTypefaceCombo.setVisible(showThemePanel);
            pitchNodeSizeSlider.setVisible(showThemePanel);
            pitchLineThicknessSlider.setVisible(showThemePanel);
            pitchLineContrastSlider.setVisible(showThemePanel);
            gridOpacitySlider.setVisible(showThemePanel);
            noteCornerRadiusSlider.setVisible(showThemePanel);
            playheadThicknessSlider.setVisible(showThemePanel);
            noteContrastSlider.setVisible(showThemePanel);
            gridSubBeatThicknessSlider.setVisible(showThemePanel);
            gridHalfBeatThicknessSlider.setVisible(showThemePanel);
            gridBeatThicknessSlider.setVisible(showThemePanel);
            gridBarThicknessSlider.setVisible(showThemePanel);
            noteTextBoldButton.setVisible(showThemePanel);
            toolbarTextBoldButton.setVisible(showThemePanel);
            noteNameBoldButton.setVisible(showThemePanel);
            noteNameShowButton.setVisible(showThemePanel);
            ghostPitchLinesButton.setVisible(showThemePanel);
            ghostPitchLinesOpacitySlider.setVisible(showThemePanel);
            noteNameFontSizeSlider.setVisible(showThemePanel);
            
            // update sliders to match current values before showing
            if (showThemePanel) {
                ghostPitchLinesButton.setToggleState(processor.pianoRollGhostPitchLines.load(),
                                                     juce::dontSendNotification);
                ghostPitchLinesOpacitySlider.setValue(processor.pianoRollGhostPitchLineOpacity.load(),
                                                      juce::dontSendNotification);
                noteNameFontSizeSlider.setValue(processor.pianoRollNoteNameFontSize.load(),
                                                juce::dontSendNotification);
            }
            
            repaint();
            return;
        }
        else if (panicButtonRect.contains(e.x, e.y)) {
            processor.triggerPanic();
            repaint();
            return;
        }
        else if (legatoButtonRect.contains(e.x, e.y)) {
            // Cycle the legato mode: off -> mono (previous note cut) -> rtn
            // (cut note retriggered when the top note ends) -> off.
            processor.legatoMode.store((processor.legatoMode.load() + 1) % 3);
            processor.updateHostDisplay();
            markPersistentEditorStateChanged();
            // Save synchronously (not just via the debounced timer flush) so
            // the chosen mode — including OFF — is never lost, even if the
            // DAW is closed right after clicking.
            processor.saveGlobalSettings();
            repaint();
            return;
        }
        else if (scaleLockButtonRect.contains(e.x, e.y)) {
            if (e.mods.isRightButtonDown()) {
                juce::PopupMenu m;
                m.setLookAndFeel(&webDAWMenuLAF());
                juce::PopupMenu rootMenu;
                rootMenu.setLookAndFeel(&webDAWMenuLAF());
                for (int i = 0; i < scaleNoteNames.size(); ++i) {
                    rootMenu.addItem(i + 1, scaleNoteNames[i], true, scaleRoot == i);
                }
                m.addSubMenu("Root Note", rootMenu);
                
                juce::PopupMenu typeMenu;
                typeMenu.setLookAndFeel(&webDAWMenuLAF());
                for (int i = 0; i < scaleNames.size(); ++i) {
                    typeMenu.addItem(100 + i, scaleNames[i], true, scaleType == i);
                }
                m.addSubMenu("Scale Type", typeMenu);

                m.addSeparator();

                // Snap ALREADY-DRAWN notes / pitch-bend nodes onto the scale.
                bool hasSelection = false;
                {
                    const juce::ScopedLock sl(processor.noteLock);
                    for (const auto& n : processor.notes)
                        if (n.selected) { hasSelection = true; break; }
                }
                m.addItem(200, "Snap Notes to Scale (selected)", hasSelection);
                m.addItem(201, "Snap Pitch Bends (selected notes)", hasSelection);
                m.addItem(202, "Snap Pitch Bends (all notes)", true);

                m.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(this).withTargetScreenArea(this->localAreaToGlobal(scaleLockButtonRect)),
                    [this](int result) {
                        if (result > 0 && result <= 12) {
                            scaleRoot = result - 1;
                            isScaleLockActive = true; // picking a scale highlights + locks it
                            markPersistentEditorStateChanged();
                            repaint();
                        } else if (result >= 100 && result < 200) {
                            scaleType = result - 100;
                            isScaleLockActive = true; // picking a scale highlights + locks it
                            markPersistentEditorStateChanged();
                            repaint();
                        } else if (result == 200 || result == 201 || result == 202) {
                            snapToScaleAction(result); // tune the already-drawn ones
                        }
                    });
                return;
            } else {
                isScaleLockActive = !isScaleLockActive;
            }
        }
        markPersistentEditorStateChanged();
        repaint();
        return;
    }

    if (e.mods.isAltDown() && e.mods.isRightButtonDown())
    {
        isRazorSelecting = true;
        hasRazorSelection = true;
        razorStartMousePos = e.getPosition();
        
        float snap = getCurrentGridSnap();
        float beat = screenToBeat(e.x);
        razorStartBeat = std::floor(beat / snap) * snap;
        razorEndBeat = razorStartBeat + snap;
        
        int note = screenToNote(e.y);
        razorTopNote = note;
        razorBottomNote = note;
        repaint();
        return;
    }
    // Alt + left-click on the LEFT or RIGHT edge of an existing razor
    // selection: time-stretch the notes INSIDE the selection (the region's
    // content scales with the dragged edge, e.g. drag a 2-bar region down to
    // 1 bar for double time). This must be checked BEFORE the pan shortcut
    // below, otherwise Alt+left-drag on an edge would just pan the view.
    if (hasRazorSelection && e.mods.isAltDown() && e.mods.isLeftButtonDown())
    {
        const int tOff = rulerHeight + toolbarHeight;
        const float rx = keysWidth + (razorStartBeat * pixelsPerBeat) - viewX;
        const float rw = (razorEndBeat - razorStartBeat) * pixelsPerBeat;
        const float ry = tOff + ((127 - razorTopNote) * keyHeight) - viewY;
        const float rh = (razorTopNote - razorBottomNote + 1) * keyHeight;
        const juce::Rectangle<float> rRect(rx, ry, rw, rh);
        const float tol = 6.0f;
        razorStretchEdge = 0;
        if (std::abs(e.x - rRect.getX()) <= tol && e.y >= rRect.getY() && e.y <= rRect.getBottom())
            razorStretchEdge = -1;
        else if (std::abs(e.x - rRect.getRight()) <= tol && e.y >= rRect.getY() && e.y <= rRect.getBottom())
            razorStretchEdge = 1;

        if (razorStretchEdge != 0)
        {
            isStretchingRazor = true;
            razorStartMousePos = e.getPosition();
            originalRazorStartBeat = razorStartBeat;
            originalRazorEndBeat = razorEndBeat;
            originalRazorBottomNote = razorBottomNote;
            originalRazorTopNote = razorTopNote;
            saveUndoState();
            razorDragOriginalNotes.clear();
            const juce::ScopedLock sl(processor.noteLock);
            for (auto& note : processor.notes)
            {
                if (note.startBeat < razorEndBeat && (note.startBeat + note.lengthBeats) > razorStartBeat &&
                    note.midiNote >= razorBottomNote && note.midiNote <= razorTopNote)
                    razorDragOriginalNotes.push_back(note);
            }
            repaint();
            return;
        }
        // Alt+left NOT on an edge: fall through to the pan shortcut below.
    }

    // Note under the cursor, shared by Alt-drag copy (below) and the pan
    // gate. Grid-area only: ruler, keys and velocity-lane clicks keep their
    // own handling, and Alt+drag there still pans.
    int clickedNoteIndex = -1;
    {
        const float cullStartBeat = juce::jmax(0.0f, viewX / pixelsPerBeat);
        const float cullEndBeat = (viewX + (float)getWidth()) / pixelsPerBeat;
        const int cullStartKey = juce::jmax(0, (int)(viewY / keyHeight));
        const int cullEndKey = juce::jmin(numKeys, (int)((viewY + (float)getHeight()) / keyHeight) + 1);
        const int topOffset = rulerHeight + toolbarHeight;
        const int velY = getHeight() - (showVelocityLane ? velocityLaneHeight : 0);
        if (e.x >= keysWidth && e.y >= topOffset && e.y < velY)
        {
            for (int i = (int)processor.notes.size() - 1; i >= 0; --i)
            {
                const auto& note = processor.notes[i];
                if (note.startBeat > cullEndBeat || (note.startBeat + note.lengthBeats) < cullStartBeat) continue;
                const int noteRow = 127 - note.midiNote;
                if (noteRow < cullStartKey || noteRow > cullEndKey) continue;
                auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);

                if (rect.contains(e.getPosition().toFloat()))
                {
                    clickedNoteIndex = i;
                    break;
                }
            }
        }
    }

    // Alt+left-drag on EMPTY space pans the view; on a note it copies (see
    // the note branch below). Middle-drag always pans.
    if (e.mods.isMiddleButtonDown() || (e.mods.isAltDown() && e.mods.isLeftButtonDown() && !showPitchEnvelopes && clickedNoteIndex == -1))
    {
        // Cancel any in-flight scroll/zoom animation FIRST so it can't keep
        // easing the view back toward its old target while we pan (the
        // "snaps back / jumps" bug).
        viewAnimating = false;
        animViewX = viewX;
        animViewY = viewY;
        animPixelsPerBeat = pixelsPerBeat;
        isPanning = true;
        panStartMouse = e.getPosition();
        panStartViewX = viewX;
        panStartViewY = viewY;
        return;
    }

    if (hasRazorSelection && !e.mods.isAltDown()) {
        int topOffset = rulerHeight + toolbarHeight;
        float rx = keysWidth + (razorStartBeat * pixelsPerBeat) - viewX;
        float rw = (razorEndBeat - razorStartBeat) * pixelsPerBeat;
        float ry = topOffset + ((127 - razorTopNote) * keyHeight) - viewY;
        float rh = (razorTopNote - razorBottomNote + 1) * keyHeight;
        juce::Rectangle<float> rRect(rx, ry, rw, rh);
        
        float tol = 6.0f;
        // Edge resizes snapshot the selection first so Ctrl+Z undoes them too.
        if (std::abs(e.x - rRect.getX()) <= tol && e.y >= rRect.getY() && e.y <= rRect.getBottom()) {
            razorResizeMode = 1; isResizingRazor = true; saveUndoState(); return;
        } else if (std::abs(e.x - rRect.getRight()) <= tol && e.y >= rRect.getY() && e.y <= rRect.getBottom()) {
            razorResizeMode = 2; isResizingRazor = true; saveUndoState(); return;
        } else if (std::abs(e.y - rRect.getY()) <= tol && e.x >= rRect.getX() && e.x <= rRect.getRight()) {
            razorResizeMode = 3; isResizingRazor = true; saveUndoState(); return;
        } else if (std::abs(e.y - rRect.getBottom()) <= tol && e.x >= rRect.getX() && e.x <= rRect.getRight()) {
            razorResizeMode = 4; isResizingRazor = true; saveUndoState(); return;
        } else if (rRect.contains(e.getPosition().toFloat())) {
            razorResizeMode = 5; 
            isResizingRazor = true; 
            razorStartMousePos = e.getPosition();
            
            originalRazorStartBeat = razorStartBeat;
            originalRazorEndBeat = razorEndBeat;
            originalRazorBottomNote = razorBottomNote;
            originalRazorTopNote = razorTopNote;
            
            saveUndoState();
            
            razorDragOriginalNotes.clear();
            const juce::ScopedLock sl(processor.noteLock);
            for (auto& note : processor.notes) {
                if (note.startBeat < razorEndBeat && (note.startBeat + note.lengthBeats) > razorStartBeat &&
                    note.midiNote >= razorBottomNote && note.midiNote <= razorTopNote) 
                {
                    razorDragOriginalNotes.push_back(note);
                }
            }
            return;
        }
        
        hasRazorSelection = false;
        repaint();
        return; // Consumes the click if we cleared the selection, so we don't accidentally draw a note
    }
    
    // Velocity-lane divider: grab the strip at the top of the lane to
    // resize it (replaces the old theme-panel height slider).
    if (showVelocityLane) {
        const int velYDiv = getHeight() - velocityLaneHeight;
        if (e.x >= keysWidth && e.y >= velYDiv - 4 && e.y <= velYDiv + 4) {
            isDraggingVelLaneDivider = true;
            velLaneDividerStartY = e.y;
            velLaneDividerStartHeight = velocityLaneHeight;
            return;
        }
    }

    int velY = getHeight() - velocityLaneHeight;
    if (showVelocityLane && e.y >= velY && e.x >= keysWidth) {
        const juce::ScopedLock sl (processor.noteLock);
        int bestMatch = -1;
        velGrabbedHead = false; // true only if the drag starts ON a bar
        
        // 1. First, check if the mouse is clicking directly on a visual
        //    velocity bar (same width formula as paint()).
        const float cullStartBeat = juce::jmax(0.0f, viewX / pixelsPerBeat);
        const float cullEndBeat = (viewX + (float)getWidth()) / pixelsPerBeat;
        for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
            auto& note = processor.notes[i];
            if (note.startBeat > cullEndBeat || (note.startBeat + note.lengthBeats) < cullStartBeat) continue;
            float barX = (float)keysWidth - viewX + (note.startBeat * pixelsPerBeat);
            float barW = juce::jlimit(4.0f, 12.0f, note.lengthBeats * pixelsPerBeat * 0.28f);
            float hitTolerance = 6.0f; // Make it easy to grab
            
            if (e.x >= (barX - barW * 0.5f - hitTolerance) && e.x <= (barX + barW * 0.5f + hitTolerance)) {
                if (bestMatch == -1) bestMatch = i; // Fallback match
                velGrabbedHead = true; // started ON the bar -> smooth mode
                if (note.selected) {
                    bestMatch = i; // Prioritize selected notes when bars overlap!
                    break;
                }
            }
        }

        // 2. If no direct bar hit, fall back to the note whose time range the
        //    click is inside (selected notes keep group-editing priority),
        //    then to the NEAREST bar by time — so clicking/dragging anywhere
        //    in the lane grabs the bar under the cursor.
        if (bestMatch == -1) {
            float clickedBeat = screenToBeat(e.x);
            for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
                if (processor.notes[i].startBeat > cullEndBeat || (processor.notes[i].startBeat + processor.notes[i].lengthBeats) < cullStartBeat) continue;
                if (processor.notes[i].selected && 
                    clickedBeat >= processor.notes[i].startBeat && 
                    clickedBeat <= processor.notes[i].startBeat + processor.notes[i].lengthBeats) 
                {
                    bestMatch = i;
                    break;
                }
            }
        }
        if (bestMatch == -1) {
            float clickedBeat = screenToBeat(e.x);
            float nearestDist = std::numeric_limits<float>::max();
            for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
                const auto& n = processor.notes[i];
                if (n.startBeat > cullEndBeat || (n.startBeat + n.lengthBeats) < cullStartBeat) continue;
                float dist;
                if (clickedBeat >= n.startBeat && clickedBeat <= n.startBeat + n.lengthBeats)
                    dist = 0.0f; // cursor is inside the note's time range
                else
                    dist = std::min(std::abs(clickedBeat - n.startBeat),
                                    std::abs(clickedBeat - (n.startBeat + n.lengthBeats)));
                if (dist < nearestDist) {
                    nearestDist = dist;
                    bestMatch = i;
                }
            }
        }
        
        if (bestMatch >= 0) {
            // Unselect others if we clicked an unselected note without modifiers
            if (!e.mods.isCommandDown() && !e.mods.isShiftDown() && !processor.notes[bestMatch].selected) {
                for (int i = 0; i < processor.notes.size(); ++i) {
                    if (i != bestMatch) processor.notes[i].selected = false;
                }
            }
            processor.notes[bestMatch].selected = true;

            // Begin the velocity drag: without this, mouseDrag never enters
            // the EditVelocity branch and dragging does nothing.
            draggingNoteIndex = bestMatch;
            currentDragAction = EditVelocity;
            originalVelocity = processor.notes[bestMatch].velocity;

            saveUndoState(); // velocity drags are undoable
            // NO instant change on click: values only move while dragging —
            // every bar the cursor passes over jumps to the cursor position.
            dragStartPos = e.getPosition();
            velAtCursor = (float)processor.notes[bestMatch].velocity;
            velSmoothDelta = 0.0f;
            
            selectedNotesDragState.clear();
            for (int i = 0; i < (int)processor.notes.size(); ++i) {
                if (processor.notes[i].selected) {
                    selectedNotesDragState.push_back({i, processor.notes[i].startBeat, processor.notes[i].lengthBeats, processor.notes[i].midiNote, processor.notes[i].velocity});
                }
            }
            
            repaint();
        }
        return;
    }

    int topOffset = rulerHeight + toolbarHeight;
    
    if (e.x < keysWidth && e.y > topOffset) {
        int clickedNote = screenToNote(e.y);
        // Ctrl+click on a piano key: select ALL notes on that row.
        if (e.mods.isCtrlDown())
        {
            const juce::ScopedLock sl(processor.noteLock);
            for (auto& n : processor.notes)
                n.selected = (n.midiNote == clickedNote);
            processor.notesRevision.fetch_add(1);
            repaint();
            return;
        }
        previewNoteOn(clickedNote);
        return;
    }

    if (e.x < keysWidth || e.y < topOffset) return; 

    const juce::ScopedLock sl (processor.noteLock);

    // ERASER FUNCTIONALITY (right-click, context-aware)
    // PITCH mode ON : right-click ANYWHERE arms the pitch-point eraser — no
    //                 need to start exactly on a point. The vertical-line
    //                 drag sweep then clears every point the cursor passes.
    // PITCH mode OFF: right-click erases MIDI notes.
    if (e.mods.isRightButtonDown())
    {
        currentDragAction = Erase;
        eraseIsPitchContext = showPitchEnvelopes;

        if (showPitchEnvelopes)
        {
            // Erase the point under the cursor (x & y proximity), if any —
            // otherwise just arm the eraser and let the drag sweep do the work.
            for (int i = (int)processor.notes.size() - 1; i >= 0; --i)
            {
                auto& note = processor.notes[i];
                auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
                float cy = rect.getCentreY();
                float noteLength = juce::jmax(0.0001f, note.lengthBeats);

                for (size_t j = 0; j < note.pitchCurve.size(); ++j)
                {
                    if (note.pitchCurve[j].x < -0.0001f || note.pitchCurve[j].x > noteLength + 0.0001f)
                        continue;
                    float px = rect.getX() + (note.pitchCurve[j].x / noteLength) * rect.getWidth();
                    float py = cy - note.pitchCurve[j].y * keyHeight;
                    if (std::abs(e.x - px) < 12.0f && std::abs(e.y - py) < 12.0f)
                    {
                        // The start anchor can't be deleted — but erasing it
                        // resets any bend it holds back to the note's root
                        // pitch. If it's already at root, leave it untouched.
                        if (j == 0)
                        {
                            if (std::abs(note.pitchCurve[j].y) > 0.0001f)
                            {
                                saveUndoState();
                                note.pitchCurve[j].y = 0.0f;
                                editingPitchCurveNoteIndex = i;
                                editingPitchCurveNodeIndex = (int)j;
                                editingPitchCurveTensionNodeIndex = -1;
                                repaint();
                            }
                            continue;
                        }
                        saveUndoState();
                        editingPitchCurveNoteIndex = i;
                        editingPitchCurveNodeIndex = -1;
                        editingPitchCurveTensionNodeIndex = -1;
                        note.pitchCurve.erase(note.pitchCurve.begin() + j);
                        repaint();
                        return; // erase one point on the initial click
                    }
                }
            }

            repaint();
            return; // in pitch mode, never erase notes with the right button
        }

        // NOTE context (pitch mode off): erase the MIDI note under the cursor.
        for (int i = (int)processor.notes.size() - 1; i >= 0; --i)
        {
            auto rect = getNoteRectGridSpace(processor.notes[i].midiNote, processor.notes[i].startBeat, processor.notes[i].lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);

            if (rect.contains(e.getPosition().toFloat()))
            {
                saveUndoState();
                processor.notes.erase(processor.notes.begin() + i);
                break; // only erase the top note on the initial click
            }
        }
        repaint();
        return;
    }

    float clickedBeat = screenToBeat(e.x);
    draggingNoteIndex = -1;
    currentDragAction = None;
    
    if (showPitchEnvelopes) {
        // Ctrl/Cmd + left-drag: marquee-select multiple pitch nodes.
        if (e.mods.isCtrlDown() || e.mods.isCommandDown())
        {
            isMarqueeSelectingPitch = true;
            pitchMarqueeStart = e.getPosition();
            pitchMarqueeCurrent = e.getPosition();
            selectedPitchNodes.clear();
            repaint();
            return;
        }

        int clickedNodeNoteIndex = -1;
        int clickedNodeIndex = -1;
        float bestNodeScore = 6.0f;

        for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
            auto& note = processor.notes[i];
            auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
            float cy = rect.getCentreY();
            float noteLength = juce::jmax(0.0001f, note.lengthBeats);
            int range = processor.pitchBendRange.load();
            for (size_t j = 0; j < note.pitchCurve.size(); ++j) {
                if (note.pitchCurve[j].x < -0.0001f || note.pitchCurve[j].x > noteLength + 0.0001f)
                    continue;

                float px = rect.getX() + (note.pitchCurve[j].x / noteLength) * rect.getWidth();
                float py = cy - (juce::jlimit(-(float)range, (float)range, note.pitchCurve[j].y) * keyHeight);
                const float distance = juce::Point<float>(e.x, e.y).getDistanceFrom(juce::Point<float>(px, py));
                const float priorityBonus = (i == editingPitchCurveNoteIndex || i == draggingNoteIndex) ? 0.75f : 0.0f;
                const float score = distance - priorityBonus;

                if (distance < 6.0f && score < bestNodeScore) {
                    bestNodeScore = score;
                    clickedNodeNoteIndex = i;
                    clickedNodeIndex = (int)j;
                }
            }
        }

        if (clickedNodeNoteIndex != -1) {
            auto& note = processor.notes[clickedNodeNoteIndex];

            // Multiple marquee-selected nodes: dragging one moves the group.
            if (selectedPitchNodes.size() > 1 && isPitchNodeSelected(clickedNodeNoteIndex, clickedNodeIndex))
            {
                saveUndoState();
                isDraggingPitchGroup = true;
                pitchGroupDragNodes = selectedPitchNodes;
                pitchGroupDragOriginalNodes.clear();
                for (const auto& sel : selectedPitchNodes)
                    if (sel.first >= 0 && sel.first < (int)processor.notes.size()
                        && sel.second >= 0 && sel.second < (int)processor.notes[sel.first].pitchCurve.size())
                        pitchGroupDragOriginalNodes.push_back(processor.notes[sel.first].pitchCurve[sel.second]);
                pitchGroupDragStart = e.getPosition();
                editingPitchCurveNoteIndex = clickedNodeNoteIndex;
                editingPitchCurveNodeIndex = clickedNodeIndex;
                repaint();
                return;
            }

            saveUndoState();
            editingPitchCurveNoteIndex = clickedNodeNoteIndex;
            editingPitchCurveNodeIndex = clickedNodeIndex;
            
            if (pitchPreviewEnabled)
                startPitchPreview(note.midiNote, clickedNodeNoteIndex);
            
            repaintPitchEditArea(note);
            return;
        }

        // Alt + click/drag on a pitch segment adjusts tension. Grab the
        // segment whose curve line is NEAREST the cursor (within a grab
        // radius), so it works accurately anywhere on the segment — even
        // with overlapping notes or right next to a node.
        if (e.mods.isAltDown()) {
            int bestNote = -1, bestSeg = -1;
            float bestDist = 12.0f;
            {
                const juce::ScopedLock sl(processor.noteLock);
                const int range = juce::jmax(1, processor.pitchBendRange.load());
                const int globalShape = processor.pitchShape.load();
                for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
                    const auto& note = processor.notes[i];
                    if (note.pitchCurve.size() < 2) continue;
                    auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                    rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
                    if (e.x < rect.getX() || e.x > rect.getRight()) continue;
                    const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                    const float beatOffset = juce::jlimit(0.0f, noteLength, screenToBeat(e.x) - note.startBeat);
                    for (size_t j = 0; j + 1 < note.pitchCurve.size(); ++j) {
                        if (beatOffset < note.pitchCurve[j].x - 0.0001f || beatOffset > note.pitchCurve[j + 1].x + 0.0001f) continue;
                        const float curveY = rect.getCentreY()
                            - (juce::jlimit(-(float)range, (float)range,
                                evaluatePitchBendAtBeat(note, beatOffset, globalShape)) * keyHeight);
                        const float dist = std::abs((float)e.y - curveY);
                        if (dist < bestDist) {
                            bestDist = dist;
                            bestNote = i;
                            bestSeg = (int)j;
                        }
                    }
                }
            }
            if (bestNote != -1) {
                const juce::ScopedLock sl(processor.noteLock);
                auto& note = processor.notes[bestNote];
                saveUndoState();
                editingPitchCurveNoteIndex = bestNote;
                editingPitchCurveTensionNodeIndex = bestSeg;
                initialDragTension = note.pitchCurve[bestSeg].tension;
                dragStartPos = e.getPosition();
                // Tension editing overrides the segment's shape: switch it to
                // auto so the tension drag always has an effect.
                note.pitchCurve[bestSeg].shape = 0;
                repaintPitchEditArea(note);
                return;
            }
        }

        // 2. Check if clicking ON the pitch line (or inside the note block) to add a node
        int clickedLineNoteIndex = -1;
        float bestLineScore = std::numeric_limits<float>::max();
        const int shape = processor.pitchShape.load();

        for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
            auto& note = processor.notes[i];
            // Alt+drag tension works on ANY note's segment; plain clicks still
            // only touch the currently-editing note (keeps note editing intact).
            if (i != editingPitchCurveNoteIndex && !e.mods.isAltDown()) continue;
            auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
            
            if (e.x >= rect.getX() && e.x <= rect.getRight()) {
                float cy = rect.getCentreY();
                
                // Allow clicking anywhere within the pitch bend vertical range
                int range = processor.pitchBendRange.load();
                float pitchAreaY = cy - (range * keyHeight);
                float pitchAreaBottom = cy + (range * keyHeight);
                if (e.y >= pitchAreaY && e.y <= pitchAreaBottom) {
                    const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                    const float beatOffset = ((e.x - rect.getX()) / rect.getWidth()) * noteLength;
                    const float bendAtCursor = evaluatePitchBendAtBeat(note, beatOffset, shape);
                    const float curveY = cy - (juce::jlimit(-(float)range, (float)range, bendAtCursor) * keyHeight);
                    float score = std::abs((float)e.y - curveY);

                    if (rect.contains(e.getPosition().toFloat()))
                        score -= keyHeight;

                    if (score < bestLineScore) {
                        bestLineScore = score;
                        clickedLineNoteIndex = i;
                    }
                }
            }
        }
        
        if (clickedLineNoteIndex != -1) {
            auto& note = processor.notes[clickedLineNoteIndex];
            auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
            const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
             
            float beatOffset = ((e.x - rect.getX()) / rect.getWidth()) * noteLength;
            float cy = rect.getCentreY();
            float bendY = (cy - e.y) / keyHeight;

            const bool snapPitchPoint = !e.mods.isShiftDown();
            if (snapPitchPoint) {
                float globalBeat = note.startBeat + beatOffset;
                globalBeat = snapValueToStep(globalBeat, getCurrentGridSnap());
                beatOffset = globalBeat - note.startBeat;
            }
              
            beatOffset = juce::jlimit(0.0f, noteLength, beatOffset);
            if (snapPitchPoint) {
                bendY = snapPitchBendToNoteCenter(bendY);
                if (bendY != 0.0f)
                    bendY = quantizeToScale(note.midiNote, bendY);
            }
            bendY = juce::jlimit(-(float)processor.pitchBendRange.load(), (float)processor.pitchBendRange.load(), bendY);
            
            {
                saveUndoState();
                if (note.pitchCurve.empty()) {
                    note.pitchCurve.push_back({0.0f, 0.0f, 0.0f, bakedNodeShapeFor(processor)});
                }

                // Parallel points at the same beat (different pitch) are fine;
                // only a point at the EXACT same position (same x AND same y)
                // replaces the one underneath — the new point wins, no stacks.
                constexpr float xTolerance = 0.005f; // ~2.5 ms at 120 BPM
                constexpr float yTolerance = 0.05f;  // ~5 cents
                // Newly drawn points are BAKED with the current global shape,
                // so the curve keeps this shape even if the global mode is
                // changed later (a replaced node keeps its own shape below).
                PitchNode newPoint = { beatOffset, bendY, 0.0f, bakedNodeShapeFor(processor) };
                for (auto& p : note.pitchCurve)
                {
                    if (std::abs(p.x - beatOffset) <= xTolerance
                        && std::abs(p.y - bendY) <= yTolerance)
                    {
                        // Keep the shape/tension from the replaced node so
                        // C-menu settings survive a re-place.
                        newPoint.tension = p.tension;
                        newPoint.shape = p.shape;
                        break;
                    }
                }
                note.pitchCurve.erase(std::remove_if(note.pitchCurve.begin(), note.pitchCurve.end(),
                    [&](const PitchNode& p) { return std::abs(p.x - beatOffset) <= xTolerance
                                                   && std::abs(p.y - bendY) <= yTolerance; }),
                    note.pitchCurve.end());
                // First bend point drawn on a fresh curve (only the seeded
                // start point so far): bake the CURRENT global shape into the
                // start point too, so the curve's first segment uses the shape
                // selected at draw time even if the start point was seeded
                // under an older global mode.
                if (note.pitchCurve.size() == 1)
                    note.pitchCurve.front().shape = bakedNodeShapeFor(processor);
                note.pitchCurve.push_back(newPoint);

                std::stable_sort(note.pitchCurve.begin(), note.pitchCurve.end(), [](const PitchNode& a, const PitchNode& b) { return a.x < b.x; });

                for (size_t i = 0; i < note.pitchCurve.size(); ++i) {
                    if (std::abs(note.pitchCurve[i].x - beatOffset) <= xTolerance && note.pitchCurve[i].y == bendY) {
                        editingPitchCurveNoteIndex = clickedLineNoteIndex;
                        editingPitchCurveNodeIndex = (int)i;
                        
                        break;
                    }
                }
                if (pitchPreviewEnabled)
                    startPitchPreview(note.midiNote, clickedLineNoteIndex);
                repaintPitchEditArea(note);
                return;
            }
        }
    }

    if (clickedNoteIndex != -1) {
        if (e.mods.isCommandDown() || e.mods.isShiftDown()) {
            processor.notes[clickedNoteIndex].selected = !processor.notes[clickedNoteIndex].selected;
            processor.notesRevision.fetch_add(1); // selection is part of the paint cache
        } else {
            if (!processor.notes[clickedNoteIndex].selected) {
                for (auto& n : processor.notes) n.selected = false;
                processor.notes[clickedNoteIndex].selected = true;
            }
        }
        
        if (processor.notes[clickedNoteIndex].selected) {
            // Alt-drag duplicates the whole selection (pitch curves included)
            // and drags the copies — the originals stay put. Same undo step
            // semantics as a plain move (snapshot taken before the copies are
            // added, so undo removes them).
            if (e.mods.isAltDown() && !(showPitchEnvelopes && clickedNoteIndex == editingPitchCurveNoteIndex))
            {
                std::vector<int> originals;
                for (int i = 0; i < (int)processor.notes.size(); ++i)
                    if (processor.notes[i].selected)
                        originals.push_back(i);

                int clickedPos = 0;
                for (size_t k = 0; k < originals.size(); ++k)
                    if (originals[k] == clickedNoteIndex) { clickedPos = (int)k; break; }

                saveUndoState(false); // note move/resize: always its own undo step
                std::vector<int> copies;
                {
                    const juce::ScopedLock sl(processor.noteLock);
                    copies.reserve(originals.size());
                    for (int idx : originals)
                    {
                        NoteEvent copy = processor.notes[idx]; // deep-copies pitchCurve
                        copy.selected = true;
                        processor.notes.push_back(copy);
                        copies.push_back((int)processor.notes.size() - 1);
                        processor.notes[idx].selected = false;
                    }
                }
                processor.notesRevision.fetch_add(1); // notes vector changed

                const int dragCopyIndex = copies[clickedPos];
                draggingNoteIndex = dragCopyIndex;
                previewNoteOn(processor.notes[dragCopyIndex].midiNote);

                auto rect = getNoteRectGridSpace(processor.notes[dragCopyIndex].midiNote,
                                                 processor.notes[dragCopyIndex].startBeat,
                                                 processor.notes[dragCopyIndex].lengthBeats);
                rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);

                if (e.x > rect.getRight() - 10.0f) currentDragAction = ResizeRight;
                else currentDragAction = Move;

                showDragGhost = false; // alt-copy: the originals stay put, no ghost
                wasNewNoteDrag = false;
                originalStartBeat = processor.notes[dragCopyIndex].startBeat;
                originalLengthBeats = processor.notes[dragCopyIndex].lengthBeats;
                originalMidiNote = processor.notes[dragCopyIndex].midiNote;
                dragStartPos = e.getPosition();
                wasShiftDownDuringDrag = e.mods.isShiftDown();

                selectedNotesDragState.clear();
                for (int idx : copies)
                {
                    const auto& n = processor.notes[idx];
                    selectedNotesDragState.push_back({idx, n.startBeat, n.lengthBeats, n.midiNote, n.velocity});
                }
                repaint();
                return;
            }

            draggingNoteIndex = clickedNoteIndex;
            previewNoteOn(processor.notes[clickedNoteIndex].midiNote);
            
            auto rect = getNoteRectGridSpace(processor.notes[clickedNoteIndex].midiNote, processor.notes[clickedNoteIndex].startBeat, processor.notes[clickedNoteIndex].lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
            
            if (showPitchEnvelopes && clickedNoteIndex == editingPitchCurveNoteIndex) {
                currentDragAction = None; // Prevent moving/resizing the active pitch-edited note
            } else {
                if (e.x > rect.getRight() - 10.0f) currentDragAction = ResizeRight;
                else currentDragAction = Move;
            }

            showDragGhost = (currentDragAction == Move); // outline the originals while dragging
            wasNewNoteDrag = false;
            
            originalStartBeat = processor.notes[clickedNoteIndex].startBeat;
            originalLengthBeats = processor.notes[clickedNoteIndex].lengthBeats;
            originalMidiNote = processor.notes[clickedNoteIndex].midiNote;
            dragStartPos = e.getPosition();
            wasShiftDownDuringDrag = e.mods.isShiftDown();
            saveUndoState(false); // note move/resize: always its own undo step
            
            selectedNotesDragState.clear();
            for (int i = 0; i < (int)processor.notes.size(); ++i) {
                if (processor.notes[i].selected) {
                    selectedNotesDragState.push_back({i, processor.notes[i].startBeat, processor.notes[i].lengthBeats, processor.notes[i].midiNote, processor.notes[i].velocity});
                }
            }
        } else {
            // Deselected a note with modifier click
            draggingNoteIndex = -1;
        }
        repaint();
        return;
    } else {
        const bool marqueeModifier = e.mods.isCommandDown() || e.mods.isCtrlDown();

        // Select tool: clicking/dragging empty space is a selection gesture
        // (marquee). Draw tool: marquee only with Ctrl/Cmd held; a plain click
        // deselects and draws a new note (below).
        if (currentTool == SelectTool || marqueeModifier) {
            isMarqueeSelecting = true;
            marqueeStartPos = e.getPosition();
            marqueeCurrentPos = e.getPosition();
            preMarqueeSelection.clear();
            for (auto& n : processor.notes) {
                preMarqueeSelection.push_back(n.selected);
            }
            repaint();
            return;
        }

        for (auto& n : processor.notes) n.selected = false;
    }

    int clickedNote = screenToNote(e.y);
    if (isScaleLockActive) {
        clickedNote = snapNoteToScale(clickedNote, scaleRoot, scaleType);
    }
    
    float snap = getCurrentGridSnap();
    float snappedBeat = std::floor(clickedBeat / snap) * snap;
    float defaultNoteLength = lastNoteLength > 0.0f ? lastNoteLength : snap;
    NoteEvent newNote {clickedNote, snappedBeat, defaultNoteLength, 100, false, true};
    saveUndoState();
    undoStateSavedForDrag = true;
    processor.notes.push_back(newNote);
    processor.notesRevision.fetch_add(1); // refresh the paint cache so the note + flash render immediately
    if (showPitchEnvelopes)
        ensurePitchStartPoints(); // new notes get their start point immediately
    draggingNoteIndex = (int)processor.notes.size() - 1;
    currentDragAction = Move;
    wasNewNoteDrag = true;
    showDragGhost = false;
    flashNoteIndex = draggingNoteIndex; // flash RIGHT when the note appears
    noteFlashAlpha = 0.5f;
    
    previewNoteOn(clickedNote);
    
    originalStartBeat = newNote.startBeat;
    originalLengthBeats = newNote.lengthBeats;
    originalMidiNote = newNote.midiNote;
    dragStartPos = e.getPosition();
    
    wasShiftDownDuringDrag = e.mods.isShiftDown();
    
    selectedNotesDragState.clear();
    selectedNotesDragState.push_back({draggingNoteIndex, newNote.startBeat, newNote.lengthBeats, newNote.midiNote, newNote.velocity});
    
    repaint();
}

void PianoRollComponent::mouseDrag (const juce::MouseEvent& e)
{
    juce::Point<int> oldDragPos = lastDragPos;
    lastDragPos = e.getPosition();

    // Velocity-lane divider drag: resize the lane (persisted like the old
    // theme slider did).
    if (isDraggingVelLaneDivider)
    {
        const int newH = juce::jlimit(30, 500, velLaneDividerStartHeight + (velLaneDividerStartY - e.y));
        if (newH != velocityLaneHeight)
        {
            velocityLaneHeight = newH;
            processor.pianoRollVelocityLaneHeight.store(velocityLaneHeight);
            markPersistentEditorStateChanged();
        }
        repaint();
        return;
    }

    // Ctrl/Cmd + drag in pitch mode: marquee-select pitch nodes.
    if (isMarqueeSelectingPitch)
    {
        pitchMarqueeCurrent = e.getPosition();
        juce::Rectangle<int> selRect(juce::jmin(pitchMarqueeStart.x, pitchMarqueeCurrent.x),
                                     juce::jmin(pitchMarqueeStart.y, pitchMarqueeCurrent.y),
                                     std::abs(pitchMarqueeStart.x - pitchMarqueeCurrent.x),
                                     std::abs(pitchMarqueeStart.y - pitchMarqueeCurrent.y));
        selectedPitchNodes.clear();
        {
            const juce::ScopedLock sl(processor.noteLock);
            const int range = juce::jmax(1, processor.pitchBendRange.load());
            for (int i = 0; i < (int)processor.notes.size(); ++i)
            {
                const auto& note = processor.notes[i];
                if (note.pitchCurve.empty()) continue;
                auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                rect.translate((float)keysWidth - viewX, (float)(rulerHeight + toolbarHeight) - viewY);
                const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                const float cy = rect.getCentreY();
                for (size_t j = 0; j < note.pitchCurve.size(); ++j)
                {
                    const float px = rect.getX() + (juce::jlimit(0.0f, noteLength, note.pitchCurve[j].x) / noteLength) * rect.getWidth();
                    const float py = cy - (juce::jlimit(-(float)range, (float)range, note.pitchCurve[j].y) * keyHeight);
                    if (selRect.contains((int)px, (int)py))
                        selectedPitchNodes.push_back({ i, (int)j });
                }
            }
        }
        repaint();
        return;
    }

    if (isDraggingMidiButton)
    {
        if (e.getDistanceFromDragStart() > 3)
        {
            isDraggingMidiButton = false;
            exportMidiToDrag();
        }
        return;
    }
    
    if (showPitchEnvelopes && editingPitchCurveNoteIndex != -1 && editingPitchCurveTensionNodeIndex != -1) {
        const juce::ScopedLock sl(processor.noteLock);
        const size_t noteIndex = (size_t)editingPitchCurveNoteIndex;
        const size_t nodeIndex = (size_t)editingPitchCurveTensionNodeIndex;
        
        if (noteIndex < processor.notes.size()) {
            auto& note = processor.notes[noteIndex];
            if (nodeIndex < note.pitchCurve.size()) {
                float dy = (float)(dragStartPos.y - e.y); // Negative means dragging down (less tension), positive up (more tension)
                // Need a start drag pos
                float newTension = juce::jlimit(-2.0f, 2.0f, initialDragTension + (dy * 0.0125f));
                
                note.pitchCurve[nodeIndex].tension = newTension;
                repaintPitchEditArea(note);
            }
        }
        return;
    }

    // Group-drag: multiple selected pitch nodes move together by the same
    // beat/semitone delta (restored from their original positions each frame).
    if (showPitchEnvelopes && isDraggingPitchGroup)
    {
        const juce::ScopedLock sl(processor.noteLock);
        const float dxBeats = (float)(e.x - pitchGroupDragStart.x) / pixelsPerBeat;
        const float dySemis = -(float)(e.y - pitchGroupDragStart.y) / keyHeight;
        const int range = juce::jmax(1, processor.pitchBendRange.load());
        const float gridSnap = getCurrentGridSnap();

        // Rigid-body move: snap the REFERENCE node (the one the drag started
        // on) to the grid + pitch centers, then shift the whole group by that
        // adjusted delta — the group keeps its shape and lands on the grid.
        int refIdx = -1;
        for (size_t i = 0; i < pitchGroupDragNodes.size(); ++i)
            if (pitchGroupDragNodes[i].first == editingPitchCurveNoteIndex
                && pitchGroupDragNodes[i].second == editingPitchCurveNodeIndex)
                { refIdx = (int)i; break; }

        float adjustedDx = dxBeats, adjustedDy = dySemis;
        if (refIdx >= 0 && refIdx < (int)pitchGroupDragOriginalNodes.size())
        {
            const PitchNode& refOrig = pitchGroupDragOriginalNodes[refIdx];
            float refX = refOrig.x + dxBeats;
            float refY = refOrig.y + dySemis;

            if (!e.mods.isShiftDown())
            {
                float globalBeat = processor.notes[pitchGroupDragNodes[refIdx].first].startBeat + refX;
                globalBeat = snapValueToStep(globalBeat, gridSnap);
                refX = globalBeat - processor.notes[pitchGroupDragNodes[refIdx].first].startBeat;

                refY = snapPitchBendToNoteCenter(refY);
                if (isScaleLockActive)
                    refY = quantizeToScale(processor.notes[pitchGroupDragNodes[refIdx].first].midiNote, refY);
            }

            adjustedDx = refX - refOrig.x;
            adjustedDy = refY - refOrig.y;
        }

        for (size_t i = 0; i < pitchGroupDragNodes.size(); ++i)
        {
            const int ni = pitchGroupDragNodes[i].first;
            const int nj = pitchGroupDragNodes[i].second;
            if (i >= pitchGroupDragOriginalNodes.size()) continue;
            if (ni < 0 || ni >= (int)processor.notes.size()) continue;
            auto& curve = processor.notes[ni].pitchCurve;
            if (nj < 0 || nj >= (int)curve.size()) continue;

            const PitchNode& orig = pitchGroupDragOriginalNodes[i];
            const float noteLength = juce::jmax(0.0001f, processor.notes[ni].lengthBeats);

            // Clamp against the current neighbours so nodes can't cross.
            float minX = 0.0f, maxX = noteLength;
            if (nj > 0) minX = juce::jlimit(0.0f, noteLength, curve[nj - 1].x);
            if (nj + 1 < (int)curve.size()) maxX = juce::jlimit(0.0f, noteLength, curve[nj + 1].x);
            if (minX > maxX) minX = maxX;

            float newX = juce::jlimit(minX, maxX, orig.x + adjustedDx);
            if (nj == 0) newX = 0.0f; // the curve's first point stays at the note start
            float newY = juce::jlimit(-(float)range, (float)range, orig.y + adjustedDy);

            curve[nj].x = newX;
            curve[nj].y = newY;
        }

        if (!pitchGroupDragNodes.empty())
        {
            const int ni = pitchGroupDragNodes.front().first;
            const int nj = pitchGroupDragNodes.front().second;
            if (ni >= 0 && ni < (int)processor.notes.size()
                && nj >= 0 && nj < (int)processor.notes[ni].pitchCurve.size())
                updatePitchPreviewBend(processor.notes[ni].pitchCurve[nj].y, processor.notes[ni].pitchCurve[nj].x);
        }
        repaint();
        return;
    }

    if (showPitchEnvelopes && editingPitchCurveNoteIndex != -1 && editingPitchCurveNodeIndex != -1)
    {
        const juce::ScopedLock sl(processor.noteLock);
        const size_t noteIndex = (size_t)editingPitchCurveNoteIndex;
        const size_t nodeIndex = (size_t)editingPitchCurveNodeIndex;

        if (noteIndex < processor.notes.size()) {
            auto& note = processor.notes[noteIndex];
            if (nodeIndex < note.pitchCurve.size()) {
                auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                int topOffset = rulerHeight + toolbarHeight;
                rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
                auto previousPoint = note.pitchCurve[nodeIndex];
                const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                 
                float beatOffset = ((e.x - rect.getX()) / rect.getWidth()) * noteLength;
                float cy = rect.getCentreY();
                float bendY = (cy - e.y) / keyHeight;

                const bool snapPitchPoint = !e.mods.isShiftDown();
                if (snapPitchPoint) {
                    float globalBeat = note.startBeat + beatOffset;
                    globalBeat = snapValueToStep(globalBeat, getCurrentGridSnap());
                    beatOffset = globalBeat - note.startBeat;
                }
                 
                float minX = 0.0f;
                float maxX = noteLength;
                 
                if (nodeIndex > 0) {
                    minX = juce::jlimit(0.0f, noteLength, note.pitchCurve[nodeIndex - 1].x);
                }
                if (nodeIndex + 1 < note.pitchCurve.size()) {
                    maxX = juce::jlimit(0.0f, noteLength, note.pitchCurve[nodeIndex + 1].x);
                }
                if (minX > maxX)
                    minX = maxX;
                
                if (editingPitchCurveNodeIndex == 0) {
                    beatOffset = 0.0f; // Force first point to start of note
                }
                
                beatOffset = juce::jlimit(minX, maxX, beatOffset);
                if (snapPitchPoint) {
                    bendY = snapPitchBendToNoteCenter(bendY);
                    if (bendY != 0.0f)
                        bendY = quantizeToScale(note.midiNote, bendY);
                }
                bendY = juce::jlimit(-(float)processor.pitchBendRange.load(), (float)processor.pitchBendRange.load(), bendY);

                if (std::abs(previousPoint.x - beatOffset) < pitchCurveBeatEpsilon && std::abs(previousPoint.y - bendY) < pitchCurveSemitoneEpsilon)
                    return;
                
                note.pitchCurve[nodeIndex].x = beatOffset;
                note.pitchCurve[nodeIndex].y = bendY;

                // Parallel nodes at the same beat (different pitch) are fine;
                // only landing on the EXACT same position (same x AND same y)
                // deletes the node underneath — the dragged one wins.
                constexpr float stackTolerance = 0.005f;
                constexpr float stackYTolerance = 0.05f;
                std::vector<int> nodesToRemove;
                for (int i = 0; i < (int)note.pitchCurve.size(); ++i)
                    if (i != (int)nodeIndex
                        && std::abs(note.pitchCurve[i].x - beatOffset) <= stackTolerance
                        && std::abs(note.pitchCurve[i].y - bendY) <= stackYTolerance)
                        nodesToRemove.push_back(i);
                for (auto it = nodesToRemove.rbegin(); it != nodesToRemove.rend(); ++it)
                    note.pitchCurve.erase(note.pitchCurve.begin() + *it);

                // The dragged node's index may have shifted after deletions —
                // re-locate it so the drag keeps working.
                if (!nodesToRemove.empty())
                {
                    for (int i = 0; i < (int)note.pitchCurve.size(); ++i)
                    {
                        if (std::abs(note.pitchCurve[i].x - beatOffset) <= stackTolerance
                            && std::abs(note.pitchCurve[i].y - bendY) < 0.01f)
                        {
                            editingPitchCurveNodeIndex = i;
                            break;
                        }
                    }
                }

                updatePitchPreviewBend(bendY, beatOffset); // jump sweep to the dragged spot
                repaintPitchEditArea(note);
            }
        }
        return;
    }

    if (isStretchingRazor)
    {
        float snap = getCurrentGridSnap();
        float newStart = originalRazorStartBeat;
        float newEnd = originalRazorEndBeat;
        if (razorStretchEdge == -1)
        {
            newStart = juce::jmax(0.0f, std::floor(screenToBeat(e.x) / snap) * snap);
            if (newStart >= newEnd - 0.25f) newStart = newEnd - 0.25f;
        }
        else
        {
            newEnd = std::ceil(screenToBeat(e.x) / snap) * snap;
            if (newEnd <= newStart + 0.25f) newEnd = newStart + 0.25f;
        }

        const float span = originalRazorEndBeat - originalRazorStartBeat;
        const float scale = span > 0.0001f ? (newEnd - newStart) / span : 1.0f;

        razorStartBeat = newStart;
        razorEndBeat = newEnd;

        const juce::ScopedLock sl(processor.noteLock);
        // Rebuild from the pre-stretch snapshot so repeated drags stay clean.
        processor.notes = undoHistory.back().notes;
        processor.notes.erase(std::remove_if(processor.notes.begin(), processor.notes.end(),
            [&](const NoteEvent& note) {
                return note.startBeat < originalRazorEndBeat &&
                       (note.startBeat + note.lengthBeats) > originalRazorStartBeat &&
                       note.midiNote >= originalRazorBottomNote &&
                       note.midiNote <= originalRazorTopNote;
            }), processor.notes.end());

        for (auto& note : razorDragOriginalNotes)
        {
            // Only the part INSIDE the original razor area is stretched; the
            // parts outside the area keep their original position and length
            // (the same slicing the razor move/duplicate operations use).
            const float noteEnd = note.startBeat + note.lengthBeats;
            const float sliceStart = juce::jmax(note.startBeat, originalRazorStartBeat);
            const float sliceEnd = juce::jmin(noteEnd, originalRazorEndBeat);
            const float sliceLen = sliceEnd - sliceStart;
            if (sliceLen <= 0.001f)
                continue;

            const float sliceStartRel = sliceStart - note.startBeat;
            const float sliceEndRel = sliceEnd - note.startBeat;

            // Left part (before the region) — untouched.
            if (sliceStart > note.startBeat + 0.001f)
            {
                NoteEvent leftPart = note;
                leftPart.lengthBeats = sliceStart - note.startBeat;
                leftPart.pitchCurve.clear();
                for (const auto& p : note.pitchCurve)
                    if (p.x <= sliceStartRel + 0.0001f)
                        leftPart.pitchCurve.push_back({ juce::jmin(p.x, sliceStartRel), p.y, p.tension, p.shape });
                processor.notes.push_back(leftPart);
            }

            // Right part (after the region) — untouched.
            if (sliceEnd < noteEnd - 0.001f)
            {
                NoteEvent rightPart = note;
                rightPart.startBeat = sliceEnd;
                rightPart.lengthBeats = noteEnd - sliceEnd;
                rightPart.pitchCurve.clear();
                for (const auto& p : note.pitchCurve)
                    if (p.x >= sliceEndRel - 0.0001f)
                        rightPart.pitchCurve.push_back({ juce::jmax(0.0f, p.x - sliceEndRel), p.y, p.tension, p.shape });
                processor.notes.push_back(rightPart);
            }

            // Scaled middle slice — the content that stretches. Pitch-curve
            // node positions scale together with the note length.
            NoteEvent scaled = note;
            scaled.startBeat = juce::jmax(0.0f, newStart + (sliceStart - originalRazorStartBeat) * scale);
            scaled.lengthBeats = juce::jmax(0.05f, sliceLen * scale);
            scaled.pitchCurve.clear();
            for (const auto& p : note.pitchCurve)
            {
                if (p.x >= sliceStartRel - 0.0001f && p.x <= sliceEndRel + 0.0001f)
                {
                    const float nx = juce::jlimit(0.0f, scaled.lengthBeats, (p.x - sliceStartRel) * scale);
                    scaled.pitchCurve.push_back({ nx, p.y, p.tension, p.shape });
                }
            }
            if (scaled.lengthBeats > 0.001f)
                processor.notes.push_back(scaled);
        }
        repaint();
        return;
    }

    if (isResizingRazor)
    {
        float snap = getCurrentGridSnap();
        if (razorResizeMode == 1) { // Left
            float beat = std::floor(screenToBeat(e.x) / snap) * snap;
            if (beat < razorEndBeat) razorStartBeat = juce::jmax(0.0f, beat);
        } else if (razorResizeMode == 2) { // Right
            float beat = std::ceil(screenToBeat(e.x) / snap) * snap;
            if (beat > razorStartBeat) razorEndBeat = beat;
        } else if (razorResizeMode == 3) { // Top
            int note = screenToNote(e.y);
            if (note >= razorBottomNote) razorTopNote = juce::jmin(127, note);
        } else if (razorResizeMode == 4) { // Bottom
            int note = screenToNote(e.y);
            if (note <= razorTopNote) razorBottomNote = juce::jmax(0, note);
        } else if (razorResizeMode == 5) { // Move selection and notes
            float snap = getCurrentGridSnap();
            float deltaBeats = screenToBeat(e.x) - screenToBeat(razorStartMousePos.x);
            deltaBeats = std::round(deltaBeats / snap) * snap;
            
            int deltaRows = std::round((e.y - razorStartMousePos.y) / keyHeight);
            
            float newStartBeat = juce::jmax(0.0f, originalRazorStartBeat + deltaBeats);
            float actualDeltaBeats = newStartBeat - originalRazorStartBeat;
            
            int newBottomNote = juce::jlimit(0, 127 - (originalRazorTopNote - originalRazorBottomNote), originalRazorBottomNote - deltaRows);
            int actualDeltaNotes = newBottomNote - originalRazorBottomNote;
            
            razorStartBeat = newStartBeat;
            razorEndBeat = newStartBeat + (originalRazorEndBeat - originalRazorStartBeat);
            razorBottomNote = newBottomNote;
            razorTopNote = newBottomNote + (originalRazorTopNote - originalRazorBottomNote);
            
            const juce::ScopedLock sl(processor.noteLock);
            
            // Restore from undo history
            processor.notes = undoHistory.back().notes;
            
            // Remove notes that were in the original razor area
            processor.notes.erase(std::remove_if(processor.notes.begin(), processor.notes.end(),
                [&](const NoteEvent& note) {
                    return note.startBeat < originalRazorEndBeat && 
                           (note.startBeat + note.lengthBeats) > originalRazorStartBeat &&
                           note.midiNote >= originalRazorBottomNote && 
                           note.midiNote <= originalRazorTopNote;
                }), processor.notes.end());
                
            // Add the shifted copies
            for (auto& note : razorDragOriginalNotes) {
                NoteEvent shifted = note;
                
                // Shift bounds
                float sliceStart = juce::jmax(note.startBeat, originalRazorStartBeat);
                float sliceEnd = juce::jmin(note.startBeat + note.lengthBeats, originalRazorEndBeat);
                
                shifted.startBeat = sliceStart + actualDeltaBeats;
                shifted.lengthBeats = sliceEnd - sliceStart;

                // Pitch curves: carry only the nodes inside the razor area,
                // remapped to the shifted note's coordinates.
                shifted.pitchCurve.clear();
                const float relStart = sliceStart - note.startBeat;
                const float relEnd = sliceEnd - note.startBeat;
                for (const auto& p : note.pitchCurve)
                {
                    if (p.x >= relStart - 0.0001f && p.x <= relEnd + 0.0001f)
                    {
                        PitchNode shiftedNode = p;
                        shiftedNode.x = juce::jlimit(0.0f, shifted.lengthBeats, p.x - relStart);
                        shifted.pitchCurve.push_back(shiftedNode);
                    }
                }

                int newPitch = note.midiNote + actualDeltaNotes;
                if (isScaleLockActive) {
                    newPitch = snapNoteToScale(newPitch, scaleRoot, scaleType);
                }
                shifted.midiNote = juce::jlimit(0, 127, newPitch);
                
                if (shifted.lengthBeats > 0.001f) {
                    processor.notes.push_back(shifted);
                }
            }
        }
        repaint();
        return;
    }

    if (isRazorSelecting)
    {
        float snap = getCurrentGridSnap();
        float startBeat = std::floor(screenToBeat(razorStartMousePos.x) / snap) * snap;
        float currentBeatRaw = screenToBeat(e.x);
        float endBeat = currentBeatRaw > screenToBeat(razorStartMousePos.x) ? 
                        std::ceil(currentBeatRaw / snap) * snap : 
                        std::floor(currentBeatRaw / snap) * snap;

        int startNote = screenToNote(razorStartMousePos.y);
        int currentNote = screenToNote(e.y);

        razorStartBeat = juce::jmin(startBeat, endBeat);
        razorEndBeat = juce::jmax(startBeat, endBeat);
        if (razorStartBeat == razorEndBeat) razorEndBeat += snap;

        razorBottomNote = juce::jmin(startNote, currentNote);
        razorTopNote = juce::jmax(startNote, currentNote);
        
        repaint();
        return;
    }

    if (isMarqueeSelecting)
    {
        marqueeCurrentPos = e.getPosition();

        int topOffset = rulerHeight + toolbarHeight;
        juce::Rectangle<float> marqueeRect = juce::Rectangle<float>::leftTopRightBottom(
            (float)std::min(marqueeStartPos.x, marqueeCurrentPos.x),
            (float)std::min(marqueeStartPos.y, marqueeCurrentPos.y),
            (float)std::max(marqueeStartPos.x, marqueeCurrentPos.x),
            (float)std::max(marqueeStartPos.y, marqueeCurrentPos.y)
        );

        const juce::ScopedLock sl(processor.noteLock);
        {
            // Viewport cull: the marquee lives inside the visible area, so
            // off-screen notes can never intersect it — skip them cheaply.
            const float cullStartBeat = juce::jmax(0.0f, viewX / pixelsPerBeat);
            const float cullEndBeat = (viewX + (float)getWidth()) / pixelsPerBeat;
            const int cullStartKey = juce::jmax(0, (int)(viewY / keyHeight));
            const int cullEndKey = juce::jmin(numKeys, (int)((viewY + (float)getHeight()) / keyHeight) + 1);
            for (size_t i = 0; i < processor.notes.size(); ++i) {
                auto& n = processor.notes[i];
                if (n.startBeat > cullEndBeat || (n.startBeat + n.lengthBeats) < cullStartBeat) continue;
                const int noteRow = 127 - n.midiNote;
                if (noteRow < cullStartKey || noteRow > cullEndKey) continue;
                auto rect = getNoteRectGridSpace(n.midiNote, n.startBeat, n.lengthBeats);
                rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
            
                bool inMarquee = marqueeRect.intersects(rect);
                bool wasSelected = (i < preMarqueeSelection.size()) ? preMarqueeSelection[i] : false;
            
                if (e.mods.isShiftDown()) {
                    n.selected = inMarquee || wasSelected;
                } else {
                    n.selected = inMarquee;
                }
            }
        }
        
        repaint();
        return;
    }

    if (isPanning)
    {
        viewAnimating = false; // safety: easing must never fight a manual pan
        viewX = panStartViewX - (e.x - panStartMouse.x);
        viewY = panStartViewY - (e.y - panStartMouse.y);
        viewX = juce::jmax(0.0f, viewX);
        viewY = juce::jlimit(0.0f, (float)(numKeys * keyHeight), viewY);
        storePersistentEditorState();
        repaint();
        return;
    }

    if (currentDragAction == Erase || e.mods.isRightButtonDown())
    {
        int topOffset = rulerHeight + toolbarHeight;

        // Pitch-point eraser (drag started ON a pitch point): vertical-line
        // sweep — as you right-click-drag, ANY point whose X falls inside the
        // drag window is erased (no vertical restriction), so the whole curve
        // height is swept point by point, exactly like the original behavior.
        if (eraseIsPitchContext && showPitchEnvelopes)
        {
            const juce::ScopedLock sl (processor.noteLock);
            for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
                auto& note = processor.notes[i];
                auto rect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);
                float noteLength = juce::jmax(0.0001f, note.lengthBeats);

                // iterate backwards so erasing doesn't shift remaining indices we need to check
                for (int j = (int)note.pitchCurve.size() - 1; j >= 0; --j) {
                    if (note.pitchCurve[j].x < -0.0001f || note.pitchCurve[j].x > noteLength + 0.0001f)
                        continue;
                    float px = rect.getX() + (note.pitchCurve[j].x / noteLength) * rect.getWidth();

                    float minX = std::min(oldDragPos.x, e.x) - 15.0f;
                    float maxX = std::max(oldDragPos.x, e.x) + 15.0f;

                    if (px >= minX && px <= maxX) {

                        // The very first anchor node (index 0) can't be
                        // deleted — but erasing it resets any bend it holds
                        // back to the note's root pitch. If it's already at
                        // root, leave it untouched.
                        if (j == 0)
                        {
                            if (std::abs(note.pitchCurve[j].y) > 0.0001f)
                            {
                                if (!undoStateSavedForDrag) {
                                    saveUndoState();
                                    undoStateSavedForDrag = true;
                                }
                                note.pitchCurve[j].y = 0.0f;
                                repaintPitchEditArea(note);
                            }
                            continue;
                        }

                        // don't save undo state for every single point deleted during a drag, just the first
                        if (!undoStateSavedForDrag) {
                            saveUndoState();
                            undoStateSavedForDrag = true;
                        }
                        note.pitchCurve.erase(note.pitchCurve.begin() + j);

                        // We might have deleted the node we were editing
                        if (editingPitchCurveNoteIndex == i && editingPitchCurveNodeIndex == j) {
                            editingPitchCurveNodeIndex = -1; editingPitchCurveTensionNodeIndex = -1;
                        }

                        repaintPitchEditArea(note);
                    }
                }
            }
            return;
        }

        // Note eraser (drag started on empty space or on a note)
        const juce::ScopedLock sl (processor.noteLock);
        bool erasedAny = false;
        
        for (int i = (int)processor.notes.size() - 1; i >= 0; --i)
        {
            auto rect = getNoteRectGridSpace(processor.notes[i].midiNote, processor.notes[i].startBeat, processor.notes[i].lengthBeats);
            rect.translate((float)keysWidth - viewX, (float)topOffset - viewY);

            if (rect.contains(e.getPosition().toFloat()))
            {
                if (!undoStateSavedForDrag) {
                    saveUndoState();
                    undoStateSavedForDrag = true;
                }
                processor.notes.erase(processor.notes.begin() + i);
                erasedAny = true;
            }
        }
        if (erasedAny) repaint();
        return;
    }

    if (draggingNoteIndex >= 0 && draggingNoteIndex < processor.notes.size())
    {
        if (!undoStateSavedForDrag) {
            saveUndoState();
            undoStateSavedForDrag = true;
        }

        const juce::ScopedLock sl (processor.noteLock);
        
        bool isShiftDown = e.mods.isShiftDown();
        if (currentDragAction == Move && isShiftDown != wasShiftDownDuringDrag) {
            dragStartPos = e.getPosition();
            for (auto& state : selectedNotesDragState) {
                if (state.index >= 0 && state.index < processor.notes.size()) {
                    auto& note = processor.notes[state.index];
                    state.originalStartBeat = note.startBeat;
                    state.originalLengthBeats = note.lengthBeats;
                    state.originalMidiNote = note.midiNote;
                    state.originalVelocity = note.velocity;
                }
            }
            wasShiftDownDuringDrag = isShiftDown;
        }
        
        float deltaBeats = (float)(e.x - dragStartPos.x) / pixelsPerBeat;
        float snap = getCurrentGridSnap();
        float snappedDeltaBeats = std::round(deltaBeats / snap) * snap;
        int deltaRows = std::round((float)(e.y - dragStartPos.y) / keyHeight);
        
        int deltaVel = 0;
        float lengthDelta = 0.0f;
        
        bool moveWithShiftStretch = (currentDragAction == Move && e.mods.isShiftDown());
        
        if (currentDragAction == Move) {
            float minStartBeat = std::numeric_limits<float>::max();
            int minMidiNote = 127;
            int maxMidiNote = 0;
            
            for (const auto& state : selectedNotesDragState) {
                if (state.originalStartBeat < minStartBeat) minStartBeat = state.originalStartBeat;
                if (state.originalMidiNote < minMidiNote) minMidiNote = state.originalMidiNote;
                if (state.originalMidiNote > maxMidiNote) maxMidiNote = state.originalMidiNote;
            }
            
            if (currentDragAction == Move && minStartBeat + snappedDeltaBeats < 0.0f) {
                snappedDeltaBeats = -minStartBeat;
            }
            
            deltaRows = juce::jlimit(maxMidiNote - 127, minMidiNote, deltaRows);
        }
        
        if (currentDragAction == ResizeRight || moveWithShiftStretch) {
            float draggingNoteOrigStart = 0.0f;
            float draggingNoteOrigLength = snap;
            for (const auto& state : selectedNotesDragState) {
                if (state.index == draggingNoteIndex) {
                    draggingNoteOrigStart = state.originalStartBeat;
                    draggingNoteOrigLength = state.originalLengthBeats;
                    break;
                }
            }
            float currentMouseBeat = screenToBeat(e.x);
            float snappedMouseBeat = std::round(currentMouseBeat / snap) * snap;
            float draggingNoteNewLength = juce::jmax(snap, snappedMouseBeat - draggingNoteOrigStart);
            lengthDelta = draggingNoteNewLength - draggingNoteOrigLength;
        }
        else if (currentDragAction == EditVelocity)
        {
            // Velocity values are applied by the cursor sweep below: every
            // bar the mouse passes over jumps to the cursor's position.
        }
        
        for (const auto& state : selectedNotesDragState) {
            if (state.index >= processor.notes.size()) continue;
            auto& note = processor.notes[state.index];
            
            if (currentDragAction == Move)
            {
                if (moveWithShiftStretch) {
                    note.startBeat = state.originalStartBeat; // Keep start fixed
                    note.lengthBeats = juce::jmax(snap, state.originalLengthBeats + lengthDelta);
                } else {
                    note.startBeat = state.originalStartBeat + snappedDeltaBeats;
                    
                    int newPitch = state.originalMidiNote - deltaRows;
                    if (isScaleLockActive) {
                        newPitch = snapNoteToScale(newPitch, scaleRoot, scaleType);
                    }
                    note.midiNote = juce::jlimit(0, 127, newPitch);
                }
            }
            else if (currentDragAction == ResizeRight)
            {
                note.lengthBeats = juce::jmax(snap, state.originalLengthBeats + lengthDelta);
            }
        }

        // Velocity sweep: while dragging in the velocity lane, EVERY bar the
        // mouse cursor passes over jumps to the cursor's vertical position
        // (top = 127, bottom = ~1). Bars the cursor is not over stay
        // untouched, so you can paint velocities by sweeping across the lane.
        if (currentDragAction == EditVelocity)
        {
            const float velYf = (float)(getHeight() - velocityLaneHeight);
            const float velH = (float)(velocityLaneHeight - 10);
            velAtCursor = juce::jlimit(1.0f, 127.0f,
                                       ((float)velocityLaneHeight - (e.y - velYf)) / velH * 127.0f);
            const int newVel = (int)std::lround(velAtCursor);
            const float hitTolerance = 6.0f;
            const float cullStartBeat = juce::jmax(0.0f, viewX / pixelsPerBeat);
            const float cullEndBeat = (viewX + (float)getWidth()) / pixelsPerBeat;
            for (int i = (int)processor.notes.size() - 1; i >= 0; --i)
            {
                auto& n = processor.notes[i];
                if (n.startBeat > cullEndBeat || (n.startBeat + n.lengthBeats) < cullStartBeat) continue;
                const float barX = (float)keysWidth - viewX + (n.startBeat * pixelsPerBeat);
                const float barW = juce::jlimit(4.0f, 12.0f, n.lengthBeats * pixelsPerBeat * 0.28f);
                if (e.x < (barX - barW * 0.5f - hitTolerance) || e.x > (barX + barW * 0.5f + hitTolerance))
                    continue; // bar not under the cursor — leave it alone
                n.velocity = (juce::uint8)juce::jlimit(1, 127, newVel);
            }
        }
        
        if (currentDragAction == Move) {
             previewNoteOn(processor.notes[draggingNoteIndex].midiNote);
        }
        
        repaint();
    }
}

void PianoRollComponent::mouseUp (const juce::MouseEvent& e)
{
    const bool wasPanning = isPanning;
    isDraggingMidiButton = false;
    isDraggingVelLaneDivider = false;
    eraseIsPitchContext = false; // end the right-click eraser drag
    stopPitchPreview(); // stop the looping slide preview when the drag ends
    isDraggingPitchGroup = false; // end any pitch-node group drag
    // Don't reset the note index so the envelope stays visible!
    editingPitchCurveNodeIndex = -1; editingPitchCurveTensionNodeIndex = -1;

    if (isResizingRazor) {
        isResizingRazor = false;
        razorResizeMode = 0;
        markPersistentEditorStateChanged();
        processor.updateHostDisplay();
        return;
    }

    if (isStretchingRazor) {
        isStretchingRazor = false;
        razorStretchEdge = 0;
        razorDragOriginalNotes.clear();
        markPersistentEditorStateChanged();
        processor.updateHostDisplay();
        return;
    }

    if (isRazorSelecting) {
        isRazorSelecting = false;
        return;
    }

    // Pitch-node marquee: resolve the selection on release.
    if (isMarqueeSelectingPitch) {
        isMarqueeSelectingPitch = false;
        if (pitchMarqueeCurrent.getDistanceFrom(pitchMarqueeStart) < 3)
        {
            // Plain Ctrl+click: select the single node under the cursor,
            // or clear the selection if empty space was clicked.
            int n = -1, nd = -1;
            if (findPitchNodeAtMouse(n, nd))
            {
                selectedPitchNodes.clear();
                selectedPitchNodes.push_back({ n, nd });
            }
            else
            {
                selectedPitchNodes.clear();
            }
        }
        repaint();
        return;
    }
    
    if (isMarqueeSelecting) {
        isMarqueeSelecting = false;

        // A plain click (no drag) on empty space deselects everything,
        // unless a modifier key was held.
        if (marqueeCurrentPos.getDistanceFrom(marqueeStartPos) < 3
            && !e.mods.isCommandDown() && !e.mods.isCtrlDown() && !e.mods.isShiftDown())
        {
            const juce::ScopedLock sl(processor.noteLock);
            for (auto& n : processor.notes) n.selected = false;
            processor.notesRevision.fetch_add(1); // selection is part of the paint cache
        }

        preMarqueeSelection.clear();
        repaint();
        return;
    }
    
    isPanning = false;
    if (wasPanning)
        markPersistentEditorStateChanged();

    if (draggingNoteIndex >= 0 && draggingNoteIndex < processor.notes.size()) {
        lastNoteLength = processor.notes[draggingNoteIndex].lengthBeats;
        processor.notesRevision.fetch_add(1); // move/resize/velocity drag finished
    }

    showDragGhost = false;
    wasNewNoteDrag = false;
    draggingNoteIndex = -1;
    currentDragAction = None;
    previewNoteOff();
    repaint(); // drop the drag-preview ghost (and show the placement flash) immediately
}

bool PianoRollComponent::keyPressed(const juce::KeyPress& key)
{
    // Ctrl+arrows: nudge the selection in time; Alt+arrows: transpose by
    // half-steps. Works on all selected notes.
    {
        const bool ctrl = key.getModifiers().isCtrlDown();
        const bool alt = key.getModifiers().isAltDown();
        const int kc = key.getKeyCode();
        const bool isArrow = (kc == juce::KeyPress::leftKey || kc == juce::KeyPress::rightKey
                           || kc == juce::KeyPress::upKey || kc == juce::KeyPress::downKey);
        if (isArrow && (ctrl || alt))
        {
            bool anySelected = false;
            {
                const juce::ScopedLock sl(processor.noteLock);
                for (const auto& n : processor.notes) if (n.selected) { anySelected = true; break; }
            }
            if (!anySelected)
                return false;

            saveUndoState();

            const float snap = getCurrentGridSnap();
            const juce::ScopedLock sl(processor.noteLock);
            if (ctrl && (kc == juce::KeyPress::leftKey || kc == juce::KeyPress::rightKey))
            {
                const float dir = (kc == juce::KeyPress::rightKey) ? snap : -snap;
                for (auto& n : processor.notes)
                    if (n.selected) n.startBeat = juce::jmax(0.0f, n.startBeat + dir);
            }
            else if (alt && (kc == juce::KeyPress::upKey || kc == juce::KeyPress::downKey))
            {
                const int dir = (kc == juce::KeyPress::upKey) ? 1 : -1;
                for (auto& n : processor.notes)
                    if (n.selected) n.midiNote = juce::jlimit(0, 127, n.midiNote + dir);
            }
            else
                return false;

            processor.notesRevision.fetch_add(1);
            repaint();
            markPersistentEditorStateChanged();
            return true;
        }
    }

    if (key.getKeyCode() == 'e' || key.getKeyCode() == 'E' || key.getTextCharacter() == '\\' || key.getKeyCode() == '\\')
    {
        showPitchEnvelopes = !showPitchEnvelopes;
        if (showPitchEnvelopes) {
            editingPitchCurveNoteIndex = -1;
            for (int i = 0; i < (int)processor.notes.size(); ++i) {
                if (processor.notes[i].selected) {
                    editingPitchCurveNoteIndex = i;
                    break;
                }
            }
        } else {
            editingPitchCurveNoteIndex = -1;
        }
        editingPitchCurveNodeIndex = -1; editingPitchCurveTensionNodeIndex = -1;
        markPersistentEditorStateChanged();
        repaint();
        return true;
    }

    if ((key.getTextCharacter() == 'd' || key.getTextCharacter() == 'D') && hasRazorSelection)
    {
        float deltaBeat = razorEndBeat - razorStartBeat;
        if (deltaBeat <= 0) return true;

        float newStartBeat = razorStartBeat + deltaBeat;
        float newEndBeat = razorEndBeat + deltaBeat;

        saveUndoState();
        const juce::ScopedLock sl(processor.noteLock);

        std::vector<NoteEvent> notesToCopy;
        for (const auto& note : processor.notes) {
            if (note.startBeat < razorEndBeat && (note.startBeat + note.lengthBeats) > razorStartBeat &&
                note.midiNote >= razorBottomNote && note.midiNote <= razorTopNote) 
            {
                float sliceStart = juce::jmax(note.startBeat, razorStartBeat);
                float sliceEnd = juce::jmin(note.startBeat + note.lengthBeats, razorEndBeat);
                
                if (sliceEnd > sliceStart) {
                    NoteEvent copyNote = note;
                    copyNote.startBeat = sliceStart;
                    copyNote.lengthBeats = sliceEnd - sliceStart;
                    if (showPitchEnvelopes)
                    {
                        // Pitch mode: carry only the pitch nodes inside the
                        // razor area, remapped to the copy's coordinates.
                        copyNote.pitchCurve.clear();
                        const float relStart = sliceStart - note.startBeat;
                        const float relEnd = sliceEnd - note.startBeat;
                        for (const auto& p : note.pitchCurve)
                        {
                            if (p.x >= relStart - 0.0001f && p.x <= relEnd + 0.0001f)
                            {
                                PitchNode shifted = p;
                                shifted.x = juce::jlimit(0.0f, copyNote.lengthBeats, p.x - relStart);
                                copyNote.pitchCurve.push_back(shifted);
                            }
                        }
                    }
                    notesToCopy.push_back(copyNote);
                }
            }
        }

        std::vector<NoteEvent> newNotes;
        for (auto& note : processor.notes) {
            bool inPitchRange = (note.midiNote >= razorBottomNote && note.midiNote <= razorTopNote);
            if (!inPitchRange) {
                newNotes.push_back(note);
                continue;
            }
            
            float noteEnd = note.startBeat + note.lengthBeats;
            bool overlapsDest = (note.startBeat < newEndBeat && noteEnd > newStartBeat);
            
            if (!overlapsDest) {
                newNotes.push_back(note);
            } else {
                if (note.startBeat < newStartBeat) {
                    NoteEvent leftPart = note;
                    leftPart.lengthBeats = newStartBeat - note.startBeat;
                    if (leftPart.lengthBeats > 0.001f) newNotes.push_back(leftPart);
                }
                if (noteEnd > newEndBeat) {
                    NoteEvent rightPart = note;
                    rightPart.startBeat = newEndBeat;
                    rightPart.lengthBeats = noteEnd - newEndBeat;
                    if (rightPart.lengthBeats > 0.001f) newNotes.push_back(rightPart);
                }
            }
        }

        for (auto& note : notesToCopy) {
            note.startBeat += deltaBeat;
            newNotes.push_back(note);
        }
        
        processor.notes = newNotes;

        razorStartBeat = newStartBeat;
        razorEndBeat = newEndBeat;

        repaint();
        return true; 
    }

    if ((key.getKeyCode() == 'a' || key.getKeyCode() == 'A') && (key.getModifiers().isCommandDown() || key.getModifiers().isCtrlDown()))
    {
        const juce::ScopedLock sl(processor.noteLock);
        for (auto& n : processor.notes) {
            n.selected = true;
        }
        processor.notesRevision.fetch_add(1); // selection is part of the paint cache
        repaint();
        return true;
    }

    if ((key.getKeyCode() == 'c' || key.getKeyCode() == 'C') && (key.getModifiers().isCommandDown() || key.getModifiers().isCtrlDown()))
    {
        clipboardNotes.clear();
        const juce::ScopedLock sl(processor.noteLock);
        for (const auto& n : processor.notes) {
            if (n.selected) clipboardNotes.push_back(n);
        }
        return true;
    }

    // Plain 'C' on a pitch node: select the node under the cursor and show a
    // curve-shape menu (slide up/down, tension, delete) applied to that point.
    if (key.getKeyCode() == 'C' && !key.getModifiers().isCommandDown()
        && !key.getModifiers().isCtrlDown() && !key.getModifiers().isAltDown()
        && !key.getModifiers().isShiftDown())
    {
        int noteIndex = -1, nodeIndex = -1;
        if (showPitchEnvelopes && findPitchNodeAtMouse(noteIndex, nodeIndex))
        {
            showPitchNodeShapeMenu(noteIndex, nodeIndex);
            return true;
        }
        return false; // no pitch node under the cursor
    }

    // Plain 'F': zoom to fit all notes.
    if (key.getKeyCode() == 'F' && !key.getModifiers().isCommandDown()
        && !key.getModifiers().isCtrlDown() && !key.getModifiers().isAltDown()
        && !key.getModifiers().isShiftDown())
    {
        const juce::ScopedLock sl(processor.noteLock);
        if (processor.notes.empty())
            return true;

        float minBeat = 1e9f, maxBeat = -1e9f;
        int minNote = 127, maxNote = 0;
        for (const auto& n : processor.notes)
        {
            minBeat = juce::jmin(minBeat, n.startBeat);
            maxBeat = juce::jmax(maxBeat, n.startBeat + n.lengthBeats);
            minNote = juce::jmin(minNote, n.midiNote);
            maxNote = juce::jmax(maxNote, n.midiNote);
        }

        const int topOffset = rulerHeight + toolbarHeight;
        const int bottomOffset = showVelocityLane ? velocityLaneHeight : 0;
        const float availW = juce::jmax(100.0f, (float)(getWidth() - keysWidth - 20));
        const float availH = juce::jmax(60.0f, (float)(getHeight() - topOffset - bottomOffset - 20));
        const float beatSpan = juce::jmax(1.0f, maxBeat - minBeat);
        const float keySpan = juce::jmax(1.0f, (float)(maxNote - minNote + 1));

        pixelsPerBeat = juce::jlimit(1.0f, 100.0f, availW / (beatSpan * 1.1f));
        keyHeight = juce::jlimit(4.0f, 80.0f, availH / (keySpan * 1.1f));
        viewX = juce::jmax(0.0f, minBeat * pixelsPerBeat - 10.0f);
        viewY = juce::jmax(0.0f, (float)(127 - maxNote) * keyHeight - 10.0f);
        repaint();
        return true;
    }

    if ((key.getKeyCode() == 'x' || key.getKeyCode() == 'X') && (key.getModifiers().isCommandDown() || key.getModifiers().isCtrlDown()))
    {
        clipboardNotes.clear();
        saveUndoState();
        const juce::ScopedLock sl(processor.noteLock);
        bool deletedAny = false;
        for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
            if (processor.notes[i].selected) {
                clipboardNotes.push_back(processor.notes[i]);
                processor.notes.erase(processor.notes.begin() + i);
                deletedAny = true;
            }
        }
        if (deletedAny) repaint();
        return true;
    }

    if ((key.getKeyCode() == 'v' || key.getKeyCode() == 'V') && (key.getModifiers().isCommandDown() || key.getModifiers().isCtrlDown()))
    {
        if (clipboardNotes.empty()) return true;

        saveUndoState();
        const juce::ScopedLock sl(processor.noteLock);

        float minStartBeat = std::numeric_limits<float>::max();
        int maxMidiNote = -1;
        for (const auto& n : clipboardNotes) {
            if (n.startBeat < minStartBeat) minStartBeat = n.startBeat;
            if (n.midiNote > maxMidiNote) maxMidiNote = n.midiNote;
        }

        auto mousePos = getMouseXYRelative();
        float pasteBeat = screenToBeat(mousePos.x);
        int pasteNote = screenToNote(mousePos.y);

        float beatOffset = pasteBeat - minStartBeat;
        float snap = getCurrentGridSnap();
        beatOffset = std::round(beatOffset / snap) * snap;

        int noteOffset = pasteNote - maxMidiNote;

        for (auto& n : processor.notes) n.selected = false;

        for (const auto& n : clipboardNotes) {
            NoteEvent newNote = n;
            newNote.startBeat = juce::jmax(0.0f, newNote.startBeat + beatOffset);
            newNote.midiNote = juce::jlimit(0, 127, newNote.midiNote + noteOffset);
            newNote.selected = true;
            processor.notes.push_back(newNote);
        }
        if (showPitchEnvelopes)
            ensurePitchStartPoints(); // pasted notes without curves get the start point
        repaint();
        return true;
    }

    if (key.getKeyCode() == juce::KeyPress::deleteKey || key.getKeyCode() == juce::KeyPress::backspaceKey)
    {
        // In pitch mode with marquee-selected pitch nodes, Delete removes the
        // selected nodes (instead of the notes themselves).
        if (showPitchEnvelopes && !selectedPitchNodes.empty())
        {
            saveUndoState();
            {
                const juce::ScopedLock sl(processor.noteLock);
                std::vector<int> notesToClean;
                for (const auto& sel : selectedPitchNodes)
                    if (sel.first >= 0 && sel.first < (int)processor.notes.size())
                        if (std::find(notesToClean.begin(), notesToClean.end(), sel.first) == notesToClean.end())
                            notesToClean.push_back(sel.first);

                for (int noteIdx : notesToClean)
                {
                    auto& curve = processor.notes[noteIdx].pitchCurve;
                    std::vector<int> toErase;
                    for (const auto& sel : selectedPitchNodes)
                        if (sel.first == noteIdx && sel.second >= 0 && sel.second < (int)curve.size())
                            toErase.push_back(sel.second);
                    std::sort(toErase.begin(), toErase.end(), [](int a, int b) { return a > b; });
                    for (int nodeIdx : toErase)
                        curve.erase(curve.begin() + nodeIdx);
                }
            }
            selectedPitchNodes.clear();
            processor.notesRevision.fetch_add(1);
            repaint();
            return true;
        }

        saveUndoState();
        const juce::ScopedLock sl(processor.noteLock);
        bool deletedAny = false;
        for (int i = (int)processor.notes.size() - 1; i >= 0; --i) {
            if (processor.notes[i].selected) {
                processor.notes.erase(processor.notes.begin() + i);
                deletedAny = true;
            }
        }
        if (deletedAny) {
            repaint();
            return true;
        }
    }

    // Ctrl+Z / Cmd+Z = undo; Ctrl+Shift+Z / Cmd+Shift+Z = redo.
    if (key.getKeyCode() == 'Z' && key.getModifiers().isCommandDown())
    {
        if (key.getModifiers().isShiftDown())
            performRedo();
        else
            performUndo();
        return true;
    }

    // Ctrl+Y / Cmd+Y = redo (Windows convention).
    if (key.getKeyCode() == 'Y' && key.getModifiers().isCommandDown())
    {
        performRedo();
        return true;
    }

    return false;
}

void PianoRollComponent::saveUndoState(bool allowMerge)
{
    const juce::uint32 now = juce::Time::getMillisecondCounter();
    // Rapid successive saves (keyboard bursts such as nudges, deletes or
    // velocity clicks) collapse into a single undo step — but only within a
    // short window, and only when the caller allows it (note drags opt out so
    // every drag is its own undo step).
    const bool shouldMerge = allowMerge && !undoHistory.empty() && (now - lastUndoSaveTime) < 250u;
    {
        const juce::ScopedLock sl(processor.noteLock);
        NoteEditUndoState snapshot;
        snapshot.notes = processor.notes;
        snapshot.hasRazor = hasRazorSelection;
        snapshot.razorStart = razorStartBeat;
        snapshot.razorEnd = razorEndBeat;
        snapshot.razorTop = razorTopNote;
        snapshot.razorBottom = razorBottomNote;
        snapshot.gridDivisorIndex = currentGridDivisorIndex;
        snapshot.themeIndex = currentThemeIndex;
        if (shouldMerge)
            undoHistory.back() = snapshot;
        else
            undoHistory.push_back(snapshot);
        if (undoHistory.size() > 50) {
            undoHistory.erase(undoHistory.begin());
        }
        redoHistory.clear();
    }
    lastUndoSaveTime = now;
    processor.notesRevision.fetch_add(1);

    processor.updateHostDisplay();
}

void PianoRollComponent::performUndo()
{
    bool changed = false;
    {
        const juce::ScopedLock sl(processor.noteLock);
        if (!undoHistory.empty()) {
            redoHistory.push_back({ processor.notes, hasRazorSelection, razorStartBeat, razorEndBeat, razorTopNote, razorBottomNote, currentGridDivisorIndex, currentThemeIndex });
            processor.notes = undoHistory.back().notes;
            hasRazorSelection = undoHistory.back().hasRazor;
            razorStartBeat = undoHistory.back().razorStart;
            razorEndBeat = undoHistory.back().razorEnd;
            razorTopNote = undoHistory.back().razorTop;
            razorBottomNote = undoHistory.back().razorBottom;
            currentGridDivisorIndex = undoHistory.back().gridDivisorIndex;
            currentThemeIndex = undoHistory.back().themeIndex;
            undoHistory.pop_back();
            changed = true;
        }
    }

    if (changed) {
        processor.notesRevision.fetch_add(1);
        processor.pianoRollGridDivisorIndex.store(currentGridDivisorIndex);
        processor.pianoRollThemeIndex.store(currentThemeIndex);
        themeCombo.setSelectedId(currentThemeIndex + 1, juce::dontSendNotification);
        markPersistentEditorStateChanged();
        processor.updateHostDisplay();
        repaint();
    }
}

void PianoRollComponent::performRedo()
{
    bool changed = false;
    {
        const juce::ScopedLock sl(processor.noteLock);
        if (!redoHistory.empty()) {
            undoHistory.push_back({ processor.notes, hasRazorSelection, razorStartBeat, razorEndBeat, razorTopNote, razorBottomNote, currentGridDivisorIndex, currentThemeIndex });
            processor.notes = redoHistory.back().notes;
            hasRazorSelection = redoHistory.back().hasRazor;
            razorStartBeat = redoHistory.back().razorStart;
            razorEndBeat = redoHistory.back().razorEnd;
            razorTopNote = redoHistory.back().razorTop;
            razorBottomNote = redoHistory.back().razorBottom;
            currentGridDivisorIndex = redoHistory.back().gridDivisorIndex;
            currentThemeIndex = redoHistory.back().themeIndex;
            redoHistory.pop_back();
            changed = true;
        }
    }

    if (changed) {
        processor.notesRevision.fetch_add(1);
        processor.pianoRollGridDivisorIndex.store(currentGridDivisorIndex);
        processor.pianoRollThemeIndex.store(currentThemeIndex);
        themeCombo.setSelectedId(currentThemeIndex + 1, juce::dontSendNotification);
        markPersistentEditorStateChanged();
        processor.updateHostDisplay();
        repaint();
    }
}

float PianoRollComponent::quantizeToScale(int currentMidiNote, float bendY, bool ignoreLock) const {
    if (!isScaleLockActive && !ignoreLock) return bendY;
    int targetMidi = currentMidiNote + (int)std::round(bendY);
    int octave = targetMidi / 12;
    int noteInOctave = targetMidi % 12;
    
    const auto& intervals = scaleIntervals[scaleType];
    
    int closestNote = -1;
    int minDistance = 1000;
    
    for (int interval : intervals) {
        int scaleNote = (scaleRoot + interval) % 12;
        int distance = std::abs(noteInOctave - scaleNote);
        if (distance > 6) distance = 12 - distance;
        
        if (distance < minDistance) {
            minDistance = distance;
            closestNote = scaleNote;
        }
    }
    
    // Compute the actual quantized midi note
    int quantizedMidi = (octave * 12) + closestNote;
    
    // Handle wrap around if closest was in another octave
    if (std::abs(quantizedMidi - targetMidi) > 6) {
        if (quantizedMidi < targetMidi) quantizedMidi += 12;
        else quantizedMidi -= 12;
    }
    
    return (float)(quantizedMidi - currentMidiNote);
}

void PianoRollComponent::snapToScaleAction(int action)
{
    // 200 = snap selected note pitches, 201 = selected notes' bend nodes,
    // 202 = ALL notes' bend nodes. Uses the CURRENT root/scale even when
    // scale lock is off (explicit menu action).
    if (action != 200 && action != 201 && action != 202)
        return;

    saveUndoState();

    const juce::ScopedLock sl(processor.noteLock);
    bool anyChange = false;

    for (auto& note : processor.notes)
    {
        const bool isTarget = (action == 202) || note.selected;
        if (!isTarget)
            continue;

        if (action == 200)
        {
            // Snap the note's pitch to the nearest scale degree.
            const int offset = (int)std::lround(quantizeToScale(note.midiNote, 0.0f, true));
            if (offset != 0)
            {
                note.midiNote = juce::jlimit(0, 127, note.midiNote + offset);
                anyChange = true;
            }
        }
        else
        {
            // Snap every drawn bend node's amount onto the scale.
            for (auto& p : note.pitchCurve)
            {
                const float snapped = quantizeToScale(note.midiNote, p.y, true);
                if (std::abs(snapped - p.y) > 0.001f)
                {
                    p.y = snapped;
                    anyChange = true;
                }
            }
        }
    }

    if (anyChange)
    {
        processor.notesRevision.fetch_add(1);
        repaint();
        markPersistentEditorStateChanged();
    }
}

bool PianoRollComponent::isPitchNodeSelected(int noteIndex, int nodeIndex) const
{
    for (const auto& sel : selectedPitchNodes)
        if (sel.first == noteIndex && sel.second == nodeIndex)
            return true;
    return false;
}

bool PianoRollComponent::findPitchNodeAtMouse(int& outNoteIndex, int& outNodeIndex) const
{
    if (!showPitchEnvelopes)
        return false;

    const juce::Point<int> mousePos = getMouseXYRelative();
    const float s = pitchNodeSize / 6.2f;
    const float hitR = 7.0f * s + 3.0f; // generous grab radius around the node

    const float range = (float)juce::jmax(1, processor.pitchBendRange.load());

    const juce::ScopedLock sl(processor.noteLock);
    for (int i = (int)processor.notes.size() - 1; i >= 0; --i)
    {
        const auto& note = processor.notes[i];
        const float noteLength = juce::jmax(0.0001f, note.lengthBeats);

        // Same on-screen mapping the pitch-curve renderer uses in paint().
        auto noteRect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
        noteRect.translate((float)keysWidth - viewX, (float)(rulerHeight + toolbarHeight) - viewY);
        const float cy = noteRect.getCentreY();

        for (size_t j = 0; j < note.pitchCurve.size(); ++j)
        {
            if (note.pitchCurve[j].x < -0.0001f || note.pitchCurve[j].x > noteLength + 0.0001f)
                continue;
            const float px = noteRect.getX() + (juce::jlimit(0.0f, noteLength, note.pitchCurve[j].x) / noteLength) * noteRect.getWidth();
            const float py = cy - (juce::jlimit(-range, range, note.pitchCurve[j].y) * keyHeight);
            if (std::abs(px - (float)mousePos.x) <= hitR && std::abs(py - (float)mousePos.y) <= hitR)
            {
                outNoteIndex = i;
                outNodeIndex = (int)j;
                return true;
            }
        }
    }
    return false;
}

void PianoRollComponent::showPitchNodeShapeMenu(int noteIndex, int nodeIndex)
{
    if (noteIndex < 0 || noteIndex >= (int)processor.notes.size())
        return;

    juce::PopupMenu menu;
    menu.setLookAndFeel(&webDAWMenuLAF());
    menu.addSectionHeader("Pitch Segment Shape");

    menu.addItem(1, "Linear");
    menu.addItem(2, "Square (step)");
    menu.addItem(3, "Smooth");
    menu.addItem(4, "Ease In");
    menu.addItem(5, "Ease Out");
    menu.addItem(6, "Sine");
    menu.addItem(7, "Auto (tension)");
    menu.addSeparator();

    juce::PopupMenu tensionMenu;
    tensionMenu.setLookAndFeel(&webDAWMenuLAF());
    tensionMenu.addItem(8, "Soft (0.0)");
    tensionMenu.addItem(9, "Medium (0.4)");
    tensionMenu.addItem(10, "Strong (1.0)");
    tensionMenu.addItem(13, "Extreme (2.0)");
    menu.addSubMenu("Tension", tensionMenu);

    menu.addSeparator();
    menu.addSectionHeader("Apply to whole curve");
    menu.addItem(21, "Whole curve: Linear");
    menu.addItem(22, "Whole curve: Square");
    menu.addItem(23, "Whole curve: Smooth");
    menu.addItem(24, "Whole curve: Ease In");
    menu.addItem(25, "Whole curve: Ease Out");
    menu.addItem(26, "Whole curve: Sine");
    menu.addItem(27, "Whole curve: Auto");
    menu.addItem(28, "Whole curve: Reset bends to 0");

    menu.addSeparator();
    menu.addItem(11, "Straighten this point");
    menu.addItem(12, "Delete this point");

    // Anchor the menu right at the selected pitch node.
    juce::Point<int> menuAnchor (getWidth() / 2, getHeight() / 2);
    {
        const juce::ScopedLock sl(processor.noteLock);
        if (noteIndex >= 0 && noteIndex < (int)processor.notes.size())
        {
            const auto& note = processor.notes[noteIndex];
            if (nodeIndex >= 0 && nodeIndex < (int)note.pitchCurve.size())
            {
                const float noteLength = juce::jmax(0.0001f, note.lengthBeats);
                const float range = (float)juce::jmax(1, processor.pitchBendRange.load());
                auto noteRect = getNoteRectGridSpace(note.midiNote, note.startBeat, note.lengthBeats);
                noteRect.translate((float)keysWidth - viewX, (float)(rulerHeight + toolbarHeight) - viewY);
                const float px = noteRect.getX()
                    + (juce::jlimit(0.0f, noteLength, note.pitchCurve[nodeIndex].x) / noteLength) * noteRect.getWidth();
                const float py = noteRect.getCentreY()
                    - (juce::jlimit(-range, range, note.pitchCurve[nodeIndex].y) * keyHeight);
                menuAnchor = localPointToGlobal (juce::Point<int> ((int)px, (int)py));
            }
        }
    }

    menu.showMenuAsync(juce::PopupMenu::Options()
        .withTargetComponent(this)
        .withTargetScreenArea (juce::Rectangle<int> (menuAnchor.x - 1, menuAnchor.y - 1, 2, 2))
        .withMinimumWidth(240),
        [this, noteIndex, nodeIndex] (int result)
        {
            if (result == 0)
                return;

            // Apply to every marquee-selected node when several are selected,
            // otherwise just the hovered node.
            std::vector<std::pair<int,int>> targets;
            if (selectedPitchNodes.size() > 1)
                targets = selectedPitchNodes;
            else
                targets.push_back({ noteIndex, nodeIndex });

            juce::ScopedLock sl(processor.noteLock);

            // Whole-curve items apply per note (deduplicate).
            if (result == 28) // Reset all bends of the curve to 0
            {
                std::vector<int> notesToApply;
                for (const auto& t : targets)
                    if (t.first >= 0 && t.first < (int)processor.notes.size())
                        if (std::find(notesToApply.begin(), notesToApply.end(), t.first) == notesToApply.end())
                            notesToApply.push_back(t.first);
                saveUndoState();
                for (int ni : notesToApply)
                    for (auto& p : processor.notes[ni].pitchCurve)
                        p.y = 0.0f;
                processor.notesRevision.fetch_add(1);
                repaint();
                return;
            }

            if (result >= 21 && result <= 27)
            {
                std::vector<int> notesToApply;
                for (const auto& t : targets)
                    if (t.first >= 0 && t.first < (int)processor.notes.size())
                        if (std::find(notesToApply.begin(), notesToApply.end(), t.first) == notesToApply.end())
                            notesToApply.push_back(t.first);
                saveUndoState();
                const int wholeShape = (result == 27) ? 0 : (result - 20);
                for (int ni : notesToApply)
                    for (auto& p : processor.notes[ni].pitchCurve)
                        p.shape = wholeShape;
                processor.notesRevision.fetch_add(1);
                repaint();
                return;
            }

            // Delete: collect nodes per note, erase in descending order.
            if (result == 12)
            {
                saveUndoState();
                std::vector<int> notesToClean;
                for (const auto& t : targets)
                    if (t.first >= 0 && t.first < (int)processor.notes.size())
                        if (std::find(notesToClean.begin(), notesToClean.end(), t.first) == notesToClean.end())
                            notesToClean.push_back(t.first);
                for (int ni : notesToClean)
                {
                    auto& curve = processor.notes[ni].pitchCurve;
                    std::vector<int> toErase;
                    for (const auto& t : targets)
                        if (t.first == ni && t.second >= 0 && t.second < (int)curve.size())
                            toErase.push_back(t.second);
                    std::sort(toErase.begin(), toErase.end(), [](int a, int b) { return a > b; });
                    for (int nodeToErase : toErase)
                        curve.erase(curve.begin() + nodeToErase);
                }
                processor.notesRevision.fetch_add(1);
                repaint();
                return;
            }

            // Per-node operations applied to every target.
            saveUndoState();
            bool first = true;
            for (const auto& t : targets)
            {
                if (t.first < 0 || t.first >= (int)processor.notes.size())
                    continue;
                if (t.second < 0 || t.second >= (int)processor.notes[t.first].pitchCurve.size())
                    continue;

                auto& node = processor.notes[t.first].pitchCurve[t.second];
                switch (result)
                {
                    case 1: node.shape = 1; break; // Linear
                    case 2: node.shape = 2; break; // Square (step)
                    case 3: node.shape = 3; break; // Smooth
                    case 4: node.shape = 4; break; // Ease In
                    case 5: node.shape = 5; break; // Ease Out
                    case 6: node.shape = 6; break; // Sine
                    case 7: node.shape = 0; break; // Auto (tension-driven)
                    case 8:  node.tension = 0.0f; break;
                    case 9:  node.tension = 0.4f; break;
                    case 10: node.tension = 1.0f; break;
                    case 13: node.tension = 2.0f; break;
                    case 11: node.y = 0.0f; node.tension = 0.0f; node.shape = 0; break;
                    default: continue;
                }

                if (first)
                {
                    // Mark the first node as the active editing node.
                    editingPitchCurveNoteIndex = t.first;
                    editingPitchCurveNodeIndex = t.second;
                    editingPitchCurveTensionNodeIndex = -1;
                    first = false;
                }
            }

            processor.notesRevision.fetch_add(1);
            repaint();
        });
}

void PianoRollComponent::exportMidiToDrag()
{
    juce::MidiMessageSequence sequence;
    std::vector<NoteEvent> notesToExport;
    const int ticksPerQuarterNote = midiExportTicksPerQuarterNote;
    const int bendRange = processor.pitchBendRange.load();
    const int shape = processor.pitchShape.load();
     
    {
        const juce::ScopedLock sl (processor.noteLock);
        notesToExport = processor.notes;
    }

    std::vector<int> noteOrder;
    noteOrder.reserve(notesToExport.size());
    for (int i = 0; i < (int)notesToExport.size(); ++i)
        noteOrder.push_back(i);

    std::sort(noteOrder.begin(), noteOrder.end(), [&] (int a, int b)
    {
        const auto& left = notesToExport[(size_t)a];
        const auto& right = notesToExport[(size_t)b];
        if (std::abs(left.startBeat - right.startBeat) > 0.0001f)
            return left.startBeat < right.startBeat;
        return left.midiNote < right.midiNote;
    });

    double channelEndBeats[15] = {}; // MPE note channels 2-16 (15 voices)

    for (int noteIndex : noteOrder)
    {
        const auto& note = notesToExport[(size_t)noteIndex];
        if (note.lengthBeats <= 0.0001f)
            continue;

        // Notes always on greedy channels 2-16 (1 stays free).
        int noteChannel = 1;
        double noteEndBeat = note.startBeat + note.lengthBeats;

        int channelIndex = 0;
        for (int c = 0; c < 15; ++c)
        {
            if (channelEndBeats[c] <= note.startBeat + 0.0001)
            {
                channelIndex = c;
                break;
            }
            if (channelEndBeats[c] < channelEndBeats[channelIndex])
                channelIndex = c;
        }
        noteChannel = channelIndex + 2;
        channelEndBeats[channelIndex] = juce::jmax(channelEndBeats[channelIndex], noteEndBeat);

        // Pitch events: shared channel 1 in Pitch Bend mode, the note's own
        // channel in MPE mode (mirrors the playback engine).
        const int wheelChannel = (processor.bendMode.load() == 1) ? noteChannel : 1;

        const double startTick = note.startBeat * ticksPerQuarterNote;
        const double endTick = noteEndBeat * ticksPerQuarterNote;

        addPitchBendRangeMessages(sequence, wheelChannel, bendRange, startTick);

        int lastPitchBend = pitchBendToMidiValue(evaluatePitchBendAtBeat(note, 0.0f, shape), bendRange);
        addSequenceEvent(sequence, juce::MidiMessage::pitchWheel(wheelChannel, lastPitchBend), startTick);

        addSequenceEvent(sequence, juce::MidiMessage::noteOn(noteChannel, note.midiNote, (juce::uint8)note.velocity), startTick);

        if (!note.pitchCurve.empty())
        {
            const float tickLengthBeats = 1.0f / (float)ticksPerQuarterNote;
            const float noteLength = juce::jmax(0.0f, note.lengthBeats);

            auto emitPitchBendAtTick = [&] (double tick)
            {
                const float beatOffset = (float)(tick / (double)ticksPerQuarterNote - note.startBeat);
                float bendSemitones = evaluatePitchBendAtBeat(note, beatOffset, shape);
                if (shape == 1) {
                    // One-tick window (matches the playback path's one-step window).
                    const float nodeLeadBeats = tickLengthBeats;
                    for (const auto& point : note.pitchCurve) {
                        const float pointOffset = juce::jlimit(0.0f, noteLength, point.x);
                        if (pointOffset > beatOffset && pointOffset <= beatOffset + nodeLeadBeats) {
                            bendSemitones = point.y;
                            break;
                        }
                    }
                }

                const int value = pitchBendToMidiValue(bendSemitones, bendRange);

                if (value != lastPitchBend) {
                    addSequenceEvent(sequence, juce::MidiMessage::pitchWheel(wheelChannel, value), tick);
                    lastPitchBend = value;
                }
            };

            const double firstTick = std::ceil(startTick);
            const double lastTick = std::floor(endTick);
            for (double tick = firstTick; tick <= lastTick; tick += 1.0)
                emitPitchBendAtTick(tick);

            if (std::abs(endTick - lastTick) > 0.0001)
                emitPitchBendAtTick(endTick);
        }

        addSequenceEvent(sequence, juce::MidiMessage::noteOff(noteChannel, note.midiNote, (juce::uint8)0), endTick);
    }
     
    sequence.sort();
    sequence.updateMatchedPairs();
     
    juce::MidiFile midiFile;
    midiFile.setTicksPerQuarterNote(ticksPerQuarterNote);
    midiFile.addTrack(sequence);
    
    juce::File tempDir = juce::File::getSpecialLocation(juce::File::tempDirectory);
    juce::File tempMidi = tempDir.getChildFile("WebDAW_Export_" + juce::String(juce::Time::currentTimeMillis()) + ".mid");
    
    juce::FileOutputStream outStream(tempMidi);
    if (outStream.openedOk())
    {
        outStream.setPosition(0);
        outStream.truncate();
        midiFile.writeTo(outStream);
        outStream.flush();
        
        juce::StringArray files;
        files.add(tempMidi.getFullPathName());
        
        if (auto* dragContainer = juce::DragAndDropContainer::findParentDragContainerFor(this))
        {
            dragContainer->performExternalDragDropOfFiles(files, false, this);
        }

        // Clean up the temp file after the drop completes (may be async on
        // some platforms, so delay the delete).
        juce::Timer::callAfterDelay(5000, [tempMidi] { tempMidi.deleteFile(); });
    }
}
juce::Colour PianoRollComponent::getThemeAccentColour() const
{
    switch (currentThemeIndex) {
        case 0: return juce::Colour(0xff22c55e); // Emerald
        case 1: return juce::Colour(0xff3b82f6); // Blue
        case 2: return juce::Colour(0xfff43f5e); // Rose
        case 3: return juce::Colour(0xfff59e0b); // Amber
        case 4: return juce::Colour(0xffa855f7); // Purple
        default: return juce::Colour(0xff22c55e);
    }
}

juce::Colour PianoRollComponent::getThemeBackgroundColour() const
{
    // User override (Grid Bg colour in the theme panel) wins over the theme.
    const uint32_t overrideColour = processor.pianoRollGridBgColour.load();
    if (overrideColour != 0)
        return juce::Colour(overrideColour).withAlpha(1.0f);

    switch (currentThemeIndex) {
        case 1: return juce::Colour(0xff0f172a); // Blue bg
        case 2: return juce::Colour(0xff1c1917); // Rose bg
        case 3: return juce::Colour(0xff1a1412); // Amber bg
        case 4: return juce::Colour(0xff1e1b4b); // Purple bg
        default: return juce::Colour(panelBg);
    }
}

juce::Colour PianoRollComponent::getThemeGridColour(bool isBlack) const
{
    // FL-style grid: derived from the theme background — white-key rows a
    // shade LIGHTER, black-key rows a shade darker. The contrast is kept
    // deliberately SUBTLE: strong row shading starts to look like a
    // highlighted scale on its own and fights the real scale highlight.
    const juce::Colour bg = getThemeBackgroundColour();
    // With a custom Grid Bg override, keep the row shading very subtle so
    // the chosen colour (e.g. pure black) actually shows; the built-in theme
    // rows keep their slightly stronger keyboard separation.
    if (processor.pianoRollGridBgColour.load() != 0)
        return isBlack ? bg.brighter(0.05f) : bg.brighter(0.10f);
    return isBlack ? bg.brighter(0.30f) : bg.brighter(0.36f);
}

juce::Colour PianoRollComponent::getThemeToolbarColour() const
{
    // Toolbar / ruler / corner surfaces derive from the theme background so
    // switching themes recolors the whole chrome, not just the grid.
    const juce::Colour bg = getThemeBackgroundColour();
    return processor.pianoRollGridBgColour.load() != 0 ? bg.brighter(0.04f) : bg.brighter(0.05f);
}

juce::Colour PianoRollComponent::getThemeKeyColour(bool isBlack) const
{
    const juce::Colour bg = getThemeBackgroundColour();
    if (processor.pianoRollGridBgColour.load() != 0)
        return isBlack ? bg.darker(0.02f) : bg.brighter(0.08f);
    return isBlack ? bg.darker(0.03f) : bg.brighter(0.16f);
}

juce::String PianoRollComponent::getToolbarButtonHint(int x, int y) const
{
    if (drawButtonRect.contains(x, y)) return "Draw tool — click the grid to place notes";
    if (selectButtonRect.contains(x, y)) return "Select tool — click/drag to marquee-select";
    if (gridButtonRect.contains(x, y)) return "Grid snap — click to cycle 1/4 .. 1/128";
    if (velButtonRect.contains(x, y)) return "Velocity lane — show/hide";
    if (dragMidiButtonRect.contains(x, y)) return "Drag MIDI — drag out the sequence as a .mid file";
    if (pitchButtonRect.contains(x, y)) return "Pitch mode — edit pitch curves (E)";
    if (pitchRangeButtonRect.contains(x, y)) return "Pitch bend — click: range + settings · right-click: resolution · the instrument's bend range must match (e.g. Kontakt: often 2 st)";
    if (showPitchEnvelopes && shapeButtonRect.contains(x, y)) return "Curve shape — Linear / Square";
    if (themeButtonRect.contains(x, y)) return "Theme tweaks panel";
    if (panicButtonRect.contains(x, y)) return "Panic! — kill all stuck notes";
    if (legatoButtonRect.contains(x, y)) return "Legato — click to cycle: off · mono (previous note cut) · rtn (previous note cut; retriggered when the top note ends, if it is still held)";
    if (scaleLockButtonRect.contains(x, y)) return "Scale lock — click to lock, right-click: root/scale";
    return {};
}

juce::Colour PianoRollComponent::getThemeGridLineColour(int type) const
{
    // type: 0 = fine, 1 = beat, 2 = bar
    // User override (Grid Line Color in the theme panel) wins over the
    // theme-derived colour; the call sites apply the per-type opacity.
    const uint32_t overrideColour = processor.pianoRollGridLineColour.load();
    if (overrideColour != 0)
        return juce::Colour(overrideColour).withAlpha(1.0f);

    // Deliberately subdued so the grid recedes behind the notes (the clean
    // look); the per-type opacity multipliers at the call sites tune it.
    const juce::Colour bg = getThemeBackgroundColour();
    // With a custom Grid Bg override the lines stay visible without glaring
    // (important when the background is very dark or pure black).
    if (processor.pianoRollGridBgColour.load() != 0)
        return bg.brighter(type == 2 ? 0.45f : (type == 1 ? 0.35f : 0.28f));
    return bg.brighter(type == 2 ? 0.55f : (type == 1 ? 0.45f : 0.35f));
}
