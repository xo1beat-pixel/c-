#pragma once

#include <JuceHeader.h>
#include <vector>
#include <thread>

// pitchCurve node: x/y in beats/semitones relative to the note, tension
// shapes the curve (0 = linear), shape selects the segment type starting at
// this node: 0 = auto (tension-driven), 1 = linear, 2 = square (step),
// 3 = smooth, 4 = ease in, 5 = ease out, 6 = sine.
struct PitchNode { float x; float y; float tension = 0.0f; int shape = 0; };

struct NoteEvent {
    int midiNote;
    float startBeat;
    float lengthBeats;
    juce::uint8 velocity;
    bool isPlaying = false;
    bool selected = false;
    int playingChannel = 1; // MPE-style channel assignment (1-16)
    // RETURN legato: a note cut by a newer (top) note is marked as a return
    // candidate — it is retriggered (at its own start pitch) when the top
    // note ends, but only if it is still held (its end is after the top
    // note's end).
    bool returnPending = false;
    // Shared-wheel ownership (Pitch Bend mode): once a NEWER note starts on
    // the shared channel-1 wheel while this note is still sounding, this
    // note's bend stream is permanently silenced (its curve would override
    // the newer note's reset-to-start-pitch). Reset to false at note-on.
    bool wheelSuperseded = false;
    // Beat of the earliest takeover (newer note onset); -1 = not superseded.
    float wheelTakeoverBeat = -1.0f;
    std::vector<PitchNode> pitchCurve; // x = beat offset (0 to lengthBeats), y = bend in semitones
    // MIDI pitch that was ACTUALLY sent to the instrument at note-on. The UI
    // can transpose/drag notes while they are sounding, which rewrites
    // midiNote in place; every note-off must target the SOUNDED pitch, or the
    // instrument never receives a matching note-off and the voice hangs on
    // sustain until Panic. -1 = the note has never sounded (yet).
    int soundingMidiNote = -1;
};

class WebDAWHostAudioProcessor : public juce::AudioProcessor
{
public:
    WebDAWHostAudioProcessor();
    ~WebDAWHostAudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    int lastPitchBendValue[16] = {8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192};
    int lastPitchBendRangeSent[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    bool activeChannels[16] = {false};
    std::atomic<int> pitchBendRange {1};
    std::atomic<int> pitchShape {0}; // 0 = Linear, 1 = Square
    // Pitch-bend emission resolution: 0 = every sample (maximum detail for
    // extremely fast bends, higher MIDI throughput), otherwise microseconds
    // between evaluations (250/500/1000). Right-click the "PB x st" button
    // in the piano roll to change it.
    std::atomic<int> pitchBendStepMicros { 0 };

    // Bend mode:
    //   0 = "Pitch Bend": notes are placed on channels 2-16 (so back-to-back
    //       same-pitch notes never cut each other), but ALL pitch-bend events
    //       (reset, range RPN, bend stream) go to the SHARED channel-1 wheel —
    //       works with instruments that only honor channel 1's wheel
    //       (e.g. Kontakt without MPE mode).
    //   1 = "MPE": normal MPE — notes on 2-16 with their OWN per-note wheels,
    //       channel 1 reserved as the master channel.
    std::atomic<int> bendMode { 0 };

    // LEGATO note modes: every note-on ALWAYS resets the pitch wheel to the
    // note's OWN start pitch (the value of its first pitch point, usually 0)
    // — legato never carries the wheel over from the previous note. Legato
    // only controls note CUTTING / RETRIGGERING, not pitch. Works in both
    // bend modes (shared wheel and MPE).
    //   0 = off (normal pitch-bend resets)
    //   1 = mono legato: the new note CUTS the previous note's sustain
    //       (note-off sent at the new note-on), only one note sounds at a
    //       time — the classic single-voice lead behaviour
    //   2 = return legato ("rtn"): like mono — the top note CUTS the
    //       previous note's voice — but each cut note is marked as a return
    //       candidate: when the top note ends, the cut note is RETRIGGERED
    //       (at its own start pitch) if it is still held (its end is after
    //       the top note's end); otherwise it stays silent
    std::atomic<int> legatoMode { 0 };

    // Width of the VST browser panel in the editor (px). Draggable via the
    // divider next to the plugin list; persisted with the global settings.
    std::atomic<int> browserPanelWidth { 280 };
    // Whether the VST browser panel is folded away (click the divider to
    // toggle). Persisted with the global settings.
    std::atomic<bool> browserPanelCollapsed { false };

    // Live pitch-bend preview — generated on the AUDIO thread so the preview
    // is bit-exact with real playback (same pitch-bend math & resolution).
    // The UI enables it when a pitch point is grabbed; the audio thread then
    // sustains the note and sweeps its full bend curve with a clean loop.
    std::atomic<bool> pitchPreviewActive { false };
    std::atomic<int> pitchPreviewMidiNote { -1 };
    std::atomic<int> pitchPreviewNoteIndex { -1 };
    std::atomic<float> pitchPreviewJumpBeat { -1.0f }; // UI: jump sweep playhead here
    void startPitchPreview(int midiNote, int noteIndex);
    void stopPitchPreview();

    std::atomic<bool> pianoRollHasSavedEditorState {false};
    std::atomic<bool> pianoRollPitchPreview {false};
    std::atomic<bool> stateRestoredFlag {false};
    std::atomic<int> pianoRollGridDivisorIndex {2};
    std::atomic<int> pianoRollToolMode {0}; // 0 = Draw, 1 = Select
    std::atomic<bool> pianoRollShowPitchEnvelopes {false};
    std::atomic<bool> pianoRollShowVelocityLane {true};
    std::atomic<bool> pianoRollScaleLockActive {false};
    std::atomic<int> pianoRollScaleRoot {0};
    std::atomic<int> pianoRollScaleType {0};
    std::atomic<float> pianoRollKeyHeight {20.0f};
    std::atomic<float> pianoRollPixelsPerBeat {40.0f};
    std::atomic<float> pianoRollViewX {0.0f};
    std::atomic<float> pianoRollViewY {0.0f};

    std::atomic<int> pianoRollThemeIndex {1};
    std::atomic<float> pianoRollPitchNodeSize {6.2f};
    std::atomic<float> pianoRollPitchLineThickness {0.8f};
    std::atomic<float> pianoRollGridOpacity {1.0f};
    std::atomic<float> pianoRollNoteCornerRadius {3.0f};
    std::atomic<float> pianoRollPlayheadThickness {1.25f};
    std::atomic<int> pianoRollVelocityLaneHeight {100};
    std::atomic<float> pianoRollNoteContrast {1.0f};
    std::atomic<float> pianoRollPitchLineContrast {1.0f};
    // MIDI note colour override (ARGB). 0 = follow the theme accent colour.
    std::atomic<uint32_t> pianoRollNoteColour {0};
    // Pitch curve line colour override (ARGB). 0 = follow the theme accent.
    std::atomic<uint32_t> pianoRollPitchLineColour {0};
    // Piano roll grid background colour override (ARGB). 0 = follow theme.
    std::atomic<uint32_t> pianoRollGridBgColour {0};
    // Grid line colour override (ARGB). 0 = follow the theme background.
    std::atomic<uint32_t> pianoRollGridLineColour {0};
    // Note-name text on the keys: colour override (ARGB, 0 = default) + bold.
    std::atomic<uint32_t> pianoRollNoteTextColour {0};
    std::atomic<bool> pianoRollNoteTextBold {false};
    // Toolbar button label text: colour override (ARGB, 0 = default) + bold.
    std::atomic<uint32_t> pianoRollToolbarTextColour {0};
    std::atomic<bool> pianoRollToolbarTextBold {false};
    // Note-name text drawn INSIDE the note rectangles (e.g. "C4"): colour
    // override (ARGB, 0 = default black) + bold. Off by default for the
    // clean look — re-enabled from the theme panel.
    std::atomic<uint32_t> pianoRollNoteNameColour {0};
    std::atomic<bool> pianoRollNoteNameBold {true};
    std::atomic<bool> pianoRollShowNoteNames {false};
    // Font size (px) for note names drawn INSIDE the notes (theme slider).
    std::atomic<int> pianoRollNoteNameFontSize {11};
    // Razor selection area colour (theme panel swatch, default teal).
    std::atomic<uint32_t> pianoRollRazorColour {0xff5eead4};
    // Show ghost pitch lines (low-visibility curve previews on notes that
    // have bends) when pitch mode is OFF. Toggle: theme editor panel.
    std::atomic<bool> pianoRollGhostPitchLines {true};
    // Ghost pitch line opacity in percent (theme editor slider, 5-70).
    std::atomic<int> pianoRollGhostPitchLineOpacity {30};
    // Typeface used for all piano roll text (0 = Segoe UI, 1 = Arial,
    // 2 = Georgia, 3 = Consolas, 4 = Verdana, 5 = Tahoma, 6 = Trebuchet MS,
    // 7 = Times New Roman, 8 = Courier New, 9 = Impact, 10 = Comic Sans MS).
    std::atomic<int> pianoRollFontTypefaceIndex {0};
    // Last active editor tab (0 = VST Host, 1 = Piano Roll); restored when
    // the plugin reopens so it doesn't always jump back to the Host tab.
    std::atomic<int> hostTabIndex {0};
    // Grid line thickness multipliers (0.25 .. 5.0, 1.0 = default) per line
    // type: sub-beats (finest), half-beats (the "&" of each beat), beats
    // (medium), bars/measures (thick).
    std::atomic<float> pianoRollGridSubBeatThickness {1.0f};
    std::atomic<float> pianoRollGridHalfBeatThickness {1.0f};
    std::atomic<float> pianoRollGridBeatThickness {1.0f};
    std::atomic<float> pianoRollGridBarThickness {1.0f};

    const juce::String getName() const override { return "WebDAW Host"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return false; }
    // A MIDI host has no tail of its own; reflect the hosted plugin's tail
    // (e.g. reverb tails) so the DAW doesn't keep the graph alive needlessly.
    // The value is CACHED (updated under processLock on the message thread):
    // hosts may query getTailLengthSeconds() on the audio thread, so we must
    // never dereference hostedPlugin there (it can be replaced mid-load).
    std::atomic<double> cachedTailLengthSeconds { 0.0 };
    double getTailLengthSeconds() const override { return cachedTailLengthSeconds.load(); }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int index) override {}
    const juce::String getProgramName (int index) override { return {}; }
    void changeProgramName (int index, const juce::String& newName) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // --- Hosting specific methods ---
    void loadPlugin(const juce::String& path);
    // Warm load: loads the hosted plugin on a background thread so the editor
    // appears instantly; the optional saved state is applied once loaded.
    // Skips the reload entirely if the same plugin is already loaded.
    void loadPluginAsync(const juce::String& path, const juce::MemoryBlock& hostedStateToRestore = {});
    std::atomic<bool> pluginLoading { false };
    void unloadPlugin();
    juce::AudioPluginInstance* getHostedPlugin() const { return hostedPlugin.get(); }
    juce::String getHostedPluginPath() const { return currentHostedPluginPath; }
    
    // MIDI Sequencing Data
    std::vector<NoteEvent> notes;
    juce::CriticalSection noteLock; // Protects the notes vector between UI and Audio threads
    // Monotonic counter bumped whenever the UI mutates the notes vector. The
    // piano roll uses it to skip re-copying its paint snapshot when nothing
    // changed (keeps scrolling/zooming/playback cheap on huge projects).
    std::atomic<int> notesRevision { 0 };
    
    // Live MIDI from UI
    juce::MidiBuffer liveMidiBuffer;
    juce::CriticalSection liveMidiLock;
    
    void addLiveMidiEvent(const juce::MidiMessage& m) {
        juce::ScopedLock sl(liveMidiLock);
        liveMidiBuffer.addEvent(m, 0);
    }

    void triggerPanic();
    
    // Global Settings
    void loadGlobalSettings();
    void saveGlobalSettings();

    // --- Output metering / latency (audio thread writes, UI reads) ---
    // Smoothed peak levels (0..1) updated every block.
    std::atomic<float> inputLevel { 0.0f };
    std::atomic<float> outputLevel { 0.0f };
    // Cached hosted-plugin latency in samples (UI shows it as ms).
    std::atomic<int> hostedLatencySamples { 0 };

    // --- MIDI clock out to the hosted plugin ---
    std::atomic<bool> midiClockEnabled { false };

    // Whether the hosted plugin's GUI was open the last time the editor was
    // used (persisted in settings so it is restored on reopen).
    std::atomic<bool> pluginGuiVisible { true };

    // Last editor window size (persisted in settings so close/open restores
    // the same window dimensions).
    std::atomic<int> editorWindowWidth { 1100 };
    std::atomic<int> editorWindowHeight { 720 };

    // --- Offline WAV render ---
    bool renderToWavFile(const juce::File& destFile);
    std::atomic<bool> offlineRenderActive { false };
    std::atomic<double> offlineRenderBpm { 120.0 };
    std::atomic<double> offlineRenderPpqStart { 0.0 };
    
    // Playhead tracking for the UI
    std::atomic<float> currentPlayheadBeat { 0.0f };
    std::atomic<bool> isHostPlaying { false };
    
    std::atomic<float> loopStartBeat { 0.0f };
    std::atomic<float> loopEndBeat { 0.0f };
    std::atomic<bool> isLooping { false };

private:
    double lastProcessedPpq = -1.0;

    // Audio-thread-only MIDI-clock state (never touched by the UI thread)
    double clockQuarters = 0.0;      // fractional quarter notes consumed
    bool clockTransportRunning = false;

    // Non-null only while an offline render is in flight: processBlock hands
    // this synthetic playhead to the hosted plugin instead of the DAW's.
    juce::AudioPlayHead* activeRenderPlayHead = nullptr;

    // Thread that owns the offline render. Only that thread synthesizes the
    // transport and touches the hosted plugin; the DAW's audio thread outputs
    // silence during a bounce (no preview, no clicks from double processing).
    std::thread::id renderThreadId;

    // Last prepareToPlay configuration (message thread writes, render reads)
    std::atomic<double> lastPreparedSampleRate { 0.0 };
    std::atomic<int> lastPreparedBlockSize { 0 };

    // Audio-thread-only pitch-preview state (never touched by the UI thread)
    bool previewNoteSounding = false;
    double previewPlayheadBeats = 0.0;
    int previewSoundingNote = -1;

    juce::CriticalSection processLock; // Protects hostedPlugin
    juce::AudioBuffer<float> pluginBuffer;
    
    juce::AudioPluginFormatManager formatManager;
    std::unique_ptr<juce::AudioPluginInstance> hostedPlugin;
    juce::String currentHostedPluginPath;

    // Persistent plugin-description cache: avoids re-scanning the VST3's
    // metadata on every load (the main overhead a reference host avoids).
    juce::KnownPluginList pluginDescriptionCache;
    void loadPluginDescriptionCache();
    void savePluginDescriptionCache();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (WebDAWHostAudioProcessor)
};
