#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class WebDAWHostAudioProcessor;

// Slider used in the theme tweaks panel: adjusts its value with the mouse
// wheel while hovered, and CONSUMES the event so the panel underneath doesn't
// scroll instead of tweaking the slider. Without this override the wheel over
// a slider either does nothing or scrolls the whole panel.
class ThemeWheelSlider : public juce::Slider
{
public:
    using juce::Slider::Slider;

    void mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel) override
    {
        if (isEnabled() && wheel.deltaY != 0.0f && ! isMouseButtonDown())
        {
            const double steps = (getMaximum() - getMinimum()) / 20.0;
            setValue (getValue() + wheel.deltaY * steps); // wheel up = value up
            return; // consume: never propagate to the theme-panel scroller
        }
        juce::Slider::mouseWheelMove (e, wheel);
    }
};

class PianoRollComponent : public juce::Component, public juce::Timer, public juce::ChangeListener
{
public:
    PianoRollComponent(WebDAWHostAudioProcessor& p);
    ~PianoRollComponent() override;

    void changeListenerCallback(juce::ChangeBroadcaster* source) override;

    void paint (juce::Graphics&) override;
    void resized() override;

    void mouseDown (const juce::MouseEvent& e) override;
    void mouseDoubleClick (const juce::MouseEvent& e) override;
    void mouseDrag (const juce::MouseEvent& e) override;
    void mouseUp (const juce::MouseEvent& e) override;
    void mouseMove (const juce::MouseEvent& e) override;
    void mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel) override;
    void mouseExit (const juce::MouseEvent& e) override {
        juce::ignoreUnused(e);
        previewNoteOff();
    }
    
    void visibilityChanged() override {
        if (!isVisible()) {
            previewNoteOff();
        }
    }

    void timerCallback() override;
    bool keyPressed(const juce::KeyPress& key) override;

    void exportMidiToDrag();

private:
    WebDAWHostAudioProcessor& processor;
    bool isDraggingMidiButton = false;
    
    // Pitch Mode state
    bool showPitchEnvelopes = false;
        int editingPitchCurveNoteIndex = -1;
    int editingPitchCurveNodeIndex = -1;
    int editingPitchCurveTensionNodeIndex = -1;
    float initialDragTension = 0.0f;
    int ghostPitchCurveNoteIndex = -1;
    juce::Point<float> ghostPitchPoint { -1.0f, -1.0f };
    // Pitch-node marquee selection (Ctrl/Cmd + drag in pitch mode):
    // (noteIndex, nodeIndex) pairs.
    bool isMarqueeSelectingPitch = false;
    juce::Point<int> pitchMarqueeStart { 0, 0 }, pitchMarqueeCurrent { 0, 0 };
    std::vector<std::pair<int,int>> selectedPitchNodes;
    bool isPitchNodeSelected(int noteIndex, int nodeIndex) const;
    // Group-dragging of marquee-selected pitch nodes.
    bool isDraggingPitchGroup = false;
    std::vector<std::pair<int,int>> pitchGroupDragNodes;
    std::vector<PitchNode> pitchGroupDragOriginalNodes;
    juce::Point<int> pitchGroupDragStart { 0, 0 };

    // Razor Selection state
    bool isRazorSelecting = false;
    bool hasRazorSelection = false;
    bool isResizingRazor = false;
    int razorResizeMode = 0;
    juce::Point<int> razorStartMousePos;
    float razorStartBeat = 0.0f;
    float razorEndBeat = 0.0f;
    int razorTopNote = 127;
    int razorBottomNote = 0;
    float originalRazorStartBeat = 0.0f;
    float originalRazorEndBeat = 0.0f;
    int originalRazorBottomNote = 0;
    int originalRazorTopNote = 127;
    std::vector<NoteEvent> razorDragOriginalNotes;
    // Alt + drag on the left/right edge time-stretches the notes inside.
    bool isStretchingRazor = false;
    int razorStretchEdge = 0; // -1 = left edge, +1 = right edge
    
    // Marquee Selection state
    bool isMarqueeSelecting = false;
    juce::Point<int> marqueeStartPos;
    juce::Point<int> marqueeCurrentPos;
    std::vector<bool> preMarqueeSelection;


    
    // Shape & Scale Lock
    // Toolbar button rects are the single source of truth: paint() draws them
    // and mouseDown() hit-tests against the same rects (previously these were
    // duplicated as magic-number ranges that drifted out of alignment).
    juce::Rectangle<int> drawButtonRect { 12, 6, 75, 24 };
    juce::Rectangle<int> selectButtonRect { 91, 6, 78, 24 };
    juce::Rectangle<int> gridButtonRect { 183, 6, 85, 24 };
    juce::Rectangle<int> velButtonRect { 272, 6, 70, 24 };
    juce::Rectangle<int> dragMidiButtonRect { 358, 6, 95, 24 };
    juce::Rectangle<int> pitchButtonRect { 469, 6, 65, 24 };
    juce::Rectangle<int> pitchRangeButtonRect { 550, 6, 95, 24 };
    juce::Rectangle<int> shapeButtonRect { 632, 6, 75, 24 };
    juce::Rectangle<int> scaleLockButtonRect { 715, 6, 120, 24 };
    juce::Rectangle<int> themeButtonRect { 843, 6, 75, 24 };
    juce::Rectangle<int> panicButtonRect { 926, 6, 65, 24 };
    juce::Rectangle<int> legatoButtonRect { 1085, 6, 80, 24 }; // legato note-mode toggle
    int currentThemeIndex = 1; // Default to Blue
    juce::Colour getThemeAccentColour() const;
    juce::Colour getThemeBackgroundColour() const;
    juce::Colour getThemeGridColour(bool isBlack) const;
    juce::Colour getThemeGridLineColour(int type) const;
    juce::Colour getThemeToolbarColour() const;
    juce::Colour getThemeKeyColour(bool isBlack) const;

    ThemeWheelSlider pitchNodeSizeSlider;
    ThemeWheelSlider pitchLineThicknessSlider;
    ThemeWheelSlider gridOpacitySlider;
    ThemeWheelSlider noteCornerRadiusSlider;
    ThemeWheelSlider playheadThicknessSlider;
    ThemeWheelSlider noteContrastSlider;
    ThemeWheelSlider pitchLineContrastSlider;
    ThemeWheelSlider ghostPitchLinesOpacitySlider;
    ThemeWheelSlider noteNameFontSizeSlider;
    ThemeWheelSlider gridSubBeatThicknessSlider;
    ThemeWheelSlider gridHalfBeatThicknessSlider;
    ThemeWheelSlider gridBeatThicknessSlider;
    ThemeWheelSlider gridBarThicknessSlider;
        juce::ComboBox themeCombo;
        juce::ComboBox fontTypefaceCombo;
    bool showThemePanel = false;
    juce::Rectangle<int> themePanelRect;
    // Colour picker rows in the theme panel: a swatch that opens a colour
    // selector, and a Reset button back to the theme accent.
    juce::Rectangle<int> noteColourSwatchRect;
    juce::Rectangle<int> noteColourResetRect;
    juce::Rectangle<int> pitchLineColourSwatchRect;
    juce::Rectangle<int> pitchLineColourResetRect;
    juce::Rectangle<int> gridBgColourSwatchRect;
    juce::Rectangle<int> gridBgColourResetRect;
    juce::Rectangle<int> gridLineColourSwatchRect;
    juce::Rectangle<int> gridLineColourResetRect;
    // Note-name and toolbar text rows: a bold toggle button, a colour swatch
    // and a Reset button back to the default.
    juce::TextButton noteTextBoldButton;
    juce::Rectangle<int> noteTextColourSwatchRect;
    juce::Rectangle<int> noteTextColourResetRect;
    juce::TextButton toolbarTextBoldButton;
    juce::Rectangle<int> toolbarTextColourSwatchRect;
    juce::Rectangle<int> toolbarTextColourResetRect;
    // Note-name text inside the notes row: show/hide toggle (eye) + bold
    // toggle (B) + colour swatch + Reset.
    juce::TextButton noteNameShowButton;
    juce::TextButton noteNameBoldButton;
    juce::Rectangle<int> noteNameColourSwatchRect;
    juce::Rectangle<int> noteNameColourResetRect;
    juce::Rectangle<int> razorColourSwatchRect;
    juce::Rectangle<int> razorColourResetRect;
    // Ghost pitch lines toggle (theme editor panel): low-visibility pitch
    // curve previews on notes with bends, shown when pitch mode is OFF.
    juce::TextButton ghostPitchLinesButton;
    // Vertical scroll offset for the theme panel when its rows overflow the
    // window (mouse wheel over the panel scrolls it).
    int themePanelScrollY = 0;
    // Which colour the live selector targets: 0 = note, 1 = pitch line,
    // 2 = grid background, 3 = grid lines, 4 = note text, 5 = toolbar text,
    // 6 = note name (inside the notes).
    int colourSelectorTarget = 0;
    void launchColourPicker(int target, const juce::Rectangle<int>& anchor);
    juce::Colour getNoteBaseColour() const
    {
        const uint32_t c = processor.pianoRollNoteColour.load();
        // Always force full opacity — a stored translucent ARGB would make
        // notes look like glass.
        return c != 0 ? juce::Colour(c).withAlpha(1.0f) : getThemeAccentColour();
    }
    juce::Colour getPitchLineBaseColour() const
    {
        const uint32_t c = processor.pianoRollPitchLineColour.load();
        return c != 0 ? juce::Colour(c).withAlpha(1.0f) : getThemeAccentColour();
    }
    // Note-name text on the keys (default grey) and toolbar label text
    // (default per-state grey/white, resolved in drawToolbarButton).
    juce::Colour getNoteTextColour() const
    {
        const uint32_t c = processor.pianoRollNoteTextColour.load();
        return c != 0 ? juce::Colour(c).withAlpha(1.0f) : juce::Colour(0xff6c7383);
    }
    juce::Colour getToolbarTextColour() const
    {
        const uint32_t c = processor.pianoRollToolbarTextColour.load();
        return c != 0 ? juce::Colour(c).withAlpha(1.0f) : juce::Colour(0xff9ca3af);
    }
    // Note-name text drawn inside the notes (default black).
    juce::Colour getNoteNameColour() const
    {
        const uint32_t c = processor.pianoRollNoteNameColour.load();
        return c != 0 ? juce::Colour(c).withAlpha(1.0f) : juce::Colour(0xff000000);
    }

    // Pitch-bend settings panel (toggled from the "PB x st" toolbar button):
    // bend range, curve shape and bend resolution.
    bool showPbSettingsPanel = false;
    juce::Rectangle<int> pbSettingsPanelRect;
    juce::ComboBox pbRangeCombo;
    juce::ComboBox pbShapeCombo;
    juce::ComboBox pbResolutionCombo;
    juce::ToggleButton pitchPreviewToggle;
    juce::ComboBox pbModeCombo; // Bend mode: 1 = Pitch Bend (shared wheel), 2 = MPE
    void syncPbSettingsCombos();

    // Live pitch preview: when enabled, grabbing a pitch point makes the
    // PROCESSOR (audio thread) sustain the whole note and sweep its full bend
    // curve — bit-exact with real playback. The UI only arms it and nudges
    // the sweep playhead while dragging.
    bool pitchPreviewEnabled = false;
    void startPitchPreview(int midiNote, int noteIndex);
    void stopPitchPreview();
    void updatePitchPreviewBend(float bendSemitones, float beatOffset);
    void ensurePitchStartPoints();
    
    float pitchNodeSize = 6.2f;
    float pitchLineThickness = 0.8f;
    float gridOpacityMultiplier = 1.0f;
    float noteCornerRadius = 3.0f;
    float playheadThickness = 1.25f;
    float noteContrast = 1.0f;
    float pitchLineContrast = 1.0f;
    
    bool isScaleLockActive = false;
    int scaleRoot = 0; // 0 = C
    int scaleType = 0; // 0 = Major

    const int toolbarHeight = 36;
    const int rulerHeight = 24;
    const int keysWidth = 46;
    const int numKeys = 127;
    
    // Zoomable parameters
    float keyHeight = 20.0f;
    float pixelsPerBeat = 40.0f;

    // Toolbar Tools & Grid Settings
    enum ToolMode { DrawTool, SelectTool };
    ToolMode currentTool = DrawTool;
    
    int currentGridDivisorIndex = 2; // Default to 1/16th note
    const float gridOptions[6] = { 1.0f, 0.5f, 0.25f, 0.125f, 0.0625f, 0.03125f }; 
    const juce::String gridNames[6] = { "1/4", "1/8", "1/16", "1/32", "1/64", "1/128" };
    
    float getCurrentGridSnap() const { return gridOptions[currentGridDivisorIndex]; }

    // View parameters for Panning/Scrolling
    float viewX = 0.0f;
    float viewY = 0.0f;
    
    // Panning state
    bool isPanning = false;
    juce::Point<int> panStartMouse;
    float panStartViewX = 0.0f;
    float panStartViewY = 0.0f;

    // Note Preview & Helpers
    int lastPreviewedNote = -1;
    void previewNoteOn(int note);
    void previewNoteOff();
    juce::String getNoteName(int midiNote) const;

    // Coordinate Math
    int screenToNote(int y) const;
    float screenToBeat(int x) const;
    juce::Rectangle<float> getNoteRectGridSpace(int midiNote, float startBeat, float lengthBeats) const;
    void repaintPitchEditArea(const NoteEvent& note);
    void repaintPitchCurveSegment(const NoteEvent& note, int nodeIndex, juce::Point<float> previousPoint);

    // Interaction State
    int draggingNoteIndex = -1;
    enum DragAction { None, Move, ResizeRight, EditVelocity, Erase };
    DragAction currentDragAction = None;
    
    std::vector<NoteEvent> clipboardNotes;
    
    struct SelectedNoteState {
        int index;
        float originalStartBeat;
        float originalLengthBeats;
        int originalMidiNote;
        juce::uint8 originalVelocity;
    };
    std::vector<SelectedNoteState> selectedNotesDragState;
    
    float originalStartBeat = 0.0f;
    float originalLengthBeats = 0.0f;
    int originalMidiNote = 0;
    int originalVelocity = 0;
    juce::Point<int> dragStartPos;
    juce::Point<int> lastDragPos;
    
    bool wasShiftDownDuringDrag = false;
    float lastNoteLength = -1.0f;

    // Velocity Lane
    bool showVelocityLane = true;
    int velocityLaneHeight = 100;
    // Divider drag: grab the strip at the top of the lane to resize it.
    bool isDraggingVelLaneDivider = false;
    int velLaneDividerStartY = 0;
    int velLaneDividerStartHeight = 0;
    // Velocity value at the mouse cursor's vertical position (absolute mode).
    float velAtCursor = 0.0f;
    // True when the velocity drag STARTED on a lollipop: smooth relative
    // adjustment (no jump). False = clicked elsewhere: jump to cursor value.
    bool velGrabbedHead = false;
    float velSmoothDelta = 0.0f;

    // Note tail handle: hovered note index + right-edge flag for the resize
    // grip drawn in paint().
    int hoverHandleNoteIndex = -1;
    bool hoverHandleRightEdge = false;

    bool wasPlaying = false;
    bool undoStateSavedForDrag = false;
    // Right-click eraser context: true = started on a pitch point (erase
    // points only), false = erase MIDI notes.
    bool eraseIsPitchContext = false;

    // Drag-preview ghost: while moving notes, outline their ORIGINAL
    // positions (dim) so the user sees how far they've dragged.
    bool showDragGhost = false;
    // True while the current drag is a freshly CREATED note (Draw tool) —
    // used to trigger the placement flash on mouseUp.
    bool wasNewNoteDrag = false;
    // Note-placement flash: index of the note to flash + remaining alpha
    // (decayed in timerCallback, drawn in paint()).
    int flashNoteIndex = -1;
    float noteFlashAlpha = 0.0f;

    // Animated scroll/zoom: targets lerped toward in timerCallback (wheel
    // scroll + Ctrl+wheel zoom only; programmatic view sets stay instant).
    float animViewX = 0.0f;
    float animViewY = 0.0f;
    float animPixelsPerBeat = 0.0f;
    bool viewAnimating = false;
    void animateViewTo(float tx, float ty, float tppb)
    {
        animViewX = juce::jmax(0.0f, tx);
        animViewY = juce::jlimit(0.0f, (float)(numKeys * keyHeight), ty);
        animPixelsPerBeat = juce::jlimit(10.0f, 400.0f, tppb);
        viewAnimating = true;
    }

    // Debounced persistence: markPersistentEditorStateChanged() only sets this
    // flag; the 30 Hz timer flushes it (settings XML write + host refresh) at
    // most ~3 Hz so scrolling/dragging never triggers file-I/O storms.
    mutable bool settingsDirty = false;
    int settingsFlushTick = 0;

    // Toolbar hover tooltip state (drawn in paint(), driven by mouseMove())
    juce::String hoveredToolbarHint;
    juce::Rectangle<int> hoveredToolbarButtonRect;
    juce::String getToolbarButtonHint(int x, int y) const;

    std::vector<NoteEvent> paintNotesCache;
    // Notes revision the cache was copied from; -1 forces the first copy.
    int cachedNotesRevision = -1;
    // Undo/redo snapshots: notes + the razor selection box, so undoing a
    // razor edit also restores the selection area itself.
    struct NoteEditUndoState
    {
        std::vector<NoteEvent> notes;
        bool hasRazor = false;
        float razorStart = 0.0f;
        float razorEnd = 0.0f;
        int razorTop = 0;
        int razorBottom = 127;
        // Grid/theme are snapshotted too so their changes are undoable.
        int gridDivisorIndex = 2;
        int themeIndex = 1;
    };
    std::vector<NoteEditUndoState> undoHistory;
    std::vector<NoteEditUndoState> redoHistory;
    // Millisecond counter of the last saveUndoState(); rapid successive saves
    // (keyboard bursts like nudges/deletes) merge into one undo step.
    juce::uint32 lastUndoSaveTime = 0;
    void saveUndoState(bool allowMerge = true);
    void performUndo();
    void performRedo();
    void loadPersistentEditorState();
    void storePersistentEditorState() const;
    void markPersistentEditorStateChanged() const;

    float quantizeToScale(int currentMidiNote, float bendY, bool ignoreLock = false) const;
    // Scale-button menu snap actions: 200 = selected notes, 201 = selected
    // notes' bend nodes, 202 = all notes' bend nodes.
    void snapToScaleAction(int action);
    bool findPitchNodeAtMouse(int& outNoteIndex, int& outNodeIndex) const;
    void showPitchNodeShapeMenu(int noteIndex, int nodeIndex);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PianoRollComponent)
};
