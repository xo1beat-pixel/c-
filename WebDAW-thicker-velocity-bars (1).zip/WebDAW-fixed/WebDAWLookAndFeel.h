#pragma once

#include <JuceHeader.h>

// Shared modern dark styling for popup menus and theme-panel TextButtons
// across the WebDAW piano roll and the VST browser. Applied per-widget
// (menus set their LAF explicitly; TextButtons get it individually), so it
// never restyles sliders/combos/scrollbars that have custom looks.
class WebDAWLookAndFeel : public juce::LookAndFeel_V4
{
public:
    WebDAWLookAndFeel()
    {
        setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff171c23));
        setColour (juce::PopupMenu::textColourId, juce::Colour (0xffe2e8f0));
        setColour (juce::PopupMenu::headerTextColourId, juce::Colour (0xff8b98a9));
        setColour (juce::PopupMenu::highlightedBackgroundColourId, juce::Colour (0xff3b82f6).withAlpha (0.30f));
        setColour (juce::PopupMenu::highlightedTextColourId, juce::Colours::white);
    }

    static WebDAWLookAndFeel& get()
    {
        static WebDAWLookAndFeel instance;
        return instance;
    }

    // ------------------------------------------------------------------ //
    // Popup menus
    // ------------------------------------------------------------------ //
    void drawPopupMenuBackground (juce::Graphics& g, int width, int height) override
    {
        juce::Rectangle<float> r (0.0f, 0.0f, (float) width, (float) height);

        // Soft vertical gradient + hairline border + faint top inner highlight.
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff1b2129), 0.0f, 0.0f,
                                                 juce::Colour (0xff14181e), 0.0f, (float) height, false));
        g.fillRect (r);

        g.setColour (juce::Colour (0xff2e3742));
        g.drawRect (r, 1.0f);

        g.setColour (juce::Colours::white.withAlpha (0.05f));
        g.drawHorizontalLine (1, 1.0f, (float) width - 2.0f);
    }

    void drawPopupMenuItem (juce::Graphics& g,
                            const juce::Rectangle<int>& area,
                            bool isSeparator,
                            bool isActive,
                            bool isHighlighted,
                            bool isTicked,
                            bool hasSubMenu,
                            const juce::String& text,
                            const juce::String& shortcutKeyText,
                            const juce::Drawable* icon,
                            const juce::Colour* textColour) override
    {
        if (isSeparator)
        {
            juce::Rectangle<float> r (area.reduced (12, 0).toFloat());
            g.setGradientFill (juce::ColourGradient (juce::Colour (0x002e3742),
                                                     r.getX(), 0.0f,
                                                     juce::Colour (0x662e3742), r.getCentreX(), 0.0f,
                                                     false));
            g.fillRect (r.getX(), r.getCentreY() - 0.5f, r.getWidth() * 0.5f, 1.0f);
            g.setGradientFill (juce::ColourGradient (juce::Colour (0x662e3742),
                                                     r.getCentreX(), 0.0f,
                                                     juce::Colour (0x002e3742), r.getRight(), 0.0f,
                                                     false));
            g.fillRect (r.getCentreX(), r.getCentreY() - 0.5f, r.getWidth() * 0.5f, 1.0f);
            return;
        }

        juce::Rectangle<float> itemArea (area.toFloat());

        // Hover highlight: rounded accent-tinted pill.
        if (isHighlighted && isActive)
        {
            g.setColour (findColour (juce::PopupMenu::highlightedBackgroundColourId));
            g.fillRoundedRectangle (itemArea.reduced (3.0f, 1.5f), 6.0f);
        }

        const float leftPad = 24.0f;

        // Ticked: small accent check on the left.
        if (isTicked && isActive)
        {
            juce::Path check;
            const float cx = 10.0f;
            const float cy = itemArea.getCentreY();
            check.startNewSubPath (cx - 4.0f, cy);
            check.lineTo (cx - 1.0f, cy + 3.0f);
            check.lineTo (cx + 4.5f, cy - 3.5f);
            g.setColour (juce::Colour (0xff3b82f6));
            g.strokePath (check, juce::PathStrokeType (2.0f, juce::PathStrokeType::curved,
                                                       juce::PathStrokeType::rounded));
        }

        // Text.
        juce::Colour textC = textColour != nullptr ? *textColour
                          : (isActive ? findColour (juce::PopupMenu::textColourId)
                                      : juce::Colour (0xff5b6675));
        if (isHighlighted && isActive)
            textC = findColour (juce::PopupMenu::highlightedTextColourId);
        if (!isActive && !isHighlighted)
            textC = textC.withAlpha (0.55f); // disabled / section header

        const bool isHeader = !isActive && !isHighlighted && !isTicked;
        g.setFont (isHeader ? juce::Font (12.0f, juce::Font::bold)
                            : juce::Font (13.5f, isTicked || isHighlighted ? juce::Font::bold : juce::Font::plain));
        if (isHeader)
            textC = textC.brighter (0.25f).withAlpha (0.9f);

        g.setColour (textC);
        g.drawText (text, juce::Rectangle<float> (itemArea.getX() + leftPad, itemArea.getY(),
                                                  itemArea.getWidth() - leftPad - 24.0f, itemArea.getHeight()),
                    juce::Justification::centredLeft);

        // Shortcut text (dim, right-aligned).
        if (shortcutKeyText.isNotEmpty())
        {
            g.setFont (juce::Font (11.5f, juce::Font::plain));
            g.setColour (textC.withAlpha (0.6f));
            g.drawText (shortcutKeyText,
                        juce::Rectangle<float> (itemArea.getX() + itemArea.getWidth() - 80.0f, itemArea.getY(),
                                                72.0f, itemArea.getHeight()),
                        juce::Justification::centredRight);
        }

        // Sub-menu chevron.
        if (hasSubMenu && isActive)
        {
            juce::Path chev;
            const float cx = itemArea.getRight() - 12.0f;
            const float cy = itemArea.getCentreY();
            chev.startNewSubPath (cx - 2.5f, cy - 4.0f);
            chev.lineTo (cx + 1.5f, cy);
            chev.lineTo (cx - 2.5f, cy + 4.0f);
            g.setColour (textC.withAlpha (0.75f));
            g.strokePath (chev, juce::PathStrokeType (1.6f, juce::PathStrokeType::curved,
                                                      juce::PathStrokeType::rounded));
        }
    }

    // ------------------------------------------------------------------ //
    // TextButtons (theme-panel buttons etc.)
    // ------------------------------------------------------------------ //
    void drawButtonBackground (juce::Graphics& g,
                               juce::Button& button,
                               const juce::Colour& backgroundColour,
                               bool shouldDrawButtonAsHighlighted,
                               bool shouldDrawButtonAsDown) override
    {
        auto r = button.getLocalBounds().toFloat().reduced (1.0f);
        const float radius = 6.0f;
        const bool toggled = button.getToggleState();

        juce::Colour base = button.findColour (toggled ? juce::TextButton::buttonOnColourId
                                                       : juce::TextButton::buttonColourId);
        if (shouldDrawButtonAsHighlighted) base = base.brighter (0.16f);
        if (shouldDrawButtonAsDown)        base = base.darker (0.12f);

        // Subtle vertical gradient + hairline border + top highlight.
        g.setGradientFill (juce::ColourGradient (base.brighter (0.10f), 0.0f, r.getY(),
                                                 base.darker (0.06f), 0.0f, r.getBottom(), false));
        g.fillRoundedRectangle (r, radius);

        g.setColour (juce::Colours::white.withAlpha (toggled ? 0.14f : 0.07f));
        g.drawHorizontalLine ((int) r.getY() + 1, r.getX() + 2.0f, r.getRight() - 2.0f);

        g.setColour (base.darker (0.55f).withAlpha (0.9f));
        g.drawRoundedRectangle (r, radius, 1.0f);
    }
};

// Shared instance helper (one per process).
inline WebDAWLookAndFeel& webDAWMenuLAF()
{
    return WebDAWLookAndFeel::get();
}
